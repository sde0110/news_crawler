# -*- coding: utf-8 -*-
import time
from bs4 import BeautifulSoup
import requests
import pandas as pd
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from datetime import datetime, timedelta
from newspaper import Article
import warnings
import sys
import os
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)
from database_utils import connect_db, save_to_monthly_table, get_last_data_from_monthly_tables, setup_webdriver, create_monthly_table
warnings.filterwarnings('ignore')

# 기본 테이블명
BASE_TABLE = 'naver_news'

def setup_database():
    """데이터베이스 연결 설정 및 기존 데이터 로드"""
    # 기본값 설정
    default_values = (
        datetime.today() - timedelta(days=7),  # 시작일
        datetime.today() - timedelta(days=1),  # 종료일
        1,                                     # 다음 인덱스
        set(),                                 # 기존 URL
        set()                                  # 기존 제목
    )
    
    try:
        conn = connect_db()
        if not conn:
            print("데이터베이스 연결 실패")
            return default_values
        
        # 1. 월별 테이블 목록 조회 및 생성
        with conn.cursor() as cursor:
            cursor.execute(f"SHOW TABLES LIKE '{BASE_TABLE}_%'")
            tables = [row[0] for row in cursor.fetchall()]
            
            # 테이블이 없으면 현재 월에 해당하는 테이블 생성
            if not tables:
                current_date = datetime.now()
                monthly_table = f"{BASE_TABLE}_{current_date.year}_{current_date.month:02d}"
                if create_monthly_table(conn, BASE_TABLE, monthly_table):
                    print(f"[정보] 새 월별 테이블 {monthly_table} 생성 완료")
                    tables.append(monthly_table)
        
        # 2. 최근 데이터 및 다음 인덱스 조회
        latest_row, next_index = get_last_data_from_monthly_tables(conn, BASE_TABLE, 'register_date')
        
        # 3. 기존 URL과 제목 로드 (중복 방지용)
        existing_urls = set()
        existing_titles = set()
        
        for table in tables:
            # URL 로드
            with conn.cursor() as cursor:
                try:
                    cursor.execute(f"SELECT url FROM {table} WHERE url IS NOT NULL AND url != ''")
                    existing_urls.update(row[0] for row in cursor.fetchall() if row[0])
                except Exception as e:
                    print(f"[경고] {table} URL 로드 중 오류: {e}")
            
            # 제목 로드
            with conn.cursor() as cursor:
                try:
                    cursor.execute(f"SELECT title FROM {table} WHERE title IS NOT NULL AND title != ''")
                    existing_titles.update(row[0] for row in cursor.fetchall() if row[0])
                except Exception as e:
                    print(f"[경고] {table} 제목 로드 중 오류: {e}")
        
        conn.close()
        
        # 4. 날짜 범위 설정 - 오류 수정 부분
        if latest_row:
            # 데이터 형식 확인 (딕셔너리 또는 튜플)
            register_date = None
            
            if isinstance(latest_row, dict):
                register_date = latest_row.get('register_date')
            elif isinstance(latest_row, tuple) and len(latest_row) > 3:  # 인덱스 접근 (테이블 구조에 맞게 조정 필요)
                register_date = latest_row[3]  # register_date가 4번째 필드라고 가정
            
            if register_date:
                # 마지막 수집 날짜 + 1일
                start_date = datetime.strptime(str(register_date), '%Y-%m-%d') + timedelta(days=1)
            else:
                # 등록일 정보가 없는 경우 기본값
                start_date = datetime.today() - timedelta(days=30)
        else:
            # 데이터가 없는 경우 기본값
            start_date = datetime.today() - timedelta(days=30)
        
        # 종료일은 어제
        end_date = datetime.today() - timedelta(days=1)
        
        # 시간 정보 추가 (시작: 00:00:00, 종료: 23:59:59)
        start_date = datetime.combine(start_date.date(), datetime.min.time())
        end_date = datetime.combine(end_date.date(), datetime.max.time())
        
        print(f"수집 기간: {start_date.strftime('%Y-%m-%d')} ~ {end_date.strftime('%Y-%m-%d')}")
        print(f"기존 데이터: URL {len(existing_urls)}개, 제목 {len(existing_titles)}개")
        
        return start_date, end_date, next_index, existing_urls, existing_titles
        
    except Exception as e:
        print(f"[오류] 데이터베이스 설정 중 오류: {e}")
        return default_values

def collect_news_urls(start_date, end_date):
    """네이버 뉴스 검색에서 밀양 관련 URL 및 저자 정보 수집"""
    try:
        # 웹드라이버 설정
        driver = setup_webdriver(headless=True)
        
        # 검색 파라미터 설정
        start_str = start_date.strftime("%Y.%m.%d")
        end_str = end_date.strftime("%Y.%m.%d")
        search_query = "%EB%B0%80%EC%96%91"  # 밀양
        
        article_list = []
        author_list = []
        
        # 페이지별 검색 및 URL 수집
        for page in range(1, 1000, 10):  # 1, 11, 21, ...
            search_url = f"https://search.naver.com/search.naver?where=news&sm=tab_pge&query={search_query}&sort=1&photo=0&field=0&pd=3&ds={start_str}&de={end_str}&start={page}"
            
            # SSL 검증 무시 설정
            requests.packages.urllib3.disable_warnings()
            
            # 검색 결과 페이지 요청
            response = requests.get(
                search_url, 
                headers={'User-Agent': 'Mozilla/5.0'},
                verify=False  # SSL 검증 비활성화
            )
            
            # HTML 파싱
            soup = BeautifulSoup(response.text, "html.parser")
            articles = soup.select("ul.list_news > li")
            
            # 결과가 없으면 종료
            if not articles:
                print(f"총 {len(article_list)}개 URL 수집 완료")
                break
                
            # 기사 URL 및 저자 추출
            for article in articles:
                try:
                    article_url = article.find("a")['data-url']
                    article_author = article.find_all("a")[3].text if len(article.find_all("a")) >= 4 else "Unknown"
                    
                    article_list.append(article_url)
                    author_list.append(article_author)
                except Exception as e:
                    continue
            
            print(f"페이지 {page//10 + 1} 처리: {len(articles)}개 발견")
            time.sleep(1)  # 요청 간격 조절
        
        return driver, article_list, author_list
        
    except Exception as e:
        print(f"[오류] URL 수집 중 오류: {e}")
        return None, [], []

def clean_text(text):
    """텍스트 정제 함수 - 광고, 저작권 표시 등 제거"""
    # 주요 정규식 패턴 (많이 사용되는 패턴만 유지)
    remove_patterns = [
        r'ⓒ .+? 무단전재·재배포 금지',
        r'저작권자 ⓒ .+? 무단전재 및 재배포 금지',
        r'밀양=.+?기자',
        r'\[.+? 기자\]',
        r'\w+@\w+\.\w+',
        r'\(사진=.+?\)',
        r'\(사진제공=.+?\)',
        "무단전재 및 재배포 금지",
        '카카오톡(으)로 기사보내기',
        '네이버밴드(으)로 기사보내기',
        "기사 잘 보셨나요?",
        "독자님의 응원이 기자에게 큰 힘이 됩니다."
    ]
    
    # 정규식 패턴 적용
    cleaned_text = text
    for pattern in remove_patterns:
        cleaned_text = re.sub(pattern, "", cleaned_text)
    
    # 중복 공백 제거 및 앞뒤 공백 제거
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()
    return cleaned_text

def process_news_content(driver, urls, authors, existing_urls, existing_titles, next_index):
    """뉴스 내용 수집, 전처리 및 저장"""
    try:
        # 결과 저장용 데이터프레임 초기화
        df = pd.DataFrame(columns=['idx', 'title', 'author', 'register_date', 'url', 'body', 'summary', 'status'])
        saved_count = 0
        skipped_count = 0
        
        # 각 URL별로 처리
        for i, (url, author) in enumerate(zip(urls, authors)):
            # 중복 URL 스킵
            if url in existing_urls:
                print(f"중복 URL 스킵: {url}")
                skipped_count += 1
                continue
                
            try:
                print(f"기사 {i+1}/{len(urls)} 처리 중")
                
                # newspaper로 기사 내용 추출
                article = Article(url, language='ko')
                article.download()
                article.parse()
                
                # 중복 제목 스킵
                if article.title in existing_titles:
                    print(f"중복 제목 스킵: {article.title}")
                    skipped_count += 1
                    continue
                
                # 기본 정보 설정
                new_row = {
                    'idx': next_index + saved_count,
                    'url': url,
                    'author': author,
                    'title': article.title,
                    'register_date': article.publish_date.strftime('%Y-%m-%d') if article.publish_date else datetime.today().strftime('%Y-%m-%d'),
                    'status': 'N'
                }
                
                # 뉴시스 기사는 웹드라이버로 추가 처리
                if author != '뉴시스':
                    text = article.text
                else:
                    driver.get(url)
                    text = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.XPATH, '//*[@id="content"]/div[1]/div[1]/div[3]/article'))
                    ).text
                
                # 텍스트 정제
                cleaned_text = clean_text(text)
                
                # 본문 및 요약 저장
                new_row['body'] = cleaned_text
                new_row['summary'] = cleaned_text[:300] + "..." if len(cleaned_text) > 300 else cleaned_text
                
                # 데이터프레임에 추가
                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
                saved_count += 1
                
                # 대기 시간
                time.sleep(0.5)
                
            except Exception as e:
                print(f"[경고] 기사 처리 중 오류 ({url}): {e}")
                continue
        
        # 중복 제거 및 데이터 정제
        df = df.drop_duplicates(subset=['url'])
        df = df.dropna(subset=['body'])
        df = df.fillna("")
        
        # 데이터베이스에 저장
        if not df.empty:
            conn = connect_db()
            try:
                columns = ['idx', 'title', 'author', 'register_date', 'url', 'body', 'summary', 'status']
                total_saved = save_to_monthly_table(conn, df, BASE_TABLE, 'register_date', columns)
                print(f"총 {total_saved}건의 기사가 월별 테이블에 저장되었습니다.")
            finally:
                if conn:
                    conn.close()
        
        return saved_count, skipped_count
        
    except Exception as e:
        print(f"[오류] 뉴스 처리 중 오류: {e}")
        return 0, 0

def main():
    """메인 실행 함수"""
    print("네이버 뉴스 크롤러 시작")
    
    try:
        # 1. 데이터베이스 설정 및 기존 데이터 로드
        start_date, end_date, next_index, existing_urls, existing_titles = setup_database()
        
        # 2. 뉴스 URL 수집
        driver, urls, authors = collect_news_urls(start_date, end_date)
        if not urls:
            print("[정보] 수집된 URL이 없습니다.")
            return
        
        # 3. 뉴스 내용 수집 및 저장
        try:
            saved_count, skipped_count = process_news_content(
                driver, urls, authors, existing_urls, existing_titles, next_index
            )
            print(f"=== 크롤링 완료 ===")
            print(f"- 처리된 URL: {len(urls)}개")
            print(f"- 저장된 기사: {saved_count}개")
            print(f"- 중복 기사: {skipped_count}개")
        finally:
            # 웹드라이버 종료
            if driver:
                driver.quit()
                print("웹드라이버 종료 완료")
                
    except Exception as e:
        print(f"[오류] 크롤러 실행 중 오류: {e}")

if __name__ == "__main__":
    # SSL 경고 무시 설정
    requests.packages.urllib3.disable_warnings()
    
    # 크롤러 실행
    main()