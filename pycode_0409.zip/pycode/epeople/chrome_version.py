from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from datetime import datetime, timedelta

def get_chrome_driver():
    """크롬 웹드라이버를 설정하고 반환합니다."""
    options = webdriver.ChromeOptions()
    # options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
    
    service = Service(executable_path="C:\drivers\chromedriver.exe")
    return webdriver.Chrome(service=service, options=options)

# 공통으로 사용할 시간 지연값
DELAY_TIME = 2

# 날짜 처리 유틸리티 함수
def get_next_date(date_str, format='%Y-%m-%d'):
    """문자열 날짜에 1일을 더한 날짜 문자열 반환"""
    date_obj = datetime.strptime(date_str, format)
    next_date = date_obj + timedelta(days=1)
    return next_date.strftime(format)

def get_today_and_yesterday():
    """오늘과 어제 날짜를 '%Y-%m-%d' 형식으로 반환"""
    today = datetime.now()
    yesterday = today - timedelta(days=1)
    return today.strftime('%Y-%m-%d'), yesterday.strftime('%Y-%m-%d')

# Chrome 버전 확인용
if __name__ == "__main__":
    driver = get_chrome_driver()
    print("Chrome WebDriver Version:", driver.capabilities['browserVersion'])
    driver.quit()
