import time, re
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
import pandas as pd
import warnings
from chrome_version import get_chrome_driver, DELAY_TIME
warnings.filterwarnings('ignore')


def crawler(url, last_date=None, today=None):
    """
    국민신문고 민원 크롤링
    
    Args:
        url (str): 사용하지 않음 (호환성 유지를 위해 남겨둠)
        last_date (str): 시작 날짜 (YYYY-MM-DD 형식)
        today (str): 종료 날짜 (YYYY-MM-DD 형식)
        
    Returns:
        pd.DataFrame: 크롤링된 데이터를 담은 데이터프레임
    """
    driver = None
    try:
        driver = get_chrome_driver()
        print(f"국민신문고 크롤링 시작: {last_date} ~ {today}")
        
        # 국민신문고 URL 접속
        url = 'https://www.epeople.go.kr/nep/prpsl/opnPrpl/opnpblPrpslList.npaid'
        driver.get(url)
        time.sleep(DELAY_TIME)
        
        # 페이지 설정: 50개 보기 선택
        select = Select(driver.find_element(By.ID, "listCnt"))
        select.select_by_index(4)  # 50개 선택
        
        # 지방자치단체 선택
        select_agency = Select(driver.find_element(By.ID, "searchCd"))
        select_agency.select_by_index(2)  # 지방자치단체 선택
        
        time.sleep(DELAY_TIME)
        
        # 지역 선택 (기본값으로 설정)
        select_area = Select(driver.find_element(By.NAME, "searchInstCd"))
        select_area.select_by_index(1)  # 예: 첫 번째 지역 선택
        
        # 날짜 설정
        if last_date and today:
            # 시작일 입력
            start_date = driver.find_element(By.NAME, "rqstStDt")
            start_date.clear()
            start_date.send_keys(last_date)
            
            # 종료일 입력
            end_date = driver.find_element(By.NAME, "rqstEndDt")
            end_date.clear()
            end_date.send_keys(today)
        
        # 검색 버튼 클릭
        search_button_xpath = '//*[@id="frm"]/div[1]/div[1]/div[4]/button[1]'
        driver.find_element(By.XPATH, search_button_xpath).click()
        time.sleep(DELAY_TIME)
        
        # 결과 데이터프레임 초기화
        df = pd.DataFrame(columns=['제목', '내용', '작성일자', '답변', '답변일자', '처리기관', '분야'])
        
        # 데이터 건수 확인
        try:
            total = driver.find_element(By.XPATH, '//*[@id="frm"]/div[2]/span/span').text
            print(f"데이터 건수: {total}")
        except:
            print("데이터 건수를 확인할 수 없습니다.")
        
        # 페이지네이션 영역 찾기 및 최대 페이지 수 확인
        try:
            pagination = driver.find_element(By.XPATH, '//*[@id="frm"]/div[3]')
            html_content = pagination.get_attribute('innerHTML')
            page_numbers = re.findall(r'frmPageLink\((\d+)\)', html_content)
                
            if page_numbers:
                page_count = max(map(int, page_numbers))
                print(f"마지막 페이지 번호: {page_count}")
            else:
                page_count = 1
                print("페이지 번호를 찾을 수 없어 1로 설정합니다.")
        except Exception as e:
            print(f"[오류] 페이지 수 확인 실패: {e}, 페이지 수를 1로 설정")
            page_count = 1
            
        print(f"[디버그] 총 {page_count}페이지 크롤링 예정")
        
        # 페이지별 크롤링
        current_page = 1
        while current_page <= page_count:
            print(f"{current_page}/{page_count} 페이지 처리 중...")
            
            try:
                # 테이블 데이터 추출
                table = driver.find_element(By.CLASS_NAME, 'tbl.default.brd1')
                tbody = table.find_element(By.TAG_NAME, "tbody")
                rows = tbody.find_elements(By.TAG_NAME, "tr")
                
                if len(rows) == 0:
                    print("[디버그] 데이터가 없습니다.")
                    break
                
                # 각 행의 데이터 추출
                for i in range(1, len(rows) + 1):
                    try:
                        # 게시물 클릭
                        complain_xpath = f'//*[@id="frm"]/table/tbody/tr[{i}]/td[2]/a'
                        driver.find_element(By.XPATH, complain_xpath).click()
                        time.sleep(DELAY_TIME)
                        
                        # 상세 정보 가져오기
                        try:
                            title = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[1]/div[1]').text
                        except:
                            title = "제목 없음"
                        
                        try:
                            content = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[3]').text
                        except:
                            content = "내용 없음"
                        
                        try:
                            reg_date = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[4]/div[2]').text
                        except:
                            reg_date = ""
                        
                        try:
                            department = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[2]/div[2]').text
                        except:
                            department = "처리기관 정보 없음"
                        
                        try:
                            answer = driver.find_element(By.XPATH, '//*[@id="txt"]/div[2]/div[1]/div[3]').text
                        except:
                            answer = "답변 전"
                        
                        try:
                            answer_date = driver.find_element(By.XPATH, '//*[@id="txt"]/div[2]/div/div/div[2]').text
                        except:
                            answer_date = ""
                        
                        try:
                            part = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[2]/div[1]').text
                        except:
                            part = "분야 정보 없음"
                        
                        # 데이터프레임에 추가
                        new_row = pd.DataFrame({
                            '제목': [title],
                            '내용': [content],
                            '작성일자': [reg_date],
                            '처리기관': [department],
                            '답변': [answer],
                            '답변일자': [answer_date],
                            '분야': [part]
                        })
                        df = pd.concat([df, new_row], ignore_index=True)
                        
                        # 뒤로 가기
                        driver.back()
                        time.sleep(DELAY_TIME)
                    
                    except Exception as e:
                        print(f"[오류] {i}번째 행 처리 중 오류: {e}")
                        try:
                            driver.back()  # 오류 발생 시 목록으로 돌아가기
                            time.sleep(DELAY_TIME)
                        except:
                            pass
                
                # 다음 페이지로 이동
                current_page += 1
                if current_page <= page_count:
                    try:
                        driver.execute_script(f"frmPageLink({current_page})")
                        time.sleep(DELAY_TIME)
                    except Exception as e:
                        print(f"[오류] 페이지 이동 실패: {e}")
                        break
            
            except Exception as e:
                print(f"[오류] 페이지 처리 중 오류: {e}")
                break
        
        print(f"[디버그] 크롤링 완료: {len(df)}개 게시물")
        return df
        
    except Exception as e:
        print(f"[오류] 크롤링 실패: {e}")
        return pd.DataFrame()
    finally:
        if driver:
            driver.quit()



