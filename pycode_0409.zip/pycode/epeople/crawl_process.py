# -*- coding: utf-8 -*-
import pandas as pd
from datetime import date, timedelta, datetime
import sys
import os
import pymysql

# 상대 경로 처리
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)

# 로컬 모듈 가져오기
from nation_crawl import crawler
from nation_all_crawl import all_crawler
from chrome_version import get_today_and_yesterday


#########################################
##### 데이터베이스 관련 함수 #############

# 로컬 DB 연결 정보
DB_CONFIG = {
    'host': 'localhost',
    'port': 3307,
    'user': 'root',
    'password': 'epdlxjdpeb!1',
    'db': 'ghost_2021',
    'charset': 'utf8mb4'
}

def connect_db():
    """데이터베이스 연결 함수"""
    try:
        # 로컬 DB 설정 사용
        connection = pymysql.connect(**DB_CONFIG)
        return connection
    except Exception as e:
        print(f"[오류] 데이터베이스 연결 실패: {e}")
        return None

def get_data(conn, table_name):
    """테이블에서 마지막 등록 날짜와 다음 인덱스를 가져오는 함수"""
    cursor = None
    
    try:
        cursor = conn.cursor()
        
        if table_name == 'epeople_all':
            sql = "SELECT register_date FROM {} WHERE answer_date not in('심사 중') ORDER BY register_date DESC LIMIT 1".format(table_name)
            cursor.execute(sql)
            df_data = cursor.fetchone()
            
            if df_data is None:
                last_date = '2000-01-01'
            else:
                last_date = df_data[0]
                # 다음 날짜 계산
                last_date = (datetime.strptime(str(last_date), '%Y-%m-%d') + timedelta(1)).strftime('%Y-%m-%d')
            
            # 다음 인덱스 조회
            sql2 = "SELECT idx FROM {} ORDER BY idx DESC LIMIT 1".format(table_name)
            cursor.execute(sql2)
            df_data2 = cursor.fetchone()
            
            if df_data2 is None:
                idx = 1
            else:
                idx = df_data2[0] + 1
            
            return last_date, idx
        
        else: # epeople_else
            sql = "SELECT region, max(register_date) FROM {} GROUP BY region".format(table_name)
            cursor.execute(sql)
            df_data = cursor.fetchall()
            
            sql2 = "SELECT idx FROM {} ORDER BY idx DESC LIMIT 1".format(table_name)
            cursor.execute(sql2)
            df_data2 = cursor.fetchone()
            
            if df_data2 is None:
                idx = 1
            else:
                idx = df_data2[0] + 1
            
            # 각 지역별 다음 날짜 계산
            region_dates = {}
            for region, date in df_data:
                if date is None:
                    # 기존 데이터가 없는 경우 기본 날짜 사용
                    region_dates[region] = '2000-01-01'
                else:
                    # 마지막 날짜의 다음 날로 설정
                    next_date = (datetime.strptime(str(date), '%Y-%m-%d') + timedelta(1)).strftime('%Y-%m-%d')
                    region_dates[region] = next_date
            
            return region_dates, idx
            
    except Exception as e:
        print(f"[오류] 데이터 조회 실패: {e}")
        return None, None
    finally:
        if cursor:
            cursor.close()
            
def db_save(df, conn, table_name):
    """데이터프레임을 테이블에 저장하는 함수"""
    if df.empty:
        return
        
    cursor = None
    try:
        cursor = conn.cursor()
        
        if table_name == 'epeople_else':
            for _, row in df.iterrows():
                sql = "INSERT INTO {}(idx, region, title, body, register_date, answer, answer_date, part) VALUES(%s, %s, %s, %s, %s, %s, %s, %s)".format(table_name)
                lists = [row['idx'], row['region'], row['제목'], row['내용'], row['작성일자'], row['답변'], row['답변일자'], row['담당부서']]
                cursor.execute(sql, lists)
                conn.commit()
        else: # 'epeople_all'
            for _, row in df.iterrows():
                sql = "INSERT INTO {}(idx, region, title, body, register_date, answer, answer_date, part) VALUES(%s, %s, %s, %s, %s, %s, %s, %s)".format(table_name)
                lists = [row['idx'], row['처리기관'], row['제목'], row['내용'], row['작성일자'], row['답변'], row['답변일자'], row['분야']]
                cursor.execute(sql, lists)
                conn.commit()
                
    except Exception as e:
        print(f"[오류] 데이터 저장 실패: {e}")
        conn.rollback()
    finally:
        if cursor:
            cursor.close()
                  
#########################################
##### 테이블별 크롤링 업데이트 코드 #######

##### epeople_all 테이블 (국민신문고 통합 사이트)
def epeople_all(conn, today):
    table_name = 'epeople_all'
    last_date, idx = get_data(conn, table_name)
    
    # 데이터베이스에 이전 데이터가 없는 경우
    if last_date == '2000-01-01':
        last_date = (datetime.strptime(today, '%Y-%m-%d') - timedelta(days=2)).strftime('%Y-%m-%d')
        # 데이터가 없는 경우 2일 전으로 설정
    
    print(f"[디버그] 크롤링 기간: {last_date} ~ {today}")
      
    # 드롭다운 지역 코드 (국민신문고 -> 지방자치단체 -> 지역 선택)
    region_code = {
        '강원도': 1,
        '경기도': 2,
        '경상남도': 3,
        '경상북도': 4,
        '광주광역시': 5,
        '대구광역시': 6,
        '대전광역시': 7,
        '부산광역시': 8,
        '서울특별시': 9,
        '세종특별자치시': 10,
        '울산광역시': 11,
        '인천광역시': 12,
        '전라남도': 13,
        '전북특별자치도': 14,
        '제주특별자치도': 15,
        '충청남도': 16,
        '충청북도': 17
    }
    result_df = pd.DataFrame(columns=['제목', '내용', '작성일자', '처리기관', '답변', '답변일자', '분야'])
      
    for key, value in region_code.items():
        print(f"[디버그] 지역 처리 중: {key} (코드: {value})")
        try:
            df = all_crawler(key, value, last_date, today)
            print(f"[디버그] {key} 지역 {len(df)}건의 데이터 발견")
            result_df = pd.concat([result_df, df], ignore_index=True)
        except Exception as e:
            print(f"[오류] {key} 크롤링 실패: {e}")
            continue
      
    result_df = result_df.sort_values(by='작성일자')
    print(f"[디버그] 전체 발견된 데이터: {len(result_df)}건")
      
    if not result_df.empty:
        index_list = list(range(idx, idx + len(result_df)))
        df = result_df.assign(idx=index_list)
        db_save(df, conn, table_name)
    else:
        print("[디버그] 업데이트할 데이터가 없습니다.")

#### epeople_else 테이블 (경상남도 새올전자민원창구)       
def epeople_else(conn, today):
    table_name = 'epeople_else'
    region_dates, idx = get_data(conn, table_name)
    result_df = pd.DataFrame(columns=['idx', 'region', 'title', 'body', 'register_date', 'answer', 'answer_date', 'part'])
    
    # 기본 URL 패턴
    BASE_URL = "https://eminwon.{}.go.kr/emwp/gov/mogaha/ntis/web/emwp/cmmpotal/action/EmwpMainMgtAction.do"
    
    # 지역별 URL 구성 정보
    regions = {
        # 경상남도 시 지역
        '창원시': {'domain': 'changwon'},
        '진주시': {'domain': 'jinju'},
        '통영시': {'domain': 'tongyeong'},
        '김해시': {'domain': 'gimhae'},
        '사천시': {'domain': 'sacheon'},
        '밀양시': {'domain': 'miryang'},
        '거제시': {'domain': 'geoje'},
        '양산시': {'domain': 'yangsan'},
        
        # 경상남도 군 지역
        '의령군': {'domain': 'uiryeong'},
        '창녕군': {'domain': 'cng'}, 
        '고성군': {'domain': 'goseong'},
        '남해군': {'domain': 'namhae'},
        '하동군': {'domain': 'hadong'},
        '산청군': {'domain': 'sancheong'},
        '함양군': {'domain': 'hygn'},  
        '합천군': {'domain': 'hc'},
        '함안군': {'custom_url': True, 
                'url': 'https://vt.haman.go.kr/emwp/gov/mogaha/ntis/web/emwp/cmmpotal/action/EmwpMainMgtAction.do'}  
    }
    
    today_obj = datetime.strptime(today, '%Y-%m-%d')
    
    for region, info in regions.items():
        # 지역이 region_dates에 없더라도 처리
        # 지역이 없는 경우 기본값인 '2000-01-01'을 사용
        last_date = region_dates.get(region, '2000-01-01')
        print(f"지역: {region}, 시작 날짜: {last_date}")
        
        # 6개월 이상 차이가 나는지 확인
        last_date_obj = datetime.strptime(last_date, '%Y-%m-%d')
        date_diff = today_obj - last_date_obj
        
        crawl_start_date = last_date
        if date_diff.days >= 180:
            crawl_start_date = (today_obj - timedelta(180)).strftime('%Y-%m-%d')
            # 6개월 이상 차이가 나는 경우 6개월 전으로 설정
        try:
            # URL 결정
            if info.get('custom_url'):
                url = info['url']
            else:
                url = BASE_URL.format(info['domain'])
            
            print(f"크롤링: {region} - {url}")
            df = crawler(url, last_date=crawl_start_date, today=today)
            
            if not df.empty:
                df['region'] = region
                result_df = pd.concat([result_df, df], ignore_index=True)
                print(f"{region}: {len(df)}건 발견")
            else:
                print(f"{region}: 데이터 없음")
        except Exception as e:
            print(f"[오류] {region} 크롤링 실패: {e}")
    
    if not result_df.empty:
        print(f"{len(result_df)}건 업데이트 합니다.")
        index_list = list(range(idx, idx + len(result_df)))
        result_df = result_df.assign(idx=index_list)
        db_save(result_df, conn, table_name)
    else:
        print("업데이트할 데이터가 없습니다.")

if __name__ == "__main__":
    print("\n메인 프로세스 시작...")
    conn = None
    try:
        conn = connect_db()
        if not conn:
            print("[오류] 데이터베이스 연결 실패. 프로그램을 종료합니다.")
            sys.exit(1)
            
        print("데이터베이스 연결 성공")
        
        # 날짜 가져오기
        _, yesterday_format = get_today_and_yesterday()
        print(f"처리할 날짜: {yesterday_format}")
        
        # epeople_all 테이블 크롤링 비활성화
        # epeople_all(conn, yesterday_format)
        # print("epeople_all 프로세스 정상 완료")
        
        # epeople_else 테이블 크롤링만 실행
        epeople_else(conn, yesterday_format)
        print("\nepeople_else 프로세스 정상 완료")
        
    except Exception as e:
        print(f"[오류] 프로세스 실패: {e}")
    finally:
        if conn:
            conn.close()
            print("데이터베이스 연결 종료")


