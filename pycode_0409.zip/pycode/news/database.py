from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from mysql.connector import pooling

# DB  접속정보 (기존 서버)
# pool = pooling.MySQLConnectionPool(pool_name="miryang_cr_pool",
#                                               pool_size=2,
#                                               pool_reset_session=True,
#                                               host='127.0.0.1',
#                                               database='ghost_2021',
#                                               user='ghostuser',
#                                               password='ghostpass!1')

# DB  접속정보 (테스트 로컬 서버)
pool = pooling.MySQLConnectionPool(
    pool_name="miryang_cr_pool",
    pool_size=2,
    pool_reset_session=True,
    host='localhost',
    port=3307,
    database='ghost_2021',
    user='root',
    password='epdlxjdpeb!1'
)

def perform_db_task(sql, fetch_one=False):
    """데이터베이스 작업을 수행하는 함수"""
    connection = None
    cursor = None
    try:
        connection = pool.get_connection()
        cursor = connection.cursor(buffered=True)
        cursor.execute(sql)
        return cursor.fetchone() if fetch_one else cursor.fetchall()
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def perform_db_task_one(sql):
    """단일 결과를 반환하는 데이터베이스 작업 수행 함수"""
    return perform_db_task(sql, fetch_one=True)

def insert_data(sql, val):
    """데이터를 삽입하는 함수"""
    connection = None
    cursor = None
    try:
        connection = pool.get_connection()
        cursor = connection.cursor(buffered=True)
        cursor.execute(sql, val)
        connection.commit()
        return cursor.lastrowid
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def query_exec(sql):
    """데이터베이스 쿼리를 실행하는 함수"""
    connection = None
    cursor = None
    try:
        connection = pool.get_connection()
        cursor = connection.cursor(buffered=True)
        cursor.execute(sql)
        connection.commit()
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def setup_webdriver():
    """웹드라이버를 설정하고 초기화하는 함수"""
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
    
    try:
        service = Service(executable_path="C:\drivers\chromedriver.exe")  # 로컬 경로에 따라 수정 필요
        driver = webdriver.Chrome(service=service, options=options)
        print("크롬드라이버 정상 초기화")
        return driver
    except Exception as e:
        raise Exception(f"크롬드라이버 초기화 실패: {e}")

# 전역 webdriver 초기화
driver = None
try:
    driver = setup_webdriver()
    print("웹드라이버 초기화 성공")
except Exception as e:
    print(f"웹드라이버 초기화 실패: {e}")