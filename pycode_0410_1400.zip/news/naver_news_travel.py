# -*- coding: utf-8 -*-
import os
import sys
import time
import re
from datetime import datetime, timedelta
import pandas as pd
import warnings
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from newspaper import Article

# 상대 경로 처리
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)

# database_utils에서 필요한 함수들 가져오기
from database_utils import connect_db, get_driver, close_driver, save_to_news_table

# 경고 숨기기
warnings.filterwarnings('ignore')

# 상수 정의
BASE_URL = "https://search.naver.com/search.naver?where=news&query=%EB%B0%80%EC%96%91+%EC%97%AC%ED%96%89&sm=tab_opt&sort=1&photo=0&field=0&pd=3&ds={}&de={}&docid=&related=0&mynews=0&office_type=0&office_section_code=0&news_office_checked=&nso=so%3Add%2Cp%3Afrom{}to{}"
MAX_PAGES = 20  # 최대 페이지 수
WAIT_TIME = 5   # 대기 시간(초)
MAX_RETRIES = 3 # 최대 재시도 횟수

def get_date_range():
    """수집할 날짜 범위 결정"""
    # 환경 변수에서 날짜 범위 가져오기
    start_date = os.environ.get('NEWS_START_DATE')
    end_date = os.environ.get('NEWS_END_DATE')
    
    # 날짜가 설정되어 있지 않은 경우 기본값 사용
    if not start_date or not end_date:
        today = datetime.now()
        end_date = today.strftime('%Y-%m-%d')
        start_date = (today - timedelta(days=2)).strftime('%Y-%m-%d')
        
    print(f"설정된 수집 기간: {start_date} ~ {end_date}")
    return start_date, end_date

def setup_database():
    """데이터베이스 연결 및 기존 URL과 제목 로드"""
    try:
        conn = connect_db()
        if not conn:
            print("[오류] 데이터베이스 연결 실패")
            return None, set(), set()
        
        # news 테이블에서 URL과 제목 로드
        cursor = conn.cursor()
        
        existing_urls = set()
        existing_titles = set()
        
        # news 테이블에서 naver_news_travel 소스의 기존 데이터 확인
        try:
            cursor.execute("SHOW TABLES LIKE 'news_%'")
            tables = [row[0] for row in cursor.fetchall()]
            
            for table in tables:
                try:
                    cursor.execute(f"SELECT url, title FROM {table} WHERE original_table = 'naver_news_travel'")
                    for row in cursor.fetchall():
                        if row[0]:  # URL이 있는 경우만
                            existing_urls.add(row[0])
                        if row[1]:  # 제목이 있는 경우만
                            existing_titles.add(row[1])
                except Exception as e:
                    print(f"[경고] {table} 테이블 조회 실패: {e}")
        except Exception as e:
            print(f"[경고] 테이블 목록 조회 실패: {e}")
        
        print(f"기존 데이터: URL {len(existing_urls)}개, 제목 {len(existing_titles)}개")
        return conn, existing_urls, existing_titles
        
    except Exception as e:
        print(f"[오류] 데이터베이스 설정 중 오류: {e}")
        if 'conn' in locals() and conn:
            try:
                conn.close()
            except:
                pass
        return None, set(), set()

def wait_for_element(driver, by, selector, timeout=10, retries=2):
    """요소가 나타날 때까지 대기하고 요소 반환 (재시도 로직 포함)"""
    for attempt in range(retries + 1):
        try:
            element = WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((by, selector))
            )
            return element
        except TimeoutException:
            if attempt < retries:
                print(f"요소를 찾지 못했습니다 ({selector}). 재시도 {attempt + 1}/{retries}")
                time.sleep(1)
            else:
                print(f"[경고] 요소를 찾을 수 없습니다: {selector}")
                return None
        except Exception as e:
            print(f"[경고] 요소 대기 중 오류 ({selector}): {e}")
            if attempt < retries:
                time.sleep(1)
            else:
                return None
    return None

def collect_news_urls(start_date, end_date):
    """네이버 뉴스 검색 결과에서 URL과 작성자 수집"""
    driver = None
    try:
        driver = get_driver()
        if not driver:
            print("[오류] 웹드라이버 초기화 실패")
            return [], []
        
        # 날짜 포맷 변경 (YYYY-MM-DD -> YYYYMMDD)
        start_date_format = start_date.replace('-', '')
        end_date_format = end_date.replace('-', '')
        
        # 네이버 검색 URL 구성
        search_url = BASE_URL.format(
            start_date, end_date, start_date_format, end_date_format
        )
        
        # 페이지 로드
        for attempt in range(MAX_RETRIES):
            try:
                driver.get(search_url)
                time.sleep(2)  # 페이지 로딩 대기
                break
            except Exception as e:
                print(f"[경고] URL 로드 중 오류 (시도 {attempt+1}/{MAX_RETRIES}): {e}")
                if attempt == MAX_RETRIES - 1:
                    print("[오류] 최대 재시도 횟수 초과")
                    return [], []
                time.sleep(2)
        
        # 결과 저장 리스트
        all_urls = []
        all_authors = []
        
        # 페이지 순회
        for page in range(1, MAX_PAGES + 1):
            try:
                # 페이지 로딩 대기
                news_list = wait_for_element(driver, By.CSS_SELECTOR, "ul.list_news", timeout=WAIT_TIME)
                if not news_list:
                    print(f"페이지 {page}에서 뉴스 목록을 찾을 수 없습니다.")
                    break
                
                time.sleep(1)  # 안정적인 로딩을 위한 추가 대기
                
                # 현재 페이지의 뉴스 목록 가져오기
                try:
                    news_items = driver.find_elements(By.CSS_SELECTOR, "ul.list_news > li.bx")
                except NoSuchElementException:
                    print(f"페이지 {page}에서 뉴스 항목을 찾을 수 없습니다.")
                    news_items = []
                
                if not news_items:
                    print(f"페이지 {page}에 뉴스 항목이 없습니다.")
                    break
                
                # 각 뉴스 항목에서 URL과 작성자 추출
                page_urls = []
                page_authors = []
                
                for item in news_items:
                    try:
                        # 링크 추출
                        link_elem = item.find_element(By.CSS_SELECTOR, "div.news_area > a.news_tit")
                        url = link_elem.get_attribute("href")
                        
                        # 언론사 추출
                        press_elem = item.find_element(By.CSS_SELECTOR, "div.news_area > div.news_info > div.info_group > a.info.press")
                        author = press_elem.text.strip()
                        
                        if url and author:
                            page_urls.append(url)
                            page_authors.append(author)
                    except Exception as e:
                        # 개별 항목 처리 실패 시 다음 항목으로 진행
                        continue
                
                # 수집된 URL 추가
                all_urls.extend(page_urls)
                all_authors.extend(page_authors)
                
                print(f"페이지 {page} 처리: {len(page_urls)}개 발견")
                
                # 다음 페이지가 있는지 확인
                if page < MAX_PAGES:
                    try:
                        next_button = driver.find_element(By.CSS_SELECTOR, "a.btn_next")
                        next_button.click()
                        time.sleep(1)  # 페이지 전환 대기
                    except:
                        print(f"다음 페이지 버튼을 찾을 수 없습니다. 수집 종료.")
                        break
                
            except Exception as e:
                print(f"[경고] 페이지 {page} 처리 중 오류: {e}")
                break
        
        print(f"총 {len(all_urls)}개 URL 수집 완료")
        return all_urls, all_authors
        
    except Exception as e:
        print(f"[오류] URL 수집 중 오류: {e}")
        return [], []
    finally:
        # 여기서는 웹드라이버를 닫지 않음 (process_news_content에서 사용하기 위함)
        pass

def clean_text(text):
    """텍스트 정제"""
    if not text:
        return ""
    
    # 불필요한 공백 및 특수문자 제거
    text = re.sub(r'\s+', ' ', text)  # 연속된 공백을 하나로
    text = re.sub(r'[\u200b\xa0]', ' ', text)  # 제로 폭 공백 및 nbsp 제거
    
    # 이메일 주소 제거
    text = re.sub(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', '', text)
    
    # URL 제거
    text = re.sub(r'https?://\S+|www\.\S+', '', text)
    
    # 특수문자 제거 (단, 한글, 영문, 숫자, 일부 문장부호는 유지)
    text = re.sub(r'[^\w\s.,?!;:\'\"\(\)\-가-힣]', '', text)
    
    # 불필요한 개행 제거
    text = re.sub(r'\n+', ' ', text)
    
    # 앞뒤 공백 제거
    text = text.strip()
    
    return text

def process_news_content(driver, urls, authors, existing_urls, existing_titles):
    """뉴스 내용 수집, 전처리 및 저장"""
    try:
        # 결과 저장용 데이터프레임 초기화
        df = pd.DataFrame(columns=['title', 'author', 'register_date', 'url', 'body', 'summary', 'status'])
        saved_count = 0
        skipped_count = 0
        error_count = 0
        
        # 각 URL별로 처리
        for i, (url, author) in enumerate(zip(urls, authors)):
            # 중복 URL 스킵
            if url in existing_urls:
                print(f"중복 URL 스킵: {url}")
                skipped_count += 1
                continue
                
            try:
                print(f"기사 {i+1}/{len(urls)} 처리 중")
                
                # 뉴스 내용 추출을 위한 재시도 로직
                article_text = None
                article_title = None
                article_date = None
                
                # newspaper로 기사 내용 추출 (최대 3회 시도)
                for attempt in range(MAX_RETRIES):
                    try:
                        article = Article(url, language='ko')
                        article.download()
                        article.parse()
                        
                        article_title = article.title
                        article_text = article.text
                        article_date = article.publish_date
                        
                        # 성공하면 루프 종료
                        break
                    except Exception as e:
                        if attempt < MAX_RETRIES - 1:
                            print(f"[경고] 기사 추출 실패 (시도 {attempt+1}/{MAX_RETRIES}): {e}")
                            time.sleep(1)
                        else:
                            print(f"[오류] 기사 추출 최대 재시도 횟수 초과: {url}")
                            raise
                
                # 필요한 데이터가 없으면 건너뜀
                if not article_title or not article_text:
                    print(f"[경고] 기사 내용이 비어 있습니다: {url}")
                    error_count += 1
                    continue
                
                # 중복 제목 스킵
                if article_title in existing_titles:
                    print(f"중복 제목 스킵: {article_title}")
                    skipped_count += 1
                    continue
                
                # 기본 정보 설정
                new_row = {
                    'url': url,
                    'author': author,
                    'title': article_title,
                    'register_date': article_date.strftime('%Y-%m-%d') if article_date else datetime.today().strftime('%Y-%m-%d'),
                    'status': 'N'
                }
                
                # 뉴시스 기사는 웹드라이버로 추가 처리
                if author == '뉴시스':
                    try:
                        driver.get(url)
                        text_elem = wait_for_element(driver, By.XPATH, '//*[@id="content"]/div[1]/div[1]/div[3]/article', timeout=10)
                        if text_elem:
                            article_text = text_elem.text
                    except Exception as e:
                        print(f"[경고] 뉴시스 기사 처리 중 오류: {e}")
                        # newspaper로 가져온 텍스트 사용
                
                # 텍스트 정제
                cleaned_text = clean_text(article_text)
                
                # 본문 및 요약 저장
                new_row['body'] = cleaned_text
                new_row['summary'] = cleaned_text[:300] + "..." if len(cleaned_text) > 300 else cleaned_text
                
                # 데이터프레임에 추가
                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
                saved_count += 1
                
                # 대기 시간
                time.sleep(0.5)
                
            except Exception as e:
                print(f"[경고] 기사 처리 중 오류 ({url}): {e}")
                error_count += 1
                continue
        
        # 중복 제거 및 데이터 정제
        df = df.drop_duplicates(subset=['url'])
        df = df.dropna(subset=['body'])
        df = df.fillna("")
        
        # 통합 뉴스 테이블에 직접 저장
        if not df.empty:
            save_conn = None
            try:
                save_conn = connect_db()
                if save_conn:
                    # save_to_news_table 함수 호출
                    total_saved = save_to_news_table(save_conn, df, 'naver_news_travel', 'register_date')
                    print(f"총 {total_saved}건의 기사가 통합 뉴스 테이블에 저장되었습니다.")
                else:
                    print("[오류] 데이터 저장을 위한 데이터베이스 연결 실패")
            except Exception as e:
                print(f"[오류] 데이터 저장 중 오류: {e}")
            finally:
                if save_conn:
                    try:
                        save_conn.close()
                    except:
                        pass
        else:
            print("저장할 새로운 기사가 없습니다.")
        
        return saved_count, skipped_count, error_count
        
    except Exception as e:
        print(f"[오류] 뉴스 처리 중 오류: {e}")
        return 0, 0, 0

def main():
    """메인 실행 함수"""
    print("네이버 여행 뉴스 크롤러 시작")
    
    # 날짜 범위 설정
    start_date, end_date = get_date_range()
    print(f"수집 기간: {start_date} ~ {end_date}")
    
    # 웹드라이버 및 데이터베이스 초기화
    driver = None
    conn = None
    
    try:
        # 데이터베이스 설정
        conn, existing_urls, existing_titles = setup_database()
        if not conn:
            print("[오류] 데이터베이스 설정 실패")
            return 1
        
        # 웹드라이버 설정
        driver = get_driver()
        if not driver:
            print("[오류] 웹드라이버 설정 실패")
            return 1
        
        # 뉴스 URL 수집
        urls, authors = collect_news_urls(start_date, end_date)
        
        if not urls:
            print("수집된 URL이 없습니다.")
            return 0
        
        # 뉴스 내용 처리 및 저장
        saved_count, skipped_count, error_count = process_news_content(
            driver, urls, authors, existing_urls, existing_titles
        )
        
        print("\n=== 크롤링 완료 ===")
        print(f"- 처리된 URL: {len(urls)}개")
        print(f"- 저장된 기사: {saved_count}개")
        print(f"- 중복 기사: {skipped_count}개")
        print(f"- 오류 발생: {error_count}개")
        
        return 0
    except Exception as e:
        print(f"[오류] 크롤러 실행 중 오류: {e}")
        return 1
    finally:
        # 리소스 정리
        if driver:
            try:
                close_driver()
                print("웹드라이버 종료 완료")
            except Exception as e:
                print(f"[경고] 웹드라이버 종료 중 오류: {e}")
                
        if conn:
            try:
                conn.close()
                print("데이터베이스 연결 종료 완료")
            except Exception:
                # 이미 닫힌 경우 무시
                pass

if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except Exception as e:
        print(f"[심각한 오류] 프로그램 실행 중 예외 발생: {e}")
        sys.exit(1)
    

