# -*- coding: utf-8 -*-
import os
import sys
import time
from datetime import datetime, timedelta
import argparse
import warnings
import subprocess
import traceback
import calendar
import re
import shutil

# 상대 경로 처리
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)

# database_utils에서 필요한 함수들 가져오기
from database_utils import connect_db

# 경고 숨기기
warnings.filterwarnings('ignore')

def run_script(script_path, env=None):
    """지정된 스크립트 실행"""
    try:
        print(f"\n=== {os.path.basename(script_path)} 실행 시작 ===")
        result = subprocess.run([sys.executable, script_path], 
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE,
                               text=True,
                               env=env)
        
        # 결과 출력
        print(f"수집 결과: {'성공' if result.returncode == 0 else '실패'}")
        
        # 상세 로그 파일 저장
        log_dir = os.path.join(parent_dir, 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        script_name = os.path.basename(script_path).replace('.py', '')
        log_file = os.path.join(log_dir, f"{script_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
        
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(result.stdout)
            f.write("\n\nSTDERR:\n")
            f.write(result.stderr)
            
        print(f"로그 파일 저장 완료: {log_file}")
        print(f"=== {os.path.basename(script_path)} 실행 완료 ===\n")
        
        return result.returncode == 0
    except Exception as e:
        print(f"[오류] {script_path} 실행 중 오류 발생: {e}")
        return False

def date_range_prompt():
    """날짜 범위 설정을 위한 대화식 인터페이스"""
    print("\n===== 날짜 범위 설정 =====")
    print("1. 오늘")
    print("2. 어제")
    print("3. 최근 3일")
    print("4. 최근 7일")
    print("5. 이번 달")
    print("6. 지난 달")
    print("7. 특정 날짜 입력")
    print("8. 날짜 범위 입력")
    
    choice = input("\n옵션을 선택하세요 (1-8): ")
    
    today = datetime.now()
    
    if choice == '1':
        # 오늘
        start_date = today.strftime('%Y-%m-%d')
        end_date = start_date
        print(f"선택한 날짜: {start_date}")
        
    elif choice == '2':
        # 어제
        yesterday = today - timedelta(days=1)
        start_date = yesterday.strftime('%Y-%m-%d')
        end_date = start_date
        print(f"선택한 날짜: {start_date}")
        
    elif choice == '3':
        # 최근 3일
        start_date = (today - timedelta(days=2)).strftime('%Y-%m-%d')
        end_date = today.strftime('%Y-%m-%d')
        print(f"선택한 날짜 범위: {start_date} ~ {end_date}")
        
    elif choice == '4':
        # 최근 7일
        start_date = (today - timedelta(days=6)).strftime('%Y-%m-%d')
        end_date = today.strftime('%Y-%m-%d')
        print(f"선택한 날짜 범위: {start_date} ~ {end_date}")
        
    elif choice == '5':
        # 이번 달
        start_date = today.replace(day=1).strftime('%Y-%m-%d')
        last_day = calendar.monthrange(today.year, today.month)[1]
        end_date = today.replace(day=last_day).strftime('%Y-%m-%d')
        print(f"선택한 날짜 범위: {start_date} ~ {end_date}")
        
    elif choice == '6':
        # 지난 달
        last_month = today.month - 1
        last_month_year = today.year
        if last_month == 0:
            last_month = 12
            last_month_year = today.year - 1
            
        last_month_date = today.replace(year=last_month_year, month=last_month, day=1)
        last_day = calendar.monthrange(last_month_year, last_month)[1]
        
        start_date = last_month_date.strftime('%Y-%m-%d')
        end_date = last_month_date.replace(day=last_day).strftime('%Y-%m-%d')
        print(f"선택한 날짜 범위: {start_date} ~ {end_date}")
        
    elif choice == '7':
        # 특정 날짜 입력
        date_input = input("날짜를 입력하세요 (YYYY-MM-DD): ")
        try:
            datetime.strptime(date_input, '%Y-%m-%d')
            start_date = date_input
            end_date = date_input
            print(f"선택한 날짜: {start_date}")
        except ValueError:
            print("유효하지 않은 날짜 형식입니다. 오늘 날짜를 사용합니다.")
            start_date = today.strftime('%Y-%m-%d')
            end_date = start_date
            
    elif choice == '8':
        # 날짜 범위 입력
        start_input = input("시작 날짜를 입력하세요 (YYYY-MM-DD): ")
        end_input = input("종료 날짜를 입력하세요 (YYYY-MM-DD): ")
        
        try:
            datetime.strptime(start_input, '%Y-%m-%d')
            datetime.strptime(end_input, '%Y-%m-%d')
            start_date = start_input
            end_date = end_input
            print(f"선택한 날짜 범위: {start_date} ~ {end_date}")
        except ValueError:
            print("유효하지 않은 날짜 형식입니다. 오늘 날짜를 사용합니다.")
            start_date = today.strftime('%Y-%m-%d')
            end_date = start_date
    else:
        print("유효하지 않은 선택입니다. 오늘 날짜를 사용합니다.")
        start_date = today.strftime('%Y-%m-%d')
        end_date = start_date
        
    return start_date, end_date

def fix_script_imports(script_path):
    """스크립트 파일의 import 문과 기타 문제 수정"""
    backup_path = script_path + '.bak'
    
    # 백업 생성
    if not os.path.exists(backup_path):
        try:
            shutil.copy2(script_path, backup_path)
            print(f"백업 파일 생성: {backup_path}")
        except Exception as e:
            print(f"[오류] 백업 생성 실패 ({script_path}): {e}")
            return False
    
    try:
        with open(script_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"[오류] 파일 읽기 실패 ({script_path}): {e}")
        return False
    
    # database_utils.py 파일 확인
    db_utils_path = os.path.join(parent_dir, 'database_utils.py')
    available_functions = []
    
    if os.path.exists(db_utils_path):
        with open(db_utils_path, 'r', encoding='utf-8') as f:
            db_utils_content = f.read()
            
        # 존재하는 함수들 확인
        function_patterns = [
            r'def\s+connect_db\s*\(',
            r'def\s+save_to_monthly_table\s*\(',
            r'def\s+save_to_news_table\s*\(',
            r'def\s+get_last_data_from_monthly_tables\s*\(',
            r'def\s+create_monthly_table\s*\(',
            r'def\s+get_driver\s*\(',
            r'def\s+close_driver\s*\(',
            r'def\s+setup_webdriver\s*\('
        ]
        
        for pattern in function_patterns:
            if re.search(pattern, db_utils_content):
                func_name = pattern.split(r'\s+')[1]
                available_functions.append(func_name)
    
    # import 문 수정
    modified = False
    
    # 기존 import 문 찾기
    import_pattern = r'from\s+database_utils\s+import\s+([^#\n]+)'
    imports_match = re.search(import_pattern, content)
    
    if imports_match:
        # 필요한 함수들 (실제 존재하는 함수들만 포함)
        required_functions = [
            'connect_db', 
            'get_driver', 
            'close_driver', 
            'save_to_news_table'
        ]
        
        required_functions = [f for f in required_functions if f in available_functions]
        
        # 모든 필요한 함수를 포함하는 새 import 문 생성
        new_import_statement = f"from database_utils import {', '.join(required_functions)}"
        
        # 기존 import 문 교체
        content = re.sub(import_pattern, new_import_statement, content)
        modified = True
    
    # 수정된 내용 저장
    if modified:
        try:
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"스크립트 파일 수정 완료: {script_path}")
            return True
        except Exception as e:
            print(f"[오류] 파일 쓰기 실패 ({script_path}): {e}")
            return False
    
    return False

def update_naver_news(script_path):
    """naver_news.py 파일 업데이트"""
    backup_path = script_path + '.bak'
    
    # 백업 생성
    if not os.path.exists(backup_path):
        try:
            shutil.copy2(script_path, backup_path)
            print(f"백업 파일 생성: {backup_path}")
        except Exception as e:
            print(f"[오류] 백업 생성 실패 ({script_path}): {e}")
            return False
    
    naver_news_code = """# -*- coding: utf-8 -*-
import os
import sys
import time
import re
from datetime import datetime, timedelta
import pandas as pd
import warnings
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from newspaper import Article

# 상대 경로 처리
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)

# database_utils에서 필요한 함수들 가져오기
from database_utils import connect_db, get_driver, close_driver, save_to_news_table, get_last_data_from_monthly_tables

# 경고 숨기기
warnings.filterwarnings('ignore')

# 상수 정의
BASE_URL = "https://search.naver.com/search.naver?where=news&query=%EB%B0%80%EC%96%91&sm=tab_opt&sort=1&photo=0&field=0&pd=3&ds={}&de={}&docid=&related=0&mynews=0&office_type=0&office_section_code=0&news_office_checked=&nso=so%3Add%2Cp%3Afrom{}to{}"
MAX_PAGES = 20  # 최대 페이지 수
WAIT_TIME = 5   # 대기 시간(초)

def get_date_range():
    \"\"\"수집할 날짜 범위 결정\"\"\"
    # 환경 변수에서 날짜 범위 가져오기
    start_date = os.environ.get('NEWS_START_DATE')
    end_date = os.environ.get('NEWS_END_DATE')
    
    # 날짜가 설정되어 있지 않은 경우 기본값 사용
    if not start_date or not end_date:
        today = datetime.now()
        end_date = today.strftime('%Y-%m-%d')
        start_date = (today - timedelta(days=2)).strftime('%Y-%m-%d')
        
    print(f"설정된 수집 기간: {start_date} ~ {end_date}")
    return start_date, end_date

def setup_database():
    \"\"\"데이터베이스 연결 및 기존 URL과 제목 로드\"\"\"
    conn = connect_db()
    if not conn:
        print("[오류] 데이터베이스 연결 실패")
        return None, set(), set()
    
    try:
        # news 테이블에서 URL과 제목 로드
        cursor = conn.cursor()
        
        existing_urls = set()
        existing_titles = set()
        
        # news 테이블에서 naver_news 소스의 기존 데이터 확인
        try:
            cursor.execute("SHOW TABLES LIKE 'news_%'")
            tables = [row[0] for row in cursor.fetchall()]
            
            for table in tables:
                try:
                    cursor.execute(f"SELECT url, title FROM {table} WHERE original_table = 'naver_news'")
                    for row in cursor.fetchall():
                        if row[0]:  # URL이 있는 경우만
                            existing_urls.add(row[0])
                        if row[1]:  # 제목이 있는 경우만
                            existing_titles.add(row[1])
                except Exception as e:
                    print(f"[경고] {table} 테이블 조회 실패: {e}")
        except Exception as e:
            print(f"[경고] 테이블 목록 조회 실패: {e}")
        
        print(f"기존 데이터: URL {len(existing_urls)}개, 제목 {len(existing_titles)}개")
        return conn, existing_urls, existing_titles
        
    except Exception as e:
        print(f"[오류] 데이터베이스 설정 중 오류: {e}")
        if conn:
            conn.close()
        return None, set(), set()

def collect_news_urls(start_date, end_date):
    \"\"\"네이버 뉴스 검색 결과에서 URL과 작성자 수집\"\"\"
    driver = get_driver()
    if not driver:
        return [], []
    
    try:
        # 날짜 포맷 변경 (YYYY-MM-DD -> YYYYMMDD)
        start_date_format = start_date.replace('-', '')
        end_date_format = end_date.replace('-', '')
        
        # 네이버 검색 URL 구성
        search_url = BASE_URL.format(
            start_date, end_date, start_date_format, end_date_format
        )
        
        driver.get(search_url)
        time.sleep(2)  # 페이지 로딩 대기
        
        # 결과 저장 리스트
        all_urls = []
        all_authors = []
        
        # 페이지 순회
        for page in range(1, MAX_PAGES + 1):
            try:
                # 페이지 로딩 대기
                WebDriverWait(driver, WAIT_TIME).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "ul.list_news"))
                )
                time.sleep(1)  # 안정적인 로딩을 위한 추가 대기
                
                # 현재 페이지의 뉴스 목록 가져오기
                news_items = driver.find_elements(By.CSS_SELECTOR, "ul.list_news > li.bx")
                
                if not news_items:
                    print(f"페이지 {page}에 뉴스 항목이 없습니다.")
                    break
                
                # 각 뉴스 항목에서 URL과 작성자 추출
                page_urls = []
                page_authors = []
                
                for item in news_items:
                    try:
                        # 링크 추출
                        link_elem = item.find_element(By.CSS_SELECTOR, "div.news_area > a.news_tit")
                        url = link_elem.get_attribute("href")
                        
                        # 언론사 추출
                        press_elem = item.find_element(By.CSS_SELECTOR, "div.news_area > div.news_info > div.info_group > a.info.press")
                        author = press_elem.text.strip()
                        
                        if url and author:
                            page_urls.append(url)
                            page_authors.append(author)
                    except Exception as e:
                        continue
                
                # 수집된 URL 추가
                all_urls.extend(page_urls)
                all_authors.extend(page_authors)
                
                print(f"페이지 {page} 처리: {len(page_urls)}개 발견")
                
                # 다음 페이지가 있는지 확인
                if page < MAX_PAGES:
                    try:
                        next_button = driver.find_element(By.CSS_SELECTOR, f"a.btn_next")
                        next_button.click()
                        time.sleep(1)  # 페이지 전환 대기
                    except:
                        print(f"다음 페이지 버튼을 찾을 수 없습니다. 수집 종료.")
                        break
                
            except Exception as e:
                print(f"[경고] 페이지 {page} 처리 중 오류: {e}")
                break
        
        print(f"총 {len(all_urls)}개 URL 수집 완료")
        return all_urls, all_authors
        
    except Exception as e:
        print(f"[오류] URL 수집 중 오류: {e}")
        return [], []

def clean_text(text):
    \"\"\"텍스트 정제\"\"\"
    if not text:
        return ""
    
    # 불필요한 공백 및 특수문자 제거
    text = re.sub(r'\\s+', ' ', text)  # 연속된 공백을 하나로
    text = re.sub(r'[\\u200b\\xa0]', ' ', text)  # 제로 폭 공백 및 nbsp 제거
    
    # 이메일 주소 제거
    text = re.sub(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}', '', text)
    
    # URL 제거
    text = re.sub(r'https?://\\S+|www\\.\\S+', '', text)
    
    # 특수문자 제거 (단, 한글, 영문, 숫자, 일부 문장부호는 유지)
    text = re.sub(r'[^\\w\\s.,?!;:\\'\\\"()\\-가-힣]', '', text)
    
    # 불필요한 개행 제거
    text = re.sub(r'\\n+', ' ', text)
    
    # 앞뒤 공백 제거
    text = text.strip()
    
    return text

def process_news_content(driver, urls, authors, existing_urls, existing_titles):
    \"\"\"뉴스 내용 수집, 전처리 및 저장\"\"\"
    try:
        # 결과 저장용 데이터프레임 초기화
        df = pd.DataFrame(columns=['title', 'author', 'register_date', 'url', 'body', 'summary', 'status'])
        saved_count = 0
        skipped_count = 0
        
        # 각 URL별로 처리
        for i, (url, author) in enumerate(zip(urls, authors)):
            # 중복 URL 스킵
            if url in existing_urls:
                print(f"중복 URL 스킵: {url}")
                skipped_count += 1
                continue
                
            try:
                print(f"기사 {i+1}/{len(urls)} 처리 중")
                
                # newspaper로 기사 내용 추출
                article = Article(url, language='ko')
                article.download()
                article.parse()
                
                # 중복 제목 스킵
                if article.title in existing_titles:
                    print(f"중복 제목 스킵: {article.title}")
                    skipped_count += 1
                    continue
                
                # 기본 정보 설정
                new_row = {
                    'url': url,
                    'author': author,
                    'title': article.title,
                    'register_date': article.publish_date.strftime('%Y-%m-%d') if article.publish_date else datetime.today().strftime('%Y-%m-%d'),
                    'status': 'N'
                }
                
                # 뉴시스 기사는 웹드라이버로 추가 처리
                if author != '뉴시스':
                    text = article.text
                else:
                    driver.get(url)
                    try:
                        text = WebDriverWait(driver, 10).until(
                            EC.presence_of_element_located((By.XPATH, '//*[@id="content"]/div[1]/div[1]/div[3]/article'))
                        ).text
                    except:
                        text = article.text  # 실패시 article의 텍스트 사용
                
                # 텍스트 정제
                cleaned_text = clean_text(text)
                
                # 본문 및 요약 저장
                new_row['body'] = cleaned_text
                new_row['summary'] = cleaned_text[:300] + "..." if len(cleaned_text) > 300 else cleaned_text
                
                # 데이터프레임에 추가
                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
                saved_count += 1
                
                # 대기 시간
                time.sleep(0.5)
                
            except Exception as e:
                print(f"[경고] 기사 처리 중 오류 ({url}): {e}")
                continue
        
        # 중복 제거 및 데이터 정제
        df = df.drop_duplicates(subset=['url'])
        df = df.dropna(subset=['body'])
        df = df.fillna("")
        
        # 통합 뉴스 테이블에 직접 저장
        if not df.empty:
            conn = None
            try:
                conn = connect_db()
                if conn:
                    # save_to_news_table 함수 호출
                    total_saved = save_to_news_table(conn, df, 'naver_news', 'register_date')
                    print(f"총 {total_saved}건의 기사가 통합 뉴스 테이블에 저장되었습니다.")
            except Exception as e:
                print(f"[오류] 데이터 저장 중 오류: {e}")
            finally:
                if conn:
                    try:
                        conn.close()
                    except:
                        pass
        else:
            print("저장할 새로운 기사가 없습니다.")
        
        return saved_count, skipped_count
        
    except Exception as e:
        print(f"[오류] 뉴스 처리 중 오류: {e}")
        return 0, 0

def main():
    \"\"\"메인 실행 함수\"\"\"
    print("네이버 뉴스 크롤러 시작")
    
    # 날짜 범위 설정
    start_date, end_date = get_date_range()
    print(f"수집 기간: {start_date} ~ {end_date}")
    
    # 데이터베이스 설정
    conn = None
    try:
        conn, existing_urls, existing_titles = setup_database()
        if not conn:
            print("[오류] 데이터베이스 설정 실패")
            return 1
        
        # 뉴스 URL 수집
        urls, authors = collect_news_urls(start_date, end_date)
        
        if not urls:
            print("수집된 URL이 없습니다.")
            if conn:
                try:
                    conn.close()
                except:
                    pass
            return 0
        
        # 뉴스 내용 처리 및 저장
        saved_count, skipped_count = process_news_content(
            get_driver(), urls, authors, existing_urls, existing_titles
        )
        
        print("\\n=== 크롤링 완료 ===")
        print(f"- 처리된 URL: {len(urls)}개")
        print(f"- 저장된 기사: {saved_count}개")
        print(f"- 중복 기사: {skipped_count}개")
        
        return 0
    except Exception as e:
        print(f"[오류] 크롤러 실행 중 오류: {e}")
        return 1
    finally:
        # 리소스 정리
        close_driver()
        if conn:
            try:
                conn.close()
            except:
                pass
        print("웹드라이버 종료 완료")

if __name__ == "__main__":
    sys.exit(main())
"""
    
    try:
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(naver_news_code)
        print(f"네이버 뉴스 스크립트 수정 완료: {script_path}")
        return True
    except Exception as e:
        print(f"[오류] 파일 쓰기 실패 ({script_path}): {e}")
        return False

def fix_all_scripts():
    """모든 스크립트 파일 수정"""
    # 크롤러 스크립트 파일 경로
    scripts = [
        os.path.join(parent_dir, 'news', 'bigkinds_news.py'),
        os.path.join(parent_dir, 'news', 'gndomin_news.py'),
        os.path.join(parent_dir, 'news', 'naver_news.py'),
        os.path.join(parent_dir, 'news', 'naver_news_travel.py')
    ]
    
    # 각 스크립트 파일 처리
    for script_path in scripts:
        if not os.path.exists(script_path):
            print(f"[경고] 스크립트를 찾을 수 없습니다: {script_path}")
            continue
            
        # naver_news.py 파일은 완전히 새로 작성
        if os.path.basename(script_path) == 'naver_news.py':
            update_naver_news(script_path)
        else:
            # 다른 파일들은 import 문만 수정
            fix_script_imports(script_path)

def main():
    """메인 실행 함수"""
    parser = argparse.ArgumentParser(description='통합 뉴스 수집')
    parser.add_argument('--interactive', '-i', action='store_true', help='대화식으로 날짜 범위 설정')
    parser.add_argument('--start-date', type=str, help='시작 날짜 (YYYY-MM-DD 형식)')
    parser.add_argument('--end-date', type=str, help='종료 날짜 (YYYY-MM-DD 형식, 기본값: 시작 날짜와 동일)')
    parser.add_argument('--debug', action='store_true', help='디버그 모드 활성화 (자세한 오류 로그)')
    parser.add_argument('--fix-scripts', action='store_true', help='크롤러 파일 자동 수정')
    args = parser.parse_args()
    
    # 디버그 모드 설정
    debug_mode = args.debug
    
    # 스크립트 파일 자동 수정
    if args.fix_scripts:
        print("크롤러 파일 자동 수정 중...")
        fix_all_scripts()
        print("크롤러 파일 수정 완료")
        return
    
    # 날짜 설정
    start_date = None
    end_date = None
    
    # 대화식 모드가 활성화되었거나 날짜 인수가 없는 경우 프롬프트 표시
    if args.interactive or (not args.start_date and not args.end_date):
        start_date, end_date = date_range_prompt()
    else:
        # 명령줄 인수에서 날짜 가져오기
        if args.start_date:
            try:
                datetime.strptime(args.start_date, '%Y-%m-%d')
                start_date = args.start_date
                
                if args.end_date:
                    datetime.strptime(args.end_date, '%Y-%m-%d')
                    end_date = args.end_date
                else:
                    end_date = start_date
                    
            except ValueError:
                today = datetime.now()
                print(f"[경고] 유효하지 않은 날짜 형식입니다. 오늘 날짜({today.strftime('%Y-%m-%d')})를 사용합니다.")
                start_date = today.strftime('%Y-%m-%d')
                end_date = start_date
        else:
            today = datetime.now()
            start_date = today.strftime('%Y-%m-%d')
            end_date = start_date
    
    log_start_time = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = os.path.join(parent_dir, 'logs', f"news_integrator_{log_start_time}.log")
    
    try:
        print(f"\n=== 뉴스 데이터 수집 시작: {start_date} ~ {end_date} ===")
        
        # 환경 변수로 날짜 전달
        env = os.environ.copy()
        env['NEWS_START_DATE'] = start_date
        env['NEWS_END_DATE'] = end_date
        
        # 크롤러 스크립트 파일 경로
        scripts = [
            os.path.join(parent_dir, 'news', 'bigkinds_news.py'),
            os.path.join(parent_dir, 'news', 'gndomin_news.py'),
            os.path.join(parent_dir, 'news', 'naver_news.py'),
            os.path.join(parent_dir, 'news', 'naver_news_travel.py')
        ]
        
        # 수집 작업 결과
        success_count = 0
        
        # 각 스크립트 실행
        for script in scripts:
            if os.path.exists(script):
                if run_script(script, env):
                    success_count += 1
            else:
                print(f"[경고] 스크립트를 찾을 수 없습니다: {script}")
        
        print(f"\n=== 모든 뉴스 수집 작업 완료: {success_count}/{len(scripts)} 성공 ===")
        
    except Exception as e:
        print(f"[오류] 프로그램 실행 중 예외 발생: {e}")
        if debug_mode:
            traceback.print_exc()
        
        # 로그 파일에 오류 기록
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n\n[오류] 프로그램 실행 중 예외 발생: {e}\n")
            if debug_mode:
                f.write(traceback.format_exc())

if __name__ == "__main__":
    main()