"""
빅카인즈(BigKinds) 뉴스 크롤러
- 경상도 지역 뉴스를 검색하여 기사 정보를 수집하고 월별 테이블에 저장
"""
import time
from datetime import datetime, timedelta
import re
import pandas as pd
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import sys
import os

# 상위 디렉토리의 모듈 import를 위한 경로 추가
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database_utils import connect_db, save_to_monthly_table, save_to_news_table, get_last_data_from_monthly_tables, create_monthly_table, setup_webdriver

# === 기본 설정 ===
BASE_TABLE = 'bigkinds_news'  # 기본 테이블명 (실제로는 bigkinds_news_년도_월 형식으로 저장)
WAIT_TIME = 10  # 웹 요소 대기 시간 (초)
# 검색 날짜 범위 - 여기에서 날짜를 조절해 데이터 양 제어
SEARCH_DAYS = 1  # 검색 기간(일 단위)

# === 데이터베이스 관련 함수 ===
def load_from_database():
    """기존 URL과 제목 데이터를 데이터베이스에서 로드하고 다음 인덱스 반환"""
    next_index = 1
    existing_urls = set()
    existing_titles = set()
    
    try:
        conn = connect_db()
        if not conn:
            print("데이터베이스 연결 실패")
            return next_index, existing_urls, existing_titles
            
        # 월별 테이블에서 최근 데이터와 다음 인덱스 조회
        latest_row, next_index = get_last_data_from_monthly_tables(conn, BASE_TABLE, 'register_date')
        
        # 월별 테이블 목록 조회 및 생성
        with conn.cursor() as cursor:
            cursor.execute(f"SHOW TABLES LIKE '{BASE_TABLE}_%'")
            tables = [row[0] for row in cursor.fetchall()]
            
            # 테이블이 없으면 현재 월에 해당하는 테이블 생성
            if not tables:
                current_date = datetime.now()
                monthly_table = f"{BASE_TABLE}_{current_date.year}_{current_date.month:02d}"
                if create_monthly_table(conn, BASE_TABLE, monthly_table):
                    print(f"[정보] 새 월별 테이블 {monthly_table} 생성 완료")
                    tables.append(monthly_table)
            
            # 각 테이블에서 URL과 제목 데이터 수집
            for table in tables:
                try:
                    # URL 수집
                    cursor.execute(f"SELECT link FROM {table} WHERE link IS NOT NULL AND link != ''")
                    existing_urls.update(row[0] for row in cursor.fetchall() if row[0])
                    
                    # 제목 수집
                    cursor.execute(f"SELECT title FROM {table} WHERE title IS NOT NULL AND title != ''")
                    existing_titles.update(row[0] for row in cursor.fetchall() if row[0])
                except Exception as e:
                    print(f"[경고] 테이블 {table} 데이터 조회 중 오류: {e}")
        
        conn.close()
        print(f"데이터베이스에서 {len(existing_urls)}개의 기존 URL과 {len(existing_titles)}개의 제목을 로드했습니다.")
        
    except Exception as e:
        print(f"데이터 로드 중 오류: {e}")
    
    return next_index, existing_urls, existing_titles

def save_to_database(df):
    """데이터프레임의 기사 정보를 월별 테이블에 저장"""
    if df.empty:
        print("저장할 데이터가 없습니다.")
        return 0, 0
        
    try:
        conn = connect_db()
        if not conn:
            print("데이터베이스 연결 실패")
            return 0, 0
            
        # 데이터프레임 컬럼 재구성
        df_to_save = df.copy()
        df_to_save = df_to_save.rename(columns={
            '출처': 'link', 
            '제목': 'title',
            '언론사': 'press',
            '내용': 'body',
            '작성일자': 'register_date'
        })
        
        # 키워드 리스트를 문자열로 변환
        df_to_save['class'] = df_to_save['키워드'].apply(
            lambda x: ', '.join(x) if isinstance(x, list) else x
        )
        
        # 사용할 컬럼만 선택
        columns = ['idx', 'title', 'press', 'class', 'register_date', 'body', 'link']
        df_to_save = df_to_save[columns]
        
        # 월별 테이블에 저장
        total_saved = save_to_monthly_table(conn, df_to_save, BASE_TABLE, 'register_date', columns)
        conn.close()
        
        print(f"{total_saved}개의 기사를 월별 테이블에 저장했습니다.")
        print(f"(기사 날짜별로 {BASE_TABLE}_년도_월 형식의 테이블에 저장됨)")
        return total_saved, len(df) - total_saved
        
    except Exception as e:
        print(f"데이터베이스 저장 중 오류 발생: {e}")
        return 0, 0

# === 브라우저 관련 유틸리티 함수 ===
def wait_for_element(driver, selector, by=By.XPATH, timeout=WAIT_TIME):
    """웹 요소 대기 및 반환"""
    return WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((by, selector))
    )

def wait_for_clickable(driver, selector, by=By.XPATH, timeout=WAIT_TIME):
    """클릭 가능한 웹 요소 대기 및 반환"""
    return WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((by, selector))
    )

def safe_click(driver, element):
    """자바스크립트로 안전하게 클릭 실행"""
    try:
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", element)
        return True
    except Exception as e:
        try:
            element.click()
            return True
        except:
            return False

def set_date_input(driver, input_id, date_value):
    """날짜 입력 필드에 값 설정"""
    try:
        date_input = wait_for_clickable(driver, input_id, by=By.ID)
        date_input.click()
        date_input.send_keys(Keys.CONTROL + "A")
        date_input.send_keys(date_value)
        date_input.send_keys(Keys.ENTER)
        time.sleep(0.5)
        return True
    except:
        return False

def close_modal(driver):
    """기사 모달 창 닫기"""
    try:
        close_button = driver.find_element(By.XPATH, '//*[@id="news-detail-modal"]//button[@aria-label="Close"]')
        safe_click(driver, close_button)
        return True
    except:
        try:
            driver.execute_script("document.querySelector('.modal-backdrop').click();")
            return True
        except:
            return False

# === 검색 및 데이터 수집 함수 ===
def setup_search_params(driver):
    """빅카인즈 검색 조건 설정 (기간, 언론사, 분류)"""
    try:
        # 1. 기간 설정 (설정된 일수만큼 과거 데이터 검색)
        date_button = wait_for_clickable(driver, '//a[contains(text(), "기간")]')
        safe_click(driver, date_button)
        
        start_date = (datetime.now() - timedelta(days=SEARCH_DAYS)).strftime("%Y-%m-%d")
        end_date = datetime.now().strftime("%Y-%m-%d")
        
        set_date_input(driver, 'search-begin-date', start_date)
        set_date_input(driver, 'search-end-date', end_date)
        
        print(f"검색 기간: {start_date} ~ {end_date} ({SEARCH_DAYS}일)")
        
        # 2. 언론사 설정 (경상도 지역 언론사)
        press_button = wait_for_clickable(driver, '//a[contains(text(), "언론사")]')
        safe_click(driver, press_button)
        time.sleep(1)

        # 지역일간지 > 경상 선택
        지역일간지_plus = wait_for_clickable(driver, '//*[@id="category_provider_group"]/li[3]/a/label/div')
        safe_click(driver, 지역일간지_plus)
        
        지역일간지_경상 = wait_for_clickable(driver, "//label[@for='do5']")
        safe_click(driver, 지역일간지_경상)

        # 지역주간지 > 경상 선택
        지역주간지_plus = wait_for_clickable(driver, '//*[@id="category_provider_group"]/li[4]/a/label/div')
        safe_click(driver, 지역주간지_plus)
        
        지역주간지_경상 = wait_for_clickable(driver, "//label[@for='dow5']")
        safe_click(driver, 지역주간지_경상)
        
        # 3. 통합 분류 설정 (정치, 경제, 사회, 문화)
        class_button = wait_for_clickable(driver, '//a[contains(text(), "통합 분류")]')
        safe_click(driver, class_button)
        time.sleep(1)

        categories = ["정치", "경제", "사회", "문화"]
        for i, category in enumerate(categories, 1):
            try:
                xpath = f"//*[@id='srch-tab3']/ul/li[{i}]/div/span[4]"
                checkbox = wait_for_clickable(driver, xpath)
                safe_click(driver, checkbox)
            except:
                continue
        
        # 4. 검색 실행
        search_button = wait_for_clickable(driver, '//*[@id="search-foot-div"]/div[2]/button[2]')
        safe_click(driver, search_button)
        time.sleep(3)  # 검색 결과 로딩 대기
        
        return True
    except Exception as e:
        print(f"검색 조건 설정 중 오류: {e}")
        return False

def extract_article_data(driver):
    """열린 기사 팝업에서 제목, 언론사, 날짜, 키워드, 내용, URL 정보를 추출"""
    article_data = {
        '제목': "제목 추출 실패",
        '언론사': "Unknown",
        '작성일자': "Unknown",
        '키워드': [],
        '내용': "",
        '출처': ""
    }
    
    # 1. 제목 추출
    try:
        title_path = '//*[@id="news-detail-modal"]/div/div/div/div[1]/div/div[1]/h1'
        title = wait_for_element(driver, title_path).text
        article_data['제목'] = title
        print(f"제목: {title}")
    except:
        pass
    
    # 2. 언론사 추출
    try:
        img_element = driver.find_element(By.XPATH, '//*[@id="chkProviderImage"]/img')
        onerror_value = img_element.get_attribute("onerror")
        
        match = re.search(r"this, ['\"]([^'\"]+)['\"]", onerror_value) or re.search(r'[\'"]([^\'"]+)[\'"]', onerror_value)
        news = match.group(1) if match else "Unknown"
        
        article_data['언론사'] = news
        print(f"언론사: {news}")
    except:
        pass
    
    # 3. 작성 날짜 추출
    try:
        date_path = '//*[@id="news-detail-modal"]/div/div/div/div[1]/div/div[1]/div[1]/ul/li[1]'
        date_text = driver.find_element(By.XPATH, date_path).text.strip()
        
        date_match = re.search(r'(\d{4}[-/]\d{1,2}[-/]\d{1,2})', date_text)
        if date_match:
            date_str = date_match.group(1)
            if '-' in date_str:
                date_parsed = date_str
            else:
                date_obj = datetime.strptime(date_str, '%Y/%m/%d')
                date_parsed = date_obj.strftime('%Y-%m-%d')
            
            article_data['작성일자'] = date_parsed
            print(f"작성일자: {date_parsed}")
    except:
        pass
    
    # 4. 키워드 추출
    try:
        keyword_path = '//*[@id="news-detail-modal"]/div/div/div/div[1]/div/div[1]/div[1]/div/span'
        keyword = driver.find_element(By.XPATH, keyword_path).text.strip()
        keyword_list = [k.strip() for k in keyword.split('|') if k.strip()]
        article_data['키워드'] = keyword_list
        print(f"키워드: {', '.join(keyword_list)}")
    except:
        pass
    
    # 5. 내용 추출
    try:
        content_element = wait_for_element(driver, 'news-view-content', by=By.CLASS_NAME)
        html_content = content_element.get_attribute('innerHTML')
        
        # HTML 태그 처리 후 텍스트 추출
        html_content = html_content.replace('<br>', '\n').replace('<br/>', '\n').replace('<br />', '\n')
        soup = BeautifulSoup(html_content, 'html.parser')
        text = soup.get_text(separator=' ', strip=True)
        
        # 텍스트 정리
        text = re.sub(r'\s+', ' ', text).strip()
        text = re.sub(r'\n\s*\n', '\n\n', text)
        
        article_data['내용'] = text
        print(f"내용 길이: {len(text)}자")
    except:
        pass
    
    # 6. 출처 URL 추출
    try:
        newsid_path = '//*[@id="news-detail-modal"]/div/div/div/div[1]/div/div[1]/div[2]/div[2]/button[7]'
        news_id = driver.find_element(By.XPATH, newsid_path).get_attribute('data-newsid')
        detail_url = f'https://www.bigkinds.or.kr/v2/news/newsDetailView.do?newsId={news_id}'
        article_data['출처'] = detail_url
        print(f"URL: {detail_url}")
    except:
        pass
    
    return article_data

# === 메인 함수 ===
def crawl_bigkinds_news():
    """빅카인즈 뉴스 크롤러 메인 함수"""
    # 초기화
    next_index, existing_urls, existing_titles = load_from_database()
    driver = setup_webdriver(headless=True)  # 헤드리스 모드로 설정
    result_df = pd.DataFrame(columns=['제목', '언론사', '작성일자', '키워드', '내용', '출처', 'idx'])
    duplicate_count = 0

    try:
        # 1. 빅카인즈 접속
        driver.get('https://www.bigkinds.or.kr/v2/news/index.do')
        time.sleep(3)

        # 2. 검색 조건 설정
        if not setup_search_params(driver):
            print("검색 조건 설정 실패. 크롤링을 종료합니다.")
            return
       
        # 3. 검색 결과 확인 - 기사 개수 파악
        total_count = 0
        try:
            for attempt in range(3):
                time.sleep(3)
                try:
                    total_count_xpath = '//*[@id="news-results-tab"]/div[2]/h3/span[6]'
                    total_count_element = wait_for_element(driver, total_count_xpath, timeout=10)
                    total_count_text = total_count_element.text.strip()
                    
                    count_match = re.search(r'[\d,]+', total_count_text)
                    if count_match:
                        total_count = int(count_match.group().replace(',', ''))
                        print(f"검색 결과: 총 {total_count}개 기사")
                        break
                except:
                    print("기사 개수 확인 실패")
        except:
            pass

        # 4. 기사 목록 가져오기
        news_items = driver.find_elements(By.CSS_SELECTOR, ".news-item")
        if not news_items:
            print("검색 결과가 없습니다.")
            return
            
        print(f"기사 목록 로드 완료: {len(news_items)}개")
            
        # 5. 첫 번째 기사 클릭하여 모달 열기
        first_title_link = news_items[0].find_element(By.CSS_SELECTOR, "a.news-detail")
        safe_click(driver, first_title_link)
        wait_for_element(driver, "news-detail-modal", by=By.ID)
        
        # 6. 기사 순차 수집
        article_count = 0
        max_articles = min(total_count, 200)  # 최대 200개 기사까지 수집
        
        print(f"총 {max_articles}개 기사를 수집합니다...")
        
        while article_count < max_articles and article_count < len(news_items):
            try:
                print(f"기사 {article_count+1}/{max_articles} 수집 중...")
                
                # 기사 데이터 추출
                article_data = extract_article_data(driver)
                
                # 중복 확인
                is_duplicate = False
                if article_data['출처'] in existing_urls:
                    print(f"중복 URL 발견: {article_data['출처']}")
                    is_duplicate = True
                    duplicate_count += 1
                elif article_data['제목'] in existing_titles:
                    print(f"중복 제목 발견: {article_data['제목']}")
                    is_duplicate = True
                    duplicate_count += 1
                
                # 유효한 데이터인 경우만 저장
                if not is_duplicate and article_data['내용'] and article_data['제목'] != "제목 추출 실패":
                    result_df = pd.concat([result_df, pd.DataFrame([article_data])], ignore_index=True)
                    print(f"데이터 추가 완료 (현재 {len(result_df)}개)")
                    
                    # 중복 체크용 세트에 추가
                    existing_urls.add(article_data['출처'])
                    existing_titles.add(article_data['제목'])
                
                # 다음 기사로 이동
                close_modal(driver)
                article_count += 1
                
                if article_count < len(news_items):
                    next_title_link = news_items[article_count].find_element(By.CSS_SELECTOR, "a.news-detail")
                    safe_click(driver, next_title_link)
                    time.sleep(2)
                else:
                    print("현재 페이지의 모든 기사를 처리했습니다.")
                    break
                
            except Exception as e:
                print(f"기사 처리 중 오류: {e}")
                try:
                    driver.refresh()
                    time.sleep(3)
                    
                    if article_count < len(news_items):
                        next_title_link = news_items[article_count].find_element(By.CSS_SELECTOR, "a.news-detail")
                        safe_click(driver, next_title_link)
                        time.sleep(2)
                        continue
                    else:
                        break
                except:
                    print("페이지 복구 실패, 수집을 종료합니다.")
                    break
        
        # 7. 수집 데이터 저장
        if not result_df.empty:
            # idx 필드 추가
            result_df['idx'] = range(next_index, next_index + len(result_df))
            
            # 데이터베이스에 저장
            saved, skipped = save_to_database(result_df)
            print("\n=== 기사 수집 및 저장 결과 ===")
            print(f"총 확인 기사: {article_count}개")
            print(f"저장된 기사: {saved}개")
            print(f"중복 기사: {duplicate_count}개")
            print(f"저장 실패: {skipped}개")
        else:
            print("\n저장할 새로운 기사가 없습니다.")

    except Exception as e:
        print(f"크롤링 중 오류 발생: {e}")

    finally:
        # 웹드라이버 종료
        try:
            if driver:
                driver.quit()
                print("웹드라이버 종료 완료")
        except:
            pass
        print("크롤링 완료")

# 스크립트가 직접 실행될 때만 크롤러 실행
if __name__ == "__main__":
    try:
        crawl_bigkinds_news()
    except Exception as e:
        print(f"프로그램 실행 중 오류: {e}")
