# -*- coding: utf-8 -*-
import time
from bs4 import BeautifulSoup
import requests
import pandas as pd
from datetime import datetime, timedelta
import warnings
import re
import sys
import os
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)
from database_utils import connect_db, save_to_monthly_table, save_to_news_table, get_last_data_from_monthly_tables, create_monthly_table
from newspaper import Article
warnings.filterwarnings('ignore')

# 기본 테이블명
BASE_TABLE = 'gndomin_news'

def setup_database():
    """데이터베이스 연결 및 마지막 수집 날짜 확인"""
    try:
        conn = connect_db()
        if not conn:
            return datetime.today() - timedelta(days=7), datetime.today(), set()
        
        try:
            # 월별 테이블에서 최근 데이터 조회
            latest_row, _ = get_last_data_from_monthly_tables(conn, BASE_TABLE, 'register_date')
            
            # 모든 월별 테이블에서 URL 조회
            with conn.cursor() as cursor:
                cursor.execute(f"SHOW TABLES LIKE '{BASE_TABLE}_%'")
                tables = [row[0] for row in cursor.fetchall()]
                
                # 테이블이 없는 경우 현재 년월에 해당하는 테이블 생성
                if not tables:
                    current_date = datetime.now()
                    monthly_table = f"{BASE_TABLE}_{current_date.year}_{current_date.month:02d}"
                    if create_monthly_table(conn, BASE_TABLE, monthly_table):
                        print(f"[정보] 새 월별 테이블 {monthly_table} 생성 완료")
                        tables.append(monthly_table)
                
                # 중복 체크를 위한 기존 URL 수집
                existing_urls = set()
                for table in tables:
                    try:
                        cursor.execute(f"SELECT url FROM {table}")
                        existing_urls.update(row[0] for row in cursor.fetchall() if row[0])
                    except Exception as e:
                        print(f"[경고] 테이블 {table} 조회 중 오류: {e}")
                        continue
            
            # 날짜 범위 설정
            if latest_row and latest_row['register_date']:
                # 마지막 수집 날짜 + 1일
                start_date = datetime.strptime(str(latest_row['register_date']), '%Y-%m-%d') + timedelta(days=1)
            else:
                # 초기값 : 최근 30일
                start_date = datetime.today() - timedelta(days=30)
            
            end_date = datetime.today()
            
            # 시간 정보 추가
            start_date = datetime.combine(start_date.date(), datetime.min.time())
            end_date = datetime.combine(end_date.date(), datetime.max.time())
            
            print(f"수집 기간: {start_date.strftime('%Y-%m-%d %H:%M:%S')} ~ {end_date.strftime('%Y-%m-%d %H:%M:%S')}")
            return start_date, end_date, existing_urls
        
        finally:
            if conn:
                conn.close()
        
    except Exception as e:
        print(f"[오류] 데이터베이스 설정 중 오류: {e}")
        return datetime.today() - timedelta(days=7), datetime.today(), set()

def clean_text(text):
    """텍스트 정제 함수"""
    remove_patterns = [
        r'▲.+?/밀양시',  # 이미지 캡션 제거
        r'저작권자 © 경남도민신문 무단전재 및 재배포 금지'  # 저작권 문구 제거
    ]
    
    # 각 패턴에 대해 제거 작업 수행
    cleaned_text = text
    for pattern in remove_patterns:
        cleaned_text = re.sub(pattern, '', cleaned_text)
    
    # 빈 줄 제거 및 양쪽 공백 제거
    cleaned_text = '\n'.join(line.strip() for line in cleaned_text.split('\n') if line.strip())
    return cleaned_text

def collect_news_by_region(region_code, region_name, start_date, end_date, existing_urls):
    """지역별 뉴스 수집"""
    try:
        articles_df = pd.DataFrame(columns=['title', 'author', 'register_date', 'url', 'body', 'area_nm'])
        
        # 페이지별 URL 수집
        url = f"http://www.gndomin.com/news/articleList.html?sc_sub_section_code={region_code}&view_type=sm"
        raw = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
        soup = BeautifulSoup(raw.text, "html.parser")
        
        # 뉴스 목록 추출
        news_items = soup.find_all('div', class_='list-block')
        
        for item in news_items:
            try:
                # 날짜 정보 추출
                date_div = item.find('div', class_='list-dated')
                if not date_div:
                    continue
                    
                date_text = date_div.text.strip()
                if not date_text:
                    continue
                
                # 날짜 형식 확인 및 추출
                date_parts = date_text.split(" | ")
                news_date = None
                
                for part in date_parts:
                    part = part.strip()
                    if '-' in part:
                        try:
                            date_str = part.split()[0]  # 공백으로 분리하여 첫 번째 부분(날짜)만 사용
                            news_date = datetime.strptime(date_str, '%Y-%m-%d')
                            break
                        except (ValueError, IndexError):
                            continue
                
                if not news_date:
                    print(f"날짜 형식 오류 (건너뛰기): {date_text}")
                    continue
                
                if start_date <= news_date <= end_date:
                    # 제목과 URL 추출
                    title_div = item.find('div', class_='list-titles')
                    if not title_div or not title_div.a:
                        continue
                        
                    article_url = "http://www.gndomin.com" + title_div.a['href']
                    
                    # 중복 체크
                    if article_url in existing_urls:
                        print(f"중복 URL 건너뛰기: {article_url}")
                        continue
                    
                    # 기사 내용 수집
                    article = Article(article_url, language='ko')
                    article.download()
                    article.parse()
                    
                    # 본문 내용 정제
                    body_text = article.text
                    body_text = clean_text(body_text)  # clean_text 함수 적용
                    
                    # 데이터프레임에 추가
                    new_row = {
                        'title': article.title,
                        'author': '경남도민신문',
                        'register_date': news_date.strftime('%Y-%m-%d'),
                        'url': article_url,
                        'body': body_text,
                        'area_nm': region_name
                    }
                    articles_df = pd.concat([articles_df, pd.DataFrame([new_row])], ignore_index=True)
                    print(f"기사 수집 완료: {article.title}")
                    
                    time.sleep(1)
                    
            except Exception as e:
                print(f"기사 수집 중 오류: {e}")
                print(f"오류 발생 URL: {item.a['href'] if item and hasattr(item, 'a') else '알 수 없음'}")
                continue
                
        return articles_df
        
    except Exception as e:
        print(f"지역 뉴스 수집 중 오류: {e}")
        return pd.DataFrame()

def main():
    """메인 실행 함수"""
    try:
        print("경남도민신문 크롤러 시작")
        
        # 초기 설정
        start_date, end_date, existing_urls = setup_database()
        
        # 지역 코드 정의
        regions = {
            "밀양": "S2N73",
            "창원": "S2N68",
            "진주": "S2N69",
            "김해": "S2N72"
            # "통영": "S2N70",
            # "사천": "S2N71",
            # "거제": "S2N74",
            # "양산": "S2N75",
            # "의령": "S2N76",
            # "함안": "S2N77",
            # "창녕": "S2N78",
            # "고성": "S2N79",
            # "남해": "S2N80",
            # "하동": "S2N81",
            # "산청": "S2N82",
            # "함양": "S2N83",
            # "거창": "S2N84",
            # "합천": "S2N85",
            # "부산": "S2N86",
        }
        
        # 전체 결과 저장용 데이터프레임
        all_articles = pd.DataFrame()
        
        # 지역별 수집
        for region_name, region_code in regions.items():
            print(f"\n{region_name} 지역 뉴스 수집 시작")
            region_df = collect_news_by_region(region_code, region_name, start_date, end_date, existing_urls)
            all_articles = pd.concat([all_articles, region_df], ignore_index=True)
        
        # 결과 저장
        if not all_articles.empty:
            # 상태 컬럼 추가
            all_articles['status'] = 'N'
            
            # 인덱스 재설정 (idx 컬럼은 auto_increment로 자동 생성)
            all_articles = all_articles.rename(columns={
                'title': 'title',
                'author': 'author',
                'register_date': 'register_date',
                'url': 'url',
                'body': 'body',
                'area_nm': 'area_nm'
            })
            
            # DB 저장 (월별 테이블)
            conn = connect_db()
            if conn:
                try:
                    columns = ['title', 'author', 'register_date', 'url', 'body', 'area_nm', 'status']
                    saved_count = save_to_monthly_table(conn, all_articles, BASE_TABLE, 'register_date', columns)
                    print(f"\n=== 크롤링 완료 (총 {len(all_articles)}개 수집, {saved_count}개 저장) ===")
                finally:
                    conn.close()
        else:
            print("\n=== 수집된 새로운 기사가 없습니다 ===")
            
    except Exception as e:
        print(f"크롤러 실행 중 오류: {e}")

if __name__ == "__main__":
    main()

