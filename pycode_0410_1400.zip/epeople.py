# -*- coding: utf-8 -*-
import re, time, os, sys
import pandas as pd
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import warnings
import concurrent.futures

# 상대 경로 처리
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)
from database_utils import connect_db, save_to_monthly_table, get_last_data_from_monthly_tables

# 경고 숨기기
warnings.filterwarnings('ignore')

# 기본 테이블명과 지연 시간
BASE_TABLE = 'epeople'
DELAY_TIME = 0.5  
MAX_WORKERS = 3   # 병렬 처리할 지역 수


def setup_webdriver(headless=True):
    """크롬 웹드라이버 설정 및 초기화"""
    try:
        options = webdriver.ChromeOptions()
        if headless:
            options.add_argument('--headless')
        
        # 성능 개선을 위한 추가 설정
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-infobars')
        options.add_argument('--disable-notifications')
        options.add_argument('--blink-settings=imagesEnabled=false')  # 이미지 로딩 비활성화
        options.add_argument('--disk-cache-size=52428800')  # 캐시 크기 50MB 설정
        options.add_argument('--page-cache')
        options.add_experimental_option('excludeSwitches', ['enable-logging'])
        options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
        
        # 페이지 로드 전략 변경 - EAGER: DOM 구조만 로드되면 진행 (이미지 등 완전한 로드 대기 안함)
        options.page_load_strategy = 'eager'
        
        service = Service(executable_path="C:\drivers\chromedriver.exe")
        driver = webdriver.Chrome(service=service, options=options)
        
        # 타임아웃 설정: 페이지 로드 30초, 스크립트 10초
        driver.set_page_load_timeout(30)
        driver.set_script_timeout(10)
        
        print("크롬드라이버 정상 초기화")
        return driver
    except Exception as e:
        print(f"[오류] 크롬드라이버 초기화 실패: {e}")
        return None


def get_next_date(date_str, format='%Y-%m-%d'):
    """날짜에 1일 더하기"""
    date_obj = datetime.strptime(date_str, format)
    next_date = date_obj + timedelta(days=1)
    return next_date.strftime(format)


def get_today_and_yesterday():
    """오늘과 어제 날짜 반환"""
    today = datetime.now()
    yesterday = today - timedelta(days=1)
    return today.strftime('%Y-%m-%d'), yesterday.strftime('%Y-%m-%d')


def wait_for_element(driver, by, selector, timeout=10):
    """명시적 대기 방식으로 요소가 로드될 때까지 기다림"""
    try:
        element = WebDriverWait(driver, timeout).until(
            EC.presence_of_element_located((by, selector))
        )
        return element
    except Exception as e:
        print(f"[경고] 요소 대기 시간 초과: {selector}, {e}")
        return None


def all_crawler(key, value, last_date, today, headless=True):
    """국민신문고 데이터 크롤링"""
    driver = None
    try:
        print(f"크롤링 시작: {key}, {last_date} ~ {today}")
        driver = setup_webdriver(headless=headless)
        url = 'https://www.epeople.go.kr/nep/prpsl/opnPrpl/opnpblPrpslList.npaid'
        driver.get(url)

        # 페이지 설정: 50개 보기
        select = Select(wait_for_element(driver, By.ID, "listCnt"))
        select.select_by_index(4)

        # 지방자치단체 선택
        select_agency = Select(wait_for_element(driver, By.ID, "searchCd"))
        select_agency.select_by_index(2)
        time.sleep(DELAY_TIME)

        # 지역 선택
        select_area = Select(wait_for_element(driver, By.NAME, "searchInstCd"))
        select_area.select_by_index(value)

        # 날짜 설정
        start_date = wait_for_element(driver, By.NAME, "rqstStDt")
        start_date.clear()
        start_date.send_keys(last_date)

        end_date = wait_for_element(driver, By.NAME, "rqstEndDt")
        end_date.clear()
        end_date.send_keys(today)

        # 검색 버튼 클릭
        search_button_xpath = '//*[@id="frm"]/div[1]/div[1]/div[4]/button[1]'
        wait_for_element(driver, By.XPATH, search_button_xpath).click()
        time.sleep(DELAY_TIME)

        # 데이터 건수 확인 (결과 나올 때까지 대기)
        total_element = wait_for_element(driver, By.XPATH, '//*[@id="frm"]/div[2]/span/span')
        total = "0" if not total_element else total_element.text
        print(f"데이터 건수: {total}")
        
        # 결과가 없으면 바로 반환
        if total == "0":
            print(f"{key} 지역 데이터 없음")
            return pd.DataFrame()

        # 페이지네이션 정보 확인
        pagination = wait_for_element(driver, By.XPATH, '//*[@id="frm"]/div[3]')
        html_content = pagination.get_attribute('innerHTML')
        page_numbers = re.findall(r'frmPageLink\((\d+)\)', html_content)
            
        if page_numbers:
            page_count = max(map(int, page_numbers))
            print(f"마지막 페이지 번호: {page_count}")
        else:
            page_count = 1

        # 결과 데이터프레임 초기화
        result_df = pd.DataFrame(columns=['제목', '내용', '작성일자', '답변', '답변일자', '처리기관', '분야'])

        # 페이지별 크롤링
        current_page = 1
        while current_page <= page_count:
            print(f"{current_page}/{page_count} 페이지 처리 중...")
            
            try:
                # 테이블 데이터 추출
                table = wait_for_element(driver, By.CLASS_NAME, 'tbl.default.brd1')
                tbody = table.find_element(By.TAG_NAME, "tbody")
                rows = tbody.find_elements(By.TAG_NAME, "tr")
                
                # 각 행의 데이터 추출
                for i in range(1, len(rows) + 1):
                    try:
                        # 게시물 클릭
                        complain_list = f'//*[@id="frm"]/table/tbody/tr[{i}]/td[2]/a'
                        wait_for_element(driver, By.XPATH, complain_list).click()
                        
                        # 상세 정보 가져오기 - 모든 데이터를 한 번에 수집하려고 시도
                        try:
                            title = wait_for_element(driver, By.XPATH, '//*[@id="txt"]/div[1]/div/div[1]/div[1]').text
                            text = wait_for_element(driver, By.XPATH, '//*[@id="txt"]/div[1]/div/div[3]').text
                            date = wait_for_element(driver, By.XPATH, '//*[@id="txt"]/div[1]/div/div[4]/div[2]').text
                            depart = wait_for_element(driver, By.XPATH, '//*[@id="txt"]/div[1]/div/div[2]/div[2]').text
                            part = wait_for_element(driver, By.XPATH, '//*[@id="txt"]/div[1]/div/div[2]/div[1]').text
                            
                            # 답변 정보는 없을 수도 있음 (오류 발생 가능성 높음)
                            try:
                                answer = wait_for_element(driver, By.XPATH, '//*[@id="txt"]/div[2]/div[1]/div[3]', timeout=2).text
                            except:
                                answer = "답변 전"
                                
                            try:
                                ans_date = wait_for_element(driver, By.XPATH, '//*[@id="txt"]/div[2]/div/div/div[2]', timeout=2).text
                            except:
                                ans_date = ""
                                
                        except Exception as detail_e:
                            # 기본값 설정
                            title = "제목 없음"
                            text = "내용 없음"
                            date = ""
                            depart = "처리기관 정보 없음"
                            answer = "답변 전"
                            ans_date = ""
                            part = "분야 정보 없음"
                            print(f"[경고] 상세 정보 추출 오류: {detail_e}")
                        
                        # 데이터프레임에 추가
                        new_row = pd.DataFrame({
                            '제목': [title],
                            '내용': [text],
                            '작성일자': [date],
                            '처리기관': [depart],
                            '답변': [answer],
                            '답변일자': [ans_date],
                            '분야': [part]
                        })
                        result_df = pd.concat([result_df, new_row], ignore_index=True)
                        
                        # 뒤로 가기
                        driver.back()
                    
                    except Exception as e:
                        print(f"[오류] {i}번째 행 처리 중 오류: {e}")
                        try:
                            # 페이지 상태 복구 시도
                            driver.back()
                        except:
                            # 페이지 새로고침 시도
                            driver.refresh()
                            wait_for_element(driver, By.CLASS_NAME, 'tbl.default.brd1')
                        continue
                
                # 다음 페이지로 이동
                current_page += 1
                if current_page <= page_count:
                    try:
                        driver.execute_script(f"frmPageLink({current_page})")
                        # 다음 페이지 로드 확인을 위해 테이블 요소 대기
                        wait_for_element(driver, By.CLASS_NAME, 'tbl.default.brd1')
                    except Exception as e:
                        print(f"[오류] 페이지 이동 실패: {e}")
            
            except Exception as e:
                print(f"[오류] 페이지 처리 중 오류: {e}")
                # 페이지 새로고침 시도
                driver.refresh()
                # 계속 진행할 수 없으면 break
                if current_page >= page_count:
                    break
                # 아니면 다음 페이지로 시도
                current_page += 1

        # 지역 정보 추가 및 결과 반환
        result_df['region'] = key
        print(f"{key} 크롤링 완료: {len(result_df)}건")
        return result_df

    except Exception as e:
        print(f"[오류] 크롤링 실패: {e}")
        return pd.DataFrame()
    finally:
        if driver:
            driver.quit()


def get_data(conn, base_table=BASE_TABLE):
    """최근 등록 날짜와 다음 인덱스 조회"""
    latest_row, next_idx = get_last_data_from_monthly_tables(conn, base_table, 'register_date')
    
    if not latest_row:
        # 데이터가 없는 경우 기본값 반환
        return '2000-01-01', next_idx, None
    
    # 객체 타입에 따라 날짜 필드에 접근하는 방법 변경 (오류 수정)
    register_date = None
    latest_table = None
    
    # 딕셔너리인 경우
    if isinstance(latest_row, dict):
        register_date = latest_row.get('register_date')
        latest_table = latest_row.get('source_table')
    # 튜플인 경우 - 인덱스로 접근 (테이블 구조에 맞게 조정 필요)
    elif isinstance(latest_row, tuple):
        # epeople 테이블 구조: idx, region, title, body, register_date, answer, answer_date, part, status
        register_date = latest_row[4]  # register_date가 5번째 필드 (색인 4)
        if len(latest_row) > 9:  # source_table이 맨 마지막에 추가됨
            latest_table = latest_row[-1]
    
    if not register_date:
        return '2000-01-01', next_idx, None
    
    # 마지막 날짜의 다음 날로 설정
    last_date = (datetime.strptime(str(register_date), '%Y-%m-%d') + timedelta(1)).strftime('%Y-%m-%d')
    
    return last_date, next_idx, latest_table


def process_region(key, value, last_date, today):
    """개별 지역 처리 함수 (병렬 처리용)"""
    try:
        print(f"[병렬 처리] {key} 지역 시작")
        df = all_crawler(key, value, last_date, today, headless=True)
        print(f"[병렬 처리] {key} 지역 완료: {len(df)}건")
        return df
    except Exception as e:
        print(f"[오류] {key} 지역 병렬 처리 중 오류: {e}")
        return pd.DataFrame()


def epeople_all(conn, today):
    """국민신문고 통합 사이트 크롤링 및 데이터 저장"""
    base_table = BASE_TABLE
    last_date, idx, latest_table = get_data(conn, base_table)
    
    # 데이터베이스에 이전 데이터가 없는 경우 2일 전으로 설정
    if last_date == '2000-01-01':
        last_date = (datetime.strptime(today, '%Y-%m-%d') - timedelta(days=2)).strftime('%Y-%m-%d')
    
    print(f"[정보] 크롤링 기간: {last_date} ~ {today}")
    if latest_table:
        print(f"[정보] 최근 데이터가 저장된 테이블: {latest_table}")
    else:
        print("[정보] 최근 데이터가 저장된 테이블 없음")
      
    # 국민신문고 지방자치단체 지역 코드
    region_code = {
        '강원도': 1, '경기도': 2, '경상남도': 3, '경상북도': 4,
        '광주광역시': 5, '대구광역시': 6, '대전광역시': 7, '부산광역시': 8,
        '서울특별시': 9, '세종특별자치시': 10, '울산광역시': 11, '인천광역시': 12,
        '전라남도': 13, '전북특별자치도': 14, '제주특별자치도': 15, 
        '충청남도': 16, '충청북도': 17
    }
    
    result_df = pd.DataFrame(columns=['제목', '내용', '작성일자', '처리기관', '답변', '답변일자', '분야', 'region'])
    
    start_time = datetime.now()
    print(f"[정보] 크롤링 시작 시간: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 병렬 처리로 지역별 크롤링 실행
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # 지역별 작업 제출
        future_to_region = {
            executor.submit(process_region, key, value, last_date, today): key
            for key, value in region_code.items()
        }
        
        # 결과 수집
        for future in concurrent.futures.as_completed(future_to_region):
            region_name = future_to_region[future]
            try:
                df = future.result()
                if not df.empty:
                    result_df = pd.concat([result_df, df], ignore_index=True)
                    print(f"[정보] {region_name} 지역 {len(df)}건 병합 완료")
            except Exception as e:
                print(f"[오류] {region_name} 지역 결과 처리 중 오류: {e}")
    
    end_time = datetime.now()
    elapsed_time = end_time - start_time
    print(f"[정보] 크롤링 완료 시간: {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"[정보] 총 소요 시간: {elapsed_time.total_seconds()/60:.2f}분")
    
    # 날짜순 정렬
    result_df = result_df.sort_values(by='작성일자')
    print(f"[정보] 전체 발견된 데이터: {len(result_df)}건")
      
    # 데이터 저장
    if not result_df.empty:
        # idx 추가
        index_list = list(range(idx, idx + len(result_df)))
        df = result_df.assign(idx=index_list)
        
        # 컬럼 매핑
        df_renamed = df.rename(columns={
            '제목': 'title', '내용': 'body', '작성일자': 'register_date',
            '답변': 'answer', '답변일자': 'answer_date', 
            '처리기관': 'region', '분야': 'part'
        })
        
        # 상태 컬럼 추가
        df_renamed['status'] = 'N'
        
        # 월별 테이블에 저장
        columns = ['idx', 'region', 'title', 'body', 'register_date', 'answer', 'answer_date', 'part', 'status']
        saved_count = save_to_monthly_table(conn, df_renamed, base_table, 'register_date', columns)
        print(f"[정보] 총 {saved_count}건 저장 완료")
    else:
        print("[정보] 업데이트할 데이터가 없습니다.")


# 메인 실행 코드
if __name__ == "__main__":
    print("\n메인 프로세스 시작...")
    conn = None
    try:
        conn = connect_db()
        if not conn:
            print("[오류] 데이터베이스 연결 실패. 프로그램을 종료합니다.")
            sys.exit(1)
            
        print("데이터베이스 연결 성공")
        
        # 어제 날짜로 크롤링 실행
        _, yesterday_format = get_today_and_yesterday()
        print(f"처리할 날짜: {yesterday_format}")
        
        epeople_all(conn, yesterday_format)
        print("epeople_all 프로세스 정상 완료")
        
    except Exception as e:
        print(f"[오류] 프로세스 실패: {e}")
    finally:
        if conn:
            conn.close()
            print("데이터베이스 연결 종료")

