from codecs import ignore_errors
from telnetlib import Telnet
from turtle import title
from bs4 import BeautifulSoup
from matplotlib.textpath import text_to_path
import requests, json, re, time, datetime, random
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import numpy as np
from tqdm import tqdm
import csv
import sys
import os
import warnings
from chrome_version import get_chrome_driver, DELAY_TIME
warnings.filterwarnings('ignore')




def answer_crawler(last_date, today):
    driver = None
    try:
        driver = get_chrome_driver()
        print("[디버그] 답변 크롤링 시작")
        # header = {'User-Agent': ''}
        # driver = webdriver.Chrome('./chromedriver.exe') 
        #driver.implicitly_wait(3)
        
        
        url = 'https://www.epeople.go.kr/nep/pttn/gnrlPttn/pttnSmlrCaseList.npaid'

        driver.get(url)


        req = requests.get(url,verify=False)
        html = req.text 
        soup = BeautifulSoup(html, "html.parser")

        from selenium.webdriver.support.select import Select

        select = Select(driver.find_element(By.ID, "listCnt"))
        select.select_by_index(4) #50개보기 선택

        time.sleep(DELAY_TIME)

        start_date= driver.find_element(By.NAME, "rqstStDt")
        start_date.clear()  
        start_date.send_keys(last_date) #시작날짜 입력
        ####################################################
        end_date= driver.find_element(By.NAME, "rqstEndDt")
        end_date.clear()  
        end_date.send_keys(today) #종료날짜 입력
 
        select_button = f'/html/body/div[3]/main/div/section/article/form[2]/div[1]/div[1]/div[4]/button[1]'
        driver.find_element(By.XPATH, select_button).click() #검색 클릭
        time.sleep(DELAY_TIME)
        total = driver.find_element(By.XPATH, f'//*[@id="frm"]/div[2]/span/span').text
        total = total.replace(',', "")
        print('데이터건 수 : ', total) 

        if int(total) <= 500:
              page_count = driver.find_element(By.XPATH, f'//*[@id="frm"]/div[2]/span').text
              page_count = page_count.replace(')', "")
              page_count = page_count[-1]
              print('페이지 수 : ', page_count)
              page_button = f'/html/body/div[3]/main/div/section/article/form[2]/div[3]/span[3]/a'

        else:
              page_count = driver.find_element(By.XPATH, f'//*[@id="frm"]/div[3]/a[10]').text
              print('페이지 수(10페이지 초과) : ', page_count)
              page_button = f'/html/body/div[3]/main/div/section/article/form[2]/div[3]/span[4]/a'
              
        result_df = pd.DataFrame(columns=['제목', '내용', '작성일자', '답변', '답변일자', '처리기관'])
        
        for n in  range(0, int(page_count)):
              if n == 0:
                    table = driver.find_element(By.CLASS_NAME, 'tbl.default.brd1')
                    tbody = table.find_element(By.TAG_NAME, "tbody")
                    rows = tbody.find_elements(By.TAG_NAME, "tr")
                    for i in range(1, int(len(rows))+1):
                          try:
                                complain_list = f'//*[@id="frm"]/table/tbody/tr[{i}]/td[2]/a'
                                driver.find_element(By.XPATH, complain_list).click()
                                time.sleep(DELAY_TIME)
                                mw= driver.find_element(By.CLASS_NAME, 'samBox.mw')
                                title = mw.find_element(By.CLASS_NAME, "samC_top").text
                                try:
                                      text = mw.find_element(By.CLASS_NAME, "samC_c").text
                                except:
                                      text = ""
                                date = mw.find_element(By.CLASS_NAME, "samC_date").text
                                depart = driver.find_element(By.XPATH, f'//html/body/div[3]/main/div/section/article/div[1]/div[2]/div/div[2]/ul/li[1]/dl/dd').text
                                ans= driver.find_element(By.CLASS_NAME, 'samBox.ans')
                                ans_date = ans.find_element(By.CLASS_NAME, "samC_date").text
                                answer = ans.find_element(By.CLASS_NAME, "samC_top").text
                                answer = answer.replace(ans_date, "")
                                new_row = pd.DataFrame({
                                    '제목': [title], 
                                    '내용': [text], 
                                    '작성일자': [date], 
                                    '답변': [answer], 
                                    '답변일자': [ans_date], 
                                    '처리기관': [depart]
                                })
                                result_df = pd.concat([result_df, new_row], ignore_index=True)
                                time.sleep(DELAY_TIME)
                                driver.back() 
                          except Exception as e:
                                print(f"[오류] 게시물 처리 중 오류: {e}")
                                pass
              else:
                    driver.find_element(By.XPATH, page_button).click() #페이지 클릭      
                    time.sleep(DELAY_TIME) 
                    table = driver.find_element(By.CLASS_NAME, 'tbl.default.brd1')
                    tbody = table.find_element(By.TAG_NAME, "tbody")
                    rows = tbody.find_elements(By.TAG_NAME, "tr")
                    for i in range(1, int(len(rows))+1):
                          try:
                                complain_list = f'//*[@id="frm"]/table/tbody/tr[{i}]/td[2]/a'
                                driver.find_element(By.XPATH, complain_list).click()
                                time.sleep(DELAY_TIME) 
                                try: 
                                      mw= driver.find_element(By.CLASS_NAME, 'samBox.mw')
                                      title = mw.find_element(By.CLASS_NAME, "samC_top").text
                                      try:
                                            text = mw.find_element(By.CLASS_NAME, "samC_c").text
                                      except:
                                            text = ""
                                      date = mw.find_element(By.CLASS_NAME, "samC_date").text
                                      depart = driver.find_element(By.XPATH, f'//html/body/div[3]/main/div/section/article/div[1]/div[2]/div/div[2]/ul/li[1]/dl/dd').text
                                      ans= driver.find_element(By.CLASS_NAME, 'samBox.ans')
                                      ans_date = ans.find_element(By.CLASS_NAME, "samC_date").text
                                      answer = ans.find_element(By.CLASS_NAME, "samC_top").text
                                      answer = answer.replace(ans_date, "")
                                      new_row = pd.DataFrame({
                                          '제목': [title], 
                                          '내용': [text], 
                                          '작성일자': [date], 
                                          '답변': [answer], 
                                          '답변일자': [ans_date], 
                                          '처리기관': [depart]
                                      })
                                      result_df = pd.concat([result_df, new_row], ignore_index=True)
                                      time.sleep(DELAY_TIME)
                                      driver.back()
                                except: #비공개처리한 글 에러 발생 
                                      close_button = f'/html/body/div[7]/div/div[2]/button'
                                      driver.find_element(By.XPATH, close_button).click() 
                                      pass
                          except Exception as e:
                                print(f"[오류] 게시물 처리 중 오류: {e}")
                                pass
        return result_df
    except Exception as e:
        print(f"[오류] 답변 크롤링 실패: {e}")
        return pd.DataFrame()
    finally:
        if driver:
            driver.quit()
