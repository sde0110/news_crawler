from bs4 import BeautifulSoup
import requests, json, re, time, datetime
from datetime import datetime
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import numpy as np
import csv
import sys
import os
import warnings
from chrome_version import get_chrome_driver, DELAY_TIME
warnings.filterwarnings('ignore')


def crawler(url, url2=None, last_date=None, today=None):
    """
    국민신문고 크롤링 함수
    
    Args:
        url (str): 크롤링 대상 URL
        url2 (str, optional): 두 번째 URL (필요한 경우)
        last_date (str): 시작 날짜 (YYYY-MM-DD 형식)
        today (str): 종료 날짜 (YYYY-MM-DD 형식)
        
    Returns:
        pd.DataFrame: 크롤링된 데이터를 담은 데이터프레임
    """
    driver = None
    try:
        driver = get_chrome_driver()
        print(f"[디버그] 크롤링 시작: {url}")
        
        # URL 접속
        driver.get(url)
        time.sleep(DELAY_TIME)
        
        # 날짜 입력
        if last_date and today:
            try:
                # 시작일 입력
                start_date = driver.find_element(By.NAME, "search_start_date")
                start_date.clear()
                start_date.send_keys(last_date)
                
                # 종료일 입력
                end_date = driver.find_element(By.NAME, "search_end_date")
                end_date.clear()
                end_date.send_keys(today)
                
                # 검색 버튼 클릭
                search_button = driver.find_element(By.CLASS_NAME, "btn_search")
                search_button.click()
                time.sleep(DELAY_TIME)
            except Exception as e:
                print(f"[오류] 검색 폼 처리 실패: {e}")
        
        # 결과 데이터프레임 초기화
        df = pd.DataFrame(columns=['제목', '내용', '작성일자', '답변', '답변일자', '담당부서'])
        
        # 총 페이지 수 확인
        try:
            paging = driver.find_element(By.CLASS_NAME, "paging")
            page_links = paging.find_elements(By.TAG_NAME, "a")
            total_pages = int(page_links[-1].text) if page_links else 1
        except:
            total_pages = 1
            
        print(f"[디버그] 총 {total_pages}페이지 크롤링 예정")
        
        current_page = 1
        while current_page <= total_pages:
            try:
                # 게시물 목록 가져오기
                rows = driver.find_elements(By.CSS_SELECTOR, "table.board_list tr")
                
                if len(rows) <= 1:  # 헤더만 있는 경우
                    print("[디버그] 데이터가 없습니다.")
                    break
                
                # 각 게시물 처리
                for row in rows[1:]:  # 헤더 제외
                    try:
                        # 게시물 클릭하여 상세 페이지 열기
                        title_link = row.find_element(By.CSS_SELECTOR, "td.title a")
                        title_link.click()
                        time.sleep(DELAY_TIME)
                        
                        # 상세 페이지에서 데이터 추출
                        title = driver.find_element(By.CSS_SELECTOR, ".detail_title").text
                        content = driver.find_element(By.CSS_SELECTOR, ".detail_content").text
                        reg_date = driver.find_element(By.CSS_SELECTOR, ".reg_date").text
                        department = driver.find_element(By.CSS_SELECTOR, ".department").text
                        
                        # 답변이 있는 경우 추출
                        try:
                            answer = driver.find_element(By.CSS_SELECTOR, ".answer_content").text
                            answer_date = driver.find_element(By.CSS_SELECTOR, ".answer_date").text
                        except:
                            answer = "답변 없음"
                            answer_date = ""
                        
                        # 데이터프레임에 추가
                        new_row = pd.DataFrame({
                            '제목': [title],
                            '내용': [content],
                            '작성일자': [reg_date],
                            '답변': [answer],
                            '답변일자': [answer_date],
                            '담당부서': [department]
                        })
                        df = pd.concat([df, new_row], ignore_index=True)
                        
                        # 목록으로 돌아가기
                        driver.back()
                        time.sleep(DELAY_TIME)
                        
                    except Exception as e:
                        print(f"[오류] 게시물 처리 중 오류: {e}")
                        try:
                            driver.back()  # 오류 발생 시 목록으로 돌아가기
                            time.sleep(DELAY_TIME)
                        except:
                            pass
                
                # 다음 페이지로 이동
                current_page += 1
                if current_page <= total_pages:
                    try:
                        next_page = driver.find_element(By.XPATH, f"//a[contains(text(),'{current_page}')]")
                        next_page.click()
                        time.sleep(DELAY_TIME)
                    except:
                        print(f"[오류] 페이지 {current_page}로 이동 실패")
                        break
                
            except Exception as e:
                print(f"[오류] 페이지 처리 중 오류: {e}")
                break
        
        print(f"[디버그] 크롤링 완료: {len(df)}개 게시물")
        return df
        
    except Exception as e:
        print(f"[오류] 크롤링 실패: {e}")
        return pd.DataFrame()
    finally:
        if driver:
            driver.quit()



