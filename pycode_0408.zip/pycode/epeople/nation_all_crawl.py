from codecs import ignore_errors
from telnetlib import Telnet
from turtle import title
from bs4 import BeautifulSoup
import requests, json, re, time, datetime, random
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import WebDriverWait
import pandas as pd
import numpy as np
from tqdm import tqdm
import csv
import sys
import os
import warnings
from chrome_version import get_chrome_driver, DELAY_TIME
warnings.filterwarnings('ignore')

def all_crawler(key, value, last_date, today):
    driver = None
    try:
        driver = get_chrome_driver()
        url = 'https://www.epeople.go.kr/nep/prpsl/realize/selectXclncPrpslList.npaid'
        driver.get(url)

        # 페이지 설정: 50개 보기 선택
        select = Select(driver.find_element(By.ID, "listCnt"))
        select.select_by_index(4)  # 50개보기 선택

        # 지방자치단체 선택
        select_agency = Select(driver.find_element(By.ID, "searchCd"))
        select_agency.select_by_index(2)  # 2. 지방자치단체

        time.sleep(1)

        # 지역 선택
        select_area = Select(driver.find_element(By.NAME, "searchInstCd"))
        select_area.select_by_index(value)

        # 날짜 설정
        start_date = driver.find_element(By.NAME, "rqstStDt")
        start_date.clear()
        start_date.send_keys(last_date)

        end_date = driver.find_element(By.NAME, "rqstEndDt")
        end_date.clear()
        end_date.send_keys(today)

        # 검색 버튼 클릭
        select_button = f'//*[@id="frm"]/div[1]/div[3]/div[2]/button'
        driver.find_element(By.XPATH, select_button).click()
        time.sleep(2)

        # 데이터 건수 확인
        total = driver.find_element(By.XPATH, f'//*[@id="frm"]/div[2]/span/span').text

        # 페이지 수 확인
        page_count = driver.find_element(By.XPATH, f'//*[@id="frm"]/div[3]').text

        # 결과 데이터프레임 초기화
        result_df = pd.DataFrame(columns=['제목', '내용', '작성일자', '답변', '답변일자', '처리기관'])

        # 페이지별 크롤링
        for n in range(0, int(page_count[-1])):
            if n == 0:
                page_button = f'//*[@id="frm"]/div[3]/strong/a'
                driver.find_element(By.XPATH, page_button).click()
            else:
                time.sleep(3)
                try:
                    page_button = f'//*[@id="frm"]/div[3]/span[3]'
                    driver.find_element(By.XPATH, page_button).click()
                except:
                    page_button = f'//*[@id="frm"]/div[3]/span[3]/a[{n}]'
                    driver.find_element(By.XPATH, page_button).click()
                    continue

            # 테이블 데이터 추출
            table = driver.find_element(By.CLASS_NAME, 'tbl.default.brd1')
            tbody = table.find_element(By.TAG_NAME, "tbody")
            rows = tbody.find_elements(By.TAG_NAME, "tr")

            # 각 행의 데이터 추출
            for i in range(1, int(len(rows)) + 1):
                complain_list = f'//*[@id="frm"]/table/tbody/tr[{i}]/td[2]/a'
                driver.find_element(By.XPATH, complain_list).click()

                # 상세 정보 가져오기
                title = driver.find_element(By.XPATH, f'//*[@id="txt"]/div[1]/div/div[1][contains(@class, "b_row")]').text
                text = driver.find_element(By.XPATH, f'//*[@id="txt"]/div[1]/div/div[3]').text
                date = driver.find_element(By.XPATH, f'//*[@id="txt"]/div[1]/div/div[1]/div[2]').text
                depart = driver.find_element(By.XPATH, f'//*[@id="txt"]/div[1]/div/div[2]/div[2]').text
                answer = driver.find_element(By.XPATH, f'//*[@id="txt"]/div[2]/div/div[1]').text
                ans_date = driver.find_element(By.XPATH, f'//*[@id="txt"]/div[2]/div/div[3]/div[2]').text

                # 데이터프레임에 추가
                new_row = pd.DataFrame({
                    '제목': [title],
                    '내용': [text],
                    '작성일자': [date],
                    '답변': [answer],
                    '답변일자': [ans_date],
                    '처리기관': [depart]
                })
                result_df = pd.concat([result_df, new_row], ignore_index=True)

                # 뒤로 가기
                time.sleep(2)
                driver.back()

        # 지역 정보 추가 및 결과 반환
        result_df['region'] = key
        return result_df

    except Exception as e:
        return pd.DataFrame()
    finally:
        if driver:
            driver.quit()
    
