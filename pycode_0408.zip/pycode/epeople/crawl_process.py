# -*- coding: utf-8 -*-
import pandas as pd
from datetime import date, timedelta, datetime
import sys
import os
import pymysql

# 상대 경로 처리
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)

# 로컬 모듈 가져오기
from nation_crawl import crawler
from nation_all_crawl import all_crawler
from nation_answer_crawl import answer_crawler
from chrome_version import get_chrome_driver, DELAY_TIME, get_today_and_yesterday


#########################################
##### 데이터베이스 관련 함수 #############

# 로컬 DB 연결 정보
DB_CONFIG = {
    'host': 'localhost',
    'port': 3307,
    'user': 'root',
    'password': 'epdlxjdpeb!1',
    'db': 'ghost_2025',
    'charset': 'utf8mb4'
}

def connect_db():
    """데이터베이스 연결 함수"""
    try:
        # 로컬 DB 설정 사용
        connection = pymysql.connect(**DB_CONFIG)
        return connection
    except Exception as e:
        print(f"[오류] 데이터베이스 연결 실패: {e}")
        return None

def get_data(conn, table_name):
    """테이블에서 마지막 등록 날짜와 다음 인덱스를 가져오는 함수"""
    print(f"\n[디버그] get_data() - 테이블 데이터 조회 중: {table_name}")
    cursor = None
    
    try:
        cursor = conn.cursor()
        
        if table_name == 'epeople':
            # 최근 등록일 조회
            sql = "SELECT register_date, idx FROM {} ORDER BY register_date DESC LIMIT 1".format(table_name)
            cursor.execute(sql)
            df_data = cursor.fetchone()
            
            if df_data is None:
                print("[디버그] 기존 데이터가 없습니다. 기본 날짜를 사용합니다.")
                last_date = '2000-01-01'
            else:
                last_date = df_data[0]
                print(f"[디버그] 마지막 등록일: {last_date}")
            
            # 다음 인덱스 조회
            sql2 = "SELECT idx FROM {} ORDER BY idx DESC LIMIT 1".format(table_name)
            cursor.execute(sql2)
            df_data2 = cursor.fetchone()
            
            if df_data2 is None:
                idx = 1
            else:
                idx = df_data2[0] + 1
            
            # 다음 날짜 계산 (마지막 등록일 + 1일)
            if last_date:
                last_date = (datetime.strptime(str(last_date), '%Y-%m-%d') + timedelta(1)).strftime('%Y-%m-%d')
            
            print(f"[디버그] 다음 인덱스: {idx}, 크롤링 시작일: {last_date}")
            return last_date, idx
        
        elif table_name == 'epeople_all':
            print("[디버그] epeople_all 테이블 쿼리 실행 중...")
            sql = "SELECT register_date FROM {} WHERE answer_date not in('심사 중') ORDER BY register_date DESC LIMIT 1".format(table_name)
            cursor.execute(sql)
            df_data = cursor.fetchone()
            
            if df_data is None:
                print("[디버그] 기존 데이터가 없습니다. 기본 날짜를 사용합니다")
                last_date = '2000-01-01'
            else:
                last_date = df_data[0]
                # 다음 날짜 계산
                last_date = (datetime.strptime(str(last_date), '%Y-%m-%d') + timedelta(1)).strftime('%Y-%m-%d')
                print(f"[디버그] 마지막 등록일 확인: {last_date}")
            
            # 다음 인덱스 조회
            sql2 = "SELECT idx FROM {} ORDER BY idx DESC LIMIT 1".format(table_name)
            cursor.execute(sql2)
            df_data2 = cursor.fetchone()
            
            if df_data2 is None:
                idx = 1
            else:
                idx = df_data2[0] + 1
                
            print(f"[디버그] 사용할 다음 인덱스: {idx}")
            return last_date, idx
        
        elif table_name == 'epeople_answer':
            sql = "SELECT answer_date FROM {} ORDER BY answer_date DESC LIMIT 1".format(table_name)
            cursor.execute(sql)
            df_data = cursor.fetchone()
            
            if df_data is None:
                last_date = '2000-01-01'
            else:
                last_date = df_data[0]
                # 다음 날짜 계산
                last_date = (datetime.strptime(str(last_date), '%Y-%m-%d') + timedelta(1)).strftime('%Y-%m-%d')
            
            # 다음 인덱스 조회
            sql2 = "SELECT idx FROM {} ORDER BY idx DESC LIMIT 1".format(table_name)
            cursor.execute(sql2)
            df_data2 = cursor.fetchone()
            
            if df_data2 is None:
                idx = 1
            else:
                idx = df_data2[0] + 1
                
            return last_date, idx
        
        else: # epeople_else
            sql = "SELECT region, max(register_date) FROM {} GROUP BY region".format(table_name)
            cursor.execute(sql)
            df_data = cursor.fetchall()
            
            sql2 = "SELECT idx FROM {} ORDER BY idx DESC LIMIT 1".format(table_name)
            cursor.execute(sql2)
            df_data2 = cursor.fetchone()
            
            if df_data2 is None:
                idx = 1
            else:
                idx = df_data2[0] + 1
            
            # 각 지역별 다음 날짜 계산
            region_dates = []
            for region, date in df_data:
                if date is None:
                    next_date = '2000-01-01'
                else:
                    next_date = (datetime.strptime(str(date), '%Y-%m-%d') + timedelta(1)).strftime('%Y-%m-%d')
                region_dates.append((region, next_date))
            
            return region_dates, idx
            
    except Exception as e:
        print(f"[오류] 데이터 조회 실패: {e}")
        return None, None
    finally:
        if cursor:
            cursor.close()

def db_save(df, conn, table_name):
    """데이터프레임을 테이블에 저장하는 함수"""
    print(f"\n[디버그] db_save() - 테이블에 데이터 저장 중: {table_name}")
    print(f"[디버그] 저장할 레코드 수: {len(df)}개")
    
    if df.empty:
        print("[디버그] 저장할 데이터가 없습니다.")
        return
        
    cursor = None
    try:
        cursor = conn.cursor()
        
        if table_name == 'epeople':
            sql = "INSERT INTO {}(idx, title, body, register_date, answer, answer_date, part) VALUES(%s, %s, %s, %s, %s, %s, %s)".format(table_name)
            values = [(row['idx'], row['제목'], row['내용'], row['작성일자'], 
                     row['답변'], row['답변일자'], row['담당부서']) 
                    for _, row in df.iterrows()]
            cursor.executemany(sql, values)
            conn.commit()
            print(f"[디버그] {len(df)}개의 레코드 저장 완료")
            
        elif table_name == 'epeople_else':
            for _, row in df.iterrows():
                sql = "INSERT INTO {}(idx, region, title, body, register_date, answer, answer_date, part) VALUES(%s, %s, %s, %s, %s, %s, %s, %s)".format(table_name)
                lists = [row['idx'], row['region'], row['제목'], row['내용'], row['작성일자'], row['답변'], row['답변일자'], row['담당부서']]
                cursor.execute(sql, lists)
                conn.commit()
            print(f"[디버그] {len(df)}개의 레코드 저장 완료")
                
        elif table_name == 'epeople_answer':
            for _, row in df.iterrows():
                sql = "INSERT INTO {}(idx, title, body, register_date, answer, answer_date, part) VALUES(%s, %s, %s, %s, %s, %s, %s)".format(table_name)
                lists = [row['idx'], row['제목'], row['내용'], row['작성일자'], row['답변'], row['답변일자'], row['처리기관']]
                cursor.execute(sql, lists)
                conn.commit()
            print(f"[디버그] {len(df)}개의 레코드 저장 완료")
                
        else: # 'epeople_all'
            for _, row in df.iterrows():
                sql = "INSERT INTO {}(idx, region, title, body, register_date, answer, answer_date, part) VALUES(%s, %s, %s, %s, %s, %s, %s, %s)".format(table_name)
                lists = [row['idx'], row['region'], row['제목'], row['내용'], row['작성일자'], row['답변'], row['답변일자'], row['처리기관']]
                cursor.execute(sql, lists)
                conn.commit()
            print(f"[디버그] {len(df)}개의 레코드 저장 완료")
                
    except Exception as e:
        print(f"[오류] 데이터 저장 실패: {e}")
        conn.rollback()
    finally:
        if cursor:
            cursor.close()

#########################################
##### 테이블별 크롤링 업데이트 코드 #######

##### epeople 테이블 (밀양시청 국민신문고)
def epeople(conn, today):
    """밀양시청 국민신문고 크롤링"""
    table_name = 'epeople'
    last_date, idx = get_data(conn, table_name)
    print(f"[디버그] 크롤링 기간: {last_date} ~ {today}")
    
    df = crawler(last_date, today)  # 수정된 crawler 함수 호출
    
    try:
        if not df.empty:
            print(f"{len(df)}건 업데이트 합니다.")
            df['idx'] = range(idx, idx + len(df))
            db_save(df, conn, table_name)
        else:
            print("[디버그] 업데이트할 데이터가 없습니다.")
    except Exception as e:
        print(f"[오류] 데이터 처리 실패: {e}")

##### epeople_all 테이블 (국민신문고 통합 사이트)
def epeople_all(conn, today):
    print(f"\n[디버그] epeople_all() - 크롤링 시작. 날짜: {today}")
    table_name = 'epeople_all'
    last_date, idx = get_data(conn, table_name)
    print(f"[디버그] 크롤링 기간: {last_date} ~ {today}")
    
    region_code = {'경상남도': 3, '경상북도': 4, '광주광역시': 5, '대구광역시': 6, '부산광역시': 8, '울산광역시': 11}
    result_df = pd.DataFrame(columns=['제목', '내용', '작성일자', '답변', '답변일자', '처리기관'])
    
    for key, value in region_code.items():
        print(f"\n[디버그] 지역 처리 중: {key} (코드: {value})")
        try:
            df = all_crawler(key, value, last_date, today)
            print(f"[디버그] {key} 지역 {len(df)}건의 데이터 발견")
            result_df = pd.concat([result_df, df], ignore_index=True)
        except Exception as e:
            print(f"[오류] {key} 크롤링 실패: {e}")
            continue
    
    result_df = result_df.sort_values(by='작성일자')
    print(f"\n[디버그] 전체 발견된 데이터: {len(result_df)}건")
    
    if not result_df.empty:
        index_list = list(range(idx, idx + len(result_df)))
        df = result_df.assign(idx=index_list)
        db_save(df, conn, table_name)
    else:
        print("[디버그] 업데이트할 데이터가 없습니다.")

#### epeople_else 테이블 (양산시청, 경주시청, 광주시청 국민신문고)       
def epeople_else(conn, today):
    table_name = 'epeople_else'
    region_dates, idx = get_data(conn, table_name)
    result_df = pd.DataFrame(columns=['idx', 'region', '제목', '내용', '작성일자', '답변', '답변일자', '담당부서'])
    
    # 지역별 날짜 정보를 딕셔너리로 변환
    region_date_dict = dict(region_dates)
    
    # 지역 및 URL 정보
    regions = {
        '양산시': {
            'url': 'https://eminwon.yangsan.go.kr/emwp/gov/mogaha/ntis/web/caf/mwwd/action/CafMwWdOpenAction.do?method=selectListMwOpn&menu_id=CAFOPNWebMwOpenL&jndinm=CafMwWdOpenEJB&methodnm=selectListMwOpn&context=NTIS',
            'url2': 'https://www.epeople.go.kr/frm/pttn/openPttnList.npaid?frmMenuMngNo=WBF-1703-000170'
        },
        '경주시': {
            'url': 'https://www.gyeongju.go.kr/open_content/ko/page.do?mnu_uid=1807&',
            'url2': 'https://www.epeople.go.kr/frm/pttn/openPttnList.npaid?frmMenuMngNo=WBF-1612-000077'
        },
        '부천시': {
            'url': 'http://www.bucheon.go.kr/site/homepage/menu/viewMenu?menuid=148005001001001',
            'url2': 'https://www.epeople.go.kr/frm/pttn/openPttnList.npaid?frmMenuMngNo=WBF-2012-000048'
        },
        '성남시': {
            'url': 'https://www.seongnam.go.kr/city/1001125/10797/contents.do',
            'url2': 'https://www.epeople.go.kr/frm/pttn/openPttnList.npaid?frmMenuMngNo=WBF-1710-000009'
        }
    }
    
    today_obj = datetime.strptime(today, '%Y-%m-%d')
    
    for region, urls in regions.items():
        if region == '광주시':  # 광주시는 제외
            continue
            
        if region in region_date_dict:
            last_date = region_date_dict[region]
            print(f"[디버그] {region} 크롤링 시작 날짜: {last_date}")
            
            # 6개월 이상 차이가 나는지 확인
            last_date_obj = datetime.strptime(last_date, '%Y-%m-%d')
            date_diff = today_obj - last_date_obj
            
            crawl_start_date = last_date
            if date_diff.days >= 180:
                crawl_start_date = (today_obj - timedelta(180)).strftime('%Y-%m-%d')
                print(f"[디버그] {region} 날짜가 6개월 이상 차이나므로 시작일 조정: {crawl_start_date}")
                
            try:
                df = crawler(urls['url'], urls['url2'], crawl_start_date, today)
                if not df.empty:
                    df['region'] = region
                    result_df = pd.concat([result_df, df], ignore_index=True)
                    print(f"[디버그] {region} {len(df)}건의 데이터 발견")
            except Exception as e:
                print(f"[오류] {region} 크롤링 실패: {e}")
    
    if not result_df.empty:
        print(f"{len(result_df)}건 업데이트 합니다.")
        index_list = list(range(idx, idx + len(result_df)))
        result_df = result_df.assign(idx=index_list)
        db_save(result_df, conn, table_name)
    else:
        print("[디버그] 업데이트할 데이터가 없습니다.")

#### epeople_answer 테이블 (국민신문고 질의응답)
def epeople_answer(conn, yesterday):
    table_name = 'epeople_answer'
    last_date, idx = get_data(conn, table_name)
    print(f"[디버그] 질의응답 크롤링 기간: {last_date} ~ {yesterday}")
    
    df = answer_crawler(last_date, yesterday)
    if not df.empty:
        result_df = df.sort_values(by='답변일자')
        result_df = result_df.drop_duplicates(subset=['제목', '답변'], keep='first')  # 중복제거
        print(f"{len(result_df)}건 업데이트 합니다.")
        
        index_list = list(range(idx, idx + len(result_df)))
        df = result_df.assign(idx=index_list)
        db_save(df, conn, table_name)
    else:
        print("[디버그] 업데이트할 데이터가 없습니다.")

if __name__ == "__main__":
    print("\n[디버그] 메인 프로세스 시작...")
    conn = None
    try:
        conn = connect_db()
        if not conn:
            print("[오류] 데이터베이스 연결 실패. 프로그램을 종료합니다.")
            sys.exit(1)
            
        print("[디버그] 데이터베이스 연결 성공")
        
        # 날짜 가져오기
        _, yesterday_format = get_today_and_yesterday()
        print(f"[디버그] 처리할 날짜: {yesterday_format}")
        
        # epeople_all 테이블 크롤링
        epeople_all(conn, yesterday_format)
        print("\n[디버그] 프로세스 정상 완료")
        
    except Exception as e:
        print(f"[오류] 프로세스 실패: {e}")
    finally:
        if conn:
            conn.close()
            print("[디버그] 데이터베이스 연결 종료")

