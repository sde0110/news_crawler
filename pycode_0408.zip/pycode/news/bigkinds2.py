import time
from datetime import datetime, timedelta
import re
import pandas as pd
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import pool, query_exec, insert_data, perform_db_task, perform_db_task_one

def database_handler(action="load", result_df=None):
    """데이터베이스 로드/저장 작업을 처리하는 통합 함수"""
    if action == "load":
        # 데이터베이스에서 인덱스, URL, 제목 정보를 로드
        next_index = 1
        existing_urls = set()
        existing_titles = set()
        
        try:
            # 다음 인덱스 가져오기
            result = perform_db_task_one("SELECT idx FROM bigkinds4 ORDER BY idx DESC LIMIT 1")
            if result is None:
                print("No data found in bigkinds4. Starting with index 1.")
            else:
                next_index = result[0] + 1
                    
            # 기존 URL 로드
            results = perform_db_task("SELECT link FROM bigkinds4 WHERE link IS NOT NULL AND link != ''")
            for row in results:
                if row[0]:
                    existing_urls.add(row[0])
            print(f"데이터베이스에서 {len(existing_urls)}개의 기존 URL을 로드했습니다.")
            
            # 기존 제목 로드
            results = perform_db_task("SELECT title FROM bigkinds4 WHERE title IS NOT NULL AND title != ''")
            for row in results:
                if row[0]:
                    existing_titles.add(row[0])
            print(f"데이터베이스에서 {len(existing_titles)}개의 기존 제목을 로드했습니다.")
            
        except Exception as e:
            print(f"데이터 로드 중 오류: {e}")
        
        return next_index, existing_urls, existing_titles
        
    elif action == "save" and result_df is not None:
        # 데이터베이스에 새 기사 저장
        next_index, db_existing_urls, db_existing_titles = database_handler("load")
        
        try:
            saved_count = 0
            skipped_count = 0
            
            for i, row in result_df.iterrows():
                is_duplicate = False
                
                # URL 기반 중복 확인 
                if row['출처'] in db_existing_urls:
                    print(f"중복 URL 발견(DB): {row['출처']} - 건너뜁니다.")
                    skipped_count += 1
                    is_duplicate = True
                
                # 제목 기반 중복 확인
                elif row['제목'] in db_existing_titles:
                    print(f"중복 제목 발견(DB): {row['제목']} - 건너뜁니다.")
                    skipped_count += 1
                    is_duplicate = True
                
                # 중복이 아닌 경우에만 저장
                if not is_duplicate:
                    sql = "INSERT INTO bigkinds4(idx, title, press, class, register_date, body, link) VALUES(%s, %s, %s, %s, %s, %s, %s)"
                    
                    # 키워드 리스트를 문자열로 변환
                    keyword_str = ', '.join(row['키워드']) if isinstance(row['키워드'], list) else row['키워드']
                    data = [next_index + saved_count, row['제목'], row['언론사'], keyword_str, row['작성일자'], str(row['내용']), row['출처']]
                    
                    # insert_data 함수 사용
                    insert_data(sql, data)
                    print(f"기사 저장 완료: {row['제목']} (ID: {next_index + saved_count})")
                    saved_count += 1
            
            print(f"{saved_count}개의 기사를 데이터베이스에 저장했습니다. ({skipped_count}개의 중복 기사 건너뜀)")
            return saved_count, skipped_count
        except Exception as e:
            print(f"데이터베이스 저장 중 오류 발생: {e}")
            return 0, 0

def browser_utils(driver, action, element=None, input_id=None, date_value=None):
    """브라우저 조작과 관련된 여러 기능을 하나의 함수로 통합"""
    if action == "setup":
        # database.py의 setup_webdriver 함수 사용
        from database import setup_webdriver
        try:
            return setup_webdriver()
        except Exception as e:
            print(f"웹드라이버 초기화 중 오류: {e}")
            # 실패 시 자체 초기화 시도
            import selenium.webdriver
            options = selenium.webdriver.ChromeOptions()
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-gpu')
            options.add_argument('--headless')
            return selenium.webdriver.Chrome(options=options)
        
    elif action == "click" and element is not None:
        # 웹 요소 스크롤 및 클릭 실행
        try:
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
            time.sleep(1)
            driver.execute_script("arguments[0].click();", element)
            return True
        except Exception as e:
            print(f"요소 클릭 중 오류: {e}")
            try:
                element.click()
                return True
            except:
                return False
                
    elif action == "set_date" and input_id is not None and date_value is not None:
        # 날짜 입력 필드에 값 설정
        try:
            date_input = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.ID, input_id))
            )
            date_input.click()
            date_input.send_keys(Keys.CONTROL + "A")
            date_input.send_keys(date_value)
            date_input.send_keys(Keys.ENTER)
            time.sleep(1)
            return True
        except Exception as e:
            print(f"날짜 입력 중 오류: {e}")
            return False
            
    elif action == "close_modal":
        # 기사 모달 창 닫기
        try:
            close_button = driver.find_element(By.XPATH, '//*[@id="news-detail-modal"]//button[@aria-label="Close"]')
            browser_utils(driver, "click", close_button)
            return True
        except:
            try:
                driver.execute_script("document.querySelector('.modal-backdrop').click();")
                return True
            except:
                print("모달 창 닫기 실패")
                return False

def setup_search_params(driver):
    """검색 조건(기간, 언론사, 분류)을 설정하여 검색 결과를 가져오는 함수"""
    try:
        # 기간 설정
        date_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//a[contains(text(), "기간")]'))
        )
        browser_utils(driver, "click", date_button)
        
        # 시작일 설정 (30일 전)
        start_date = datetime.now() - timedelta(days=30)
        browser_utils(driver, "set_date", input_id='search-begin-date', date_value=start_date.strftime("%Y-%m-%d"))
        
        # 종료일 설정 (오늘)
        end_date = datetime.now()
        browser_utils(driver, "set_date", input_id='search-end-date', date_value=end_date.strftime("%Y-%m-%d"))
        
        # 언론사 설정
        press_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//a[contains(text(), "언론사")]'))
        )
        browser_utils(driver, "click", press_button)
        time.sleep(2)

        # 지역일간지 클릭
        지역일간지_plus = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="category_provider_group"]/li[3]/a/label/div'))
        )
        browser_utils(driver, "click", 지역일간지_plus)
        
        지역일간지_경상 = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='do5']"))
        )
        browser_utils(driver, "click", 지역일간지_경상)

        # 지역주간지 클릭
        지역주간지_plus = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="category_provider_group"]/li[4]/a/label/div'))
        )
        browser_utils(driver, "click", 지역주간지_plus)
        
        지역주간지_경상 = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='dow5']"))
        )
        browser_utils(driver, "click", 지역주간지_경상)
        
        # 통합 분류 설정
        class_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//a[contains(text(), "통합 분류")]'))
        )
        browser_utils(driver, "click", class_button)
        time.sleep(2)

        # 분류 선택 (정치, 경제, 사회, 문화)
        categories = ["정치", "경제", "사회", "문화"]
        for i, category in enumerate(categories, 1):
            try:
                xpath = f"//*[@id='srch-tab3']/ul/li[{i}]/div/span[4]"
                checkbox = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, xpath))
                )
                browser_utils(driver, "click", checkbox)
            except Exception as e:
                print(f"{category} 분류 선택 중 오류: {e}")
        
        # 검색 실행
        search_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="search-foot-div"]/div[2]/button[2]'))
        )
        browser_utils(driver, "click", search_button)
        time.sleep(5)  # 검색 결과 로딩 대기
        
        return True
    except Exception as e:
        print(f"검색 조건 설정 중 오류: {e}")
        return False

def extract_article_data(driver):
    """열린 기사 팝업에서 제목, 언론사, 날짜, 키워드, 내용, URL 정보를 추출"""
    article_data = {
        '제목': "제목 추출 실패",
        '언론사': "Unknown",
        '작성일자': "Unknown",
        '키워드': [],
        '내용': "",
        '출처': ""
    }
    
    # 제목 추출
    try:
        title = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="news-detail-modal"]/div/div/div/div[1]/div/div[1]/h1'))
        ).text
        article_data['제목'] = title
        print(f"제목: {title}")
    except Exception as e:
        print(f"제목 추출 중 오류: {e}")
    
    # 언론사 추출
    try:
        img_xpath = '//*[@id="chkProviderImage"]/img'
        img_element = driver.find_element(By.XPATH, img_xpath)
        onerror_value = img_element.get_attribute("onerror")
        
        match = re.search(r"this, ['\"]([^'\"]+)['\"]", onerror_value)
        if match:
            news = match.group(1)
        else:
            match = re.search(r'[\'"]([^\'"]+)[\'"]', onerror_value)
            news = match.group(1) if match else "Unknown"
        
        article_data['언론사'] = news
        print(f"언론사: {news}")
    except Exception as e:
        print(f"언론사 추출 중 오류: {e}")
    
    # 작성 날짜 추출
    try:
        date_element = driver.find_element(By.XPATH, '//*[@id="news-detail-modal"]/div/div/div/div[1]/div/div[1]/div[1]/ul/li[1]')
        date_text = date_element.text.strip()
        
        date_match = re.search(r'(\d{4}[-/]\d{1,2}[-/]\d{1,2})', date_text)
        if date_match:
            date_str = date_match.group(1)
            if '-' in date_str:
                date_parsed = date_str
            else:
                date_obj = datetime.strptime(date_str, '%Y/%m/%d')
                date_parsed = date_obj.strftime('%Y-%m-%d')
            
            article_data['작성일자'] = date_parsed
            print(f"작성일자: {date_parsed}")
        else:
            print("날짜 형식 인식 실패")
    except Exception as e:
        print(f"날짜 추출 중 오류: {e}")
    
    # 키워드 추출
    try:
        keyword_element = driver.find_element(By.XPATH, '//*[@id="news-detail-modal"]/div/div/div/div[1]/div/div[1]/div[1]/div/span')
        keyword = keyword_element.text.strip()
        keyword_list = [k.strip() for k in keyword.split('|') if k.strip()]
        article_data['키워드'] = keyword_list
        print(f"키워드: {', '.join(keyword_list)}")
    except Exception as e:
        print(f"키워드 추출 중 오류: {e}")
    
    # 내용 추출
    try:
        content_element = WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'news-view-content'))
        )
        
        html_content = content_element.get_attribute('innerHTML')
        html_content = html_content.replace('<br>', '\n').replace('<br/>', '\n').replace('<br />', '\n')
        
        soup = BeautifulSoup(html_content, 'html.parser')
        text = soup.get_text(separator=' ', strip=True)
        
        text = re.sub(r'\s+', ' ', text).strip()
        text = re.sub(r'\n\s*\n', '\n\n', text)
        
        article_data['내용'] = text
        print(f"내용 길이: {len(text)}자")
    except Exception as e:
        print(f"내용 추출 중 오류: {e}")
    
    # 출처 URL 추출
    try:
        newsid_element = driver.find_element(By.XPATH, '//*[@id="news-detail-modal"]/div/div/div/div[1]/div/div[1]/div[2]/div[2]/button[7]')
        news_id = newsid_element.get_attribute('data-newsid')
        detail_url = f'https://www.bigkinds.or.kr/v2/news/newsDetailView.do?newsId={news_id}'
        article_data['출처'] = detail_url
        print(f"URL: {detail_url}")
    except Exception as e:
        print(f"URL 추출 중 오류: {e}")
    
    return article_data

def crawler():
    """빅카인즈 뉴스 크롤러의 메인 함수로 전체 기사 수집 과정을 관리"""
    # 기존 URL과 제목 로드
    next_index, existing_urls, existing_titles = database_handler("load")
    
    driver = browser_utils(None, "setup")
    result_df = pd.DataFrame(columns=['제목', '언론사', '작성일자', '키워드', '내용', '출처'])
    duplicate_count = 0

    try:
        # 빅카인즈 URL 접속
        url = 'https://www.bigkinds.or.kr/v2/news/index.do'
        print(f"URL 접속 중 : {url}")
        driver.get(url)
        time.sleep(5)

        # 검색 조건 설정
        if not setup_search_params(driver):
            print("검색 조건 설정 실패. 크롤링을 종료합니다.")
            return
       
        # 전체 기사 개수 확인
        try:
            total_count_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'total-news-cnt'))
            )
            total_count_text = total_count_element.text.replace(',', '').strip()
            total_count = int(total_count_text) if total_count_text else 500
            print(f"전체 기사 개수: {total_count}")
        except Exception as e:
            print(f"기사 개수 확인 중 오류: {e}")
            total_count = 500

        # 검색 결과 기사 목록 가져오기
        news_items = WebDriverWait(driver, 10).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".news-item"))
        )
        
        if not news_items:
            print("검색 결과가 없습니다.")
            return
            
        # 첫 번째 기사 클릭하여 팝업 열기
        first_article = news_items[0]
        title_link = first_article.find_element(By.CSS_SELECTOR, "a.news-detail")
        browser_utils(driver, "click", title_link)
        
        # 모달 창 로드 확인
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "news-detail-modal"))
        )
        print("모달 창 로드 완료")
        
        # 기사 수집 시작
        article_count = 0

        # ================= 디버깅용 5개 기사만 수집 ===================
        max_articles = 5
        # =============================================================
        # max_articles = min(total_count, 200)  # 전체 기사 수만큼 가져오되, 최대 200개 수집

        # 기사 순차 수집
        while article_count < max_articles:
            try:
                print(f"현재 기사 {article_count+1}번째 수집 중...")
                
                # 기사 데이터 추출
                article_data = extract_article_data(driver)
                
                # 중복 확인
                is_duplicate = False
                if article_data['출처'] and article_data['출처'] in existing_urls:
                    print(f"중복 URL 발견: {article_data['출처']} - 건너뜁니다.")
                    is_duplicate = True
                    duplicate_count += 1
                elif article_data['제목'] and article_data['제목'] in existing_titles:
                    print(f"중복 제목 발견: {article_data['제목']} - 건너뜁니다.")
                    is_duplicate = True
                    duplicate_count += 1
                
                # 데이터 유효성 확인 및 중복이 아닌 경우만 DataFrame에 추가
                if not is_duplicate and article_data['내용'] and article_data['제목'] != "제목 추출 실패":
                    new_row = pd.DataFrame([article_data])
                    result_df = pd.concat([result_df, new_row], ignore_index=True)
                    print(f"데이터프레임에 추가 완료 (현재 {len(result_df)}개)")
                    
                    # 수집 시점에서 중복 체크 목록에 추가
                    existing_urls.add(article_data['출처'])
                    existing_titles.add(article_data['제목'])
                
                article_count += 1
                
                # 모달 닫고 다음 기사 클릭
                browser_utils(driver, "close_modal")
                time.sleep(1)
                
                # 다음 기사가 있으면 클릭
                if article_count < len(news_items):
                    next_article = news_items[article_count]
                    next_title_link = next_article.find_element(By.CSS_SELECTOR, "a.news-detail")
                    browser_utils(driver, "click", next_title_link)
                    time.sleep(3)
                    print(f"{article_count+1}번째 뉴스 항목 클릭 완료")
                else:
                    print("더 이상 수집할 뉴스가 없습니다.")
                    break
                
            except Exception as e:
                print(f"기사 처리 중 오류 발생: {e}")
                try:
                    driver.refresh()
                    time.sleep(5)
                    
                    if article_count < len(news_items):
                        next_article = news_items[article_count]
                        next_title_link = next_article.find_element(By.CSS_SELECTOR, "a.news-detail")
                        browser_utils(driver, "click", next_title_link)
                        time.sleep(3)
                        continue
                    else:
                        break
                except:
                    print("페이지 복구 실패. 수집을 종료합니다.")
                    break
        
        # 모든 기사 수집 후 CSV 저장 및 DB 저장
        if len(result_df) > 0:
            
            # DB에 저장
            saved, skipped = database_handler("save", result_df)
            print("=== 기사 수집 완료 및 DB 저장 완료 ===")
            print(f"총 {article_count}개 기사 처리, {saved}개 저장, {duplicate_count}개 크롤링 중 중복 제외, {skipped}개 DB 저장 중 중복 제외")
        else:
            print("=== 저장할 새로운 기사가 없습니다 ===")

    except Exception as e:
        print(f"크롤러 실행 중 오류 발생: {e}")

    finally:
        # driver는 database.py에서 관리하므로 여기서 종료하지 않음
        print("크롤링 완료")
        
if __name__ == "__main__":
    try:
        crawler()
    except Exception as e:
        print(f"메인 프로세스 오류: {e}")
