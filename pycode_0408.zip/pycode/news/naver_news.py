# -*- coding: utf-8 -*-
import time
from selenium import webdriver
from bs4 import BeautifulSoup
import requests
import pandas as pd
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from datetime import datetime, timedelta
import pymysql
from newspaper import Article
import warnings
warnings.filterwarnings('ignore')

def setup_database():
    """데이터베이스 연결 설정 및 날짜 범위 설정"""
    try:
        conn = pymysql.connect(
            host='localhost', port=3307,
            user='root', password='epdlxjdpeb!1',
            db='ghost_2025', charset='utf8mb4'
        )
        
        with conn.cursor() as cursor:
            # 다음 인덱스 확인 - 수정된 부분
            cursor.execute("SELECT idx FROM naver_news ORDER BY idx DESC LIMIT 1")
            result = cursor.fetchone()
            next_index = result[0] + 1 if result else 1  # None 처리 추가
            
            cursor.execute("SELECT register_date FROM naver_news ORDER BY register_date DESC LIMIT 1")
            last_date = cursor.fetchone()
            
            cursor.execute("SELECT url FROM naver_news WHERE url IS NOT NULL AND url != ''")
            existing_urls = {row[0] for row in cursor.fetchall() if row[0]}
            
            cursor.execute("SELECT title FROM naver_news WHERE title IS NOT NULL AND title != ''")
            existing_titles = {row[0] for row in cursor.fetchall() if row[0]}
        
        conn.close()
        
        # 날짜 범위 설정 - 수정된 부분
        if last_date and last_date[0]:
            start_date = datetime.strptime(last_date[0], '%Y-%m-%d') + timedelta(days=1)
        else:
            start_date = datetime.today() - timedelta(days=30)
        
        end_date = datetime.today() - timedelta(days=1)
        
        # 시간 정보 추가
        start_date = datetime.combine(start_date.date(), datetime.min.time())
        end_date = datetime.combine(end_date.date(), datetime.max.time())
        
        print(f"수집 기간: {start_date.strftime('%Y-%m-%d %H:%M:%S')} ~ {end_date.strftime('%Y-%m-%d %H:%M:%S')}")
        return start_date, end_date, next_index, existing_urls, existing_titles
        
    except Exception as e:
        print(f"데이터베이스 설정 중 오류: {e}")
        # 기본값 반환 시 next_index를 확실히 지정
        return (
            datetime.today() - timedelta(days=7),  # start_date
            datetime.today() - timedelta(days=1),  # end_date
            1,  # next_index
            set(),  # existing_urls
            set()   # existing_titles
        )

def collect_news_urls(start_date, end_date):
    """여행 관련 뉴스 URL 및 저자 정보 수집"""
    try:
        # 웹드라이버 설정
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        # 로그 관련 옵션 추가
        options.add_argument('--log-level=3')  # 로그 레벨 최소화
        options.add_argument('--silent')  # 불필요한 로그 출력 억제
        options.add_experimental_option('excludeSwitches', ['enable-logging'])  # 로깅 비활성화
        # SSL 오류 무시 옵션
        options.add_argument('--ignore-certificate-errors')
        options.add_argument('--ignore-ssl-errors')
        options.add_argument('--allow-insecure-localhost')
        
        service = Service('C:\drivers\chromedriver.exe')
        driver = webdriver.Chrome(service=service, options=options)
        
        # requests 설정
        requests.packages.urllib3.disable_warnings()
        session = requests.Session()
        session.verify = False  # SSL 검증 비활성화
        
        article_list = []
        author_list = []
        
        # 날짜 형식 변환
        start_str = start_date.strftime("%Y.%m.%d")
        end_str = end_date.strftime("%Y.%m.%d")
        
        # 페이지별 URL 수집
        for n in range(1, 1000, 10):
            url = f'''https://search.naver.com/search.naver?where=news&sm=tab_pge&query=%EB%B0%80%EC%96%91&sort=1
                    &photo=0&field=0&pd=3&ds={start_str}&de={end_str}&start={n}'''
            
            raw = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
            html = BeautifulSoup(raw.text, "html.parser")
            articles = html.select("ul.list_news > li")
            
            if not articles:
                break
                
            for ar in articles:
                try:
                    article_url = ar.find("a")['data-url']
                    article_author = ar.find_all("a")[3].text if len(ar.find_all("a")) >= 4 else "Unknown"
                    
                    article_list.append(article_url)
                    author_list.append(article_author)
                except Exception as e:
                    print(f"URL 추출 중 오류: {e}")
                    continue
            
            time.sleep(1)
        
        return driver, article_list, author_list
        
    except Exception as e:
        print(f"URL 수집 중 오류: {e}")
        return None, [], []

def clean_text(text):
    """텍스트 정제 함수"""
    remove_patterns = [
        r'ⓒ .+? 무단전재·재배포 금지',
        r'저작권자 ⓒ .+? 무단전재 및 재배포 금지',
        r'밀양=.+?기자',
        "큰사진보기",
        "관련사진보기",
        r'기사모아보기',
        r'투데이는 여러분의 후원금을 귀하게 쓰겠습니다.',
        r'연합뉴스TV 기사문의 및 제보 : 카톡/라인\s+\w+\(.*?\)',
        r'제보는 카카오톡\s+\w+',
        r'\w+@\w+.kr',
        r'<저작권자\(c\) \w+, 무단 전재-재배포 금지>',
        r'\[저작권자\(c\) \w+ 무단전재 및 재배포 금지\]',
        r'(?:카카오톡|카카오스토리|네이버밴드|네이버블로그|URL복사)\(으\)로 기사보내기',
        r'\(사진제공=\w+\)',
        r'사진/',
        r'\[사진=\w+\]',
        r'\w+@\w+.com',
        r'\w+@\w+.kr',
        r'\[사진=\w+ 제공\]',
        r"ⓒ .+? 관련사진보기",
        r'\(사진=\w+ 기자\)',
        r'\(사진=\w+ \)',
        "글씨키우기 글씨줄이기 프린트 top\n\nfacebook twitter kakao story naver band share",
        r'\[신아일보\]',
        r'\w+@\w+',
        r'〈ⓒ \w+\([^)]+\), 무단전재 및 수집, 재배포금지',
        "UPI뉴스 /",
        r'\[밀양=\w+\s+기자\]',
        "\[\w+\s+\w+ 기자\]",
        r'\[\w+\s+\w= 기자\]',
        r'\[\w+ 기자\]',
        r'[^a-z]{3} 기자',
        r'\w+\s+기자',
        r'\[\w+ 제공\]',
        "을 응원해주세요.",
        "기사 잘 보셨나요?",
        "독자님의 응원이 기자에게 큰 힘이 됩니다.",
        "후원회원이 되어주세요.",
        "독자님의 후원금은 모두 기자에게 전달됩니다.",
        "정기후원은 모든 기자들에게 전달됩니다.",
        "정기후원 하기",
        "저작권자 ? 전국매일신문 - 전국의 생생한 뉴스를 '한눈에' 무단전재 및 재배포 금지",
        r'\[\w+\s+\w+\s+\w+\s+기자\]',
        "한국경제매거진 여행팀 기자",
        r'\w+=\w+',
        "고비룡 기자",
        "자료제공/밀양시",
        r'사진/ \w+ 사진작가',
        r'\(사진=\w+\s\w+\)',
        "대한민국 정책기자단 박하나",
        '카카오톡(으)로',
        '카카오스토리(으)로',
        '네이버밴드(으)로',
        '네이버블로그(으)로',
        '기사보내기',
        'URL복사(으)로',
        "고비룡(밀양창녕본부장)",
        "하용성 부산/경남 기자",
        "Fn투데이는 여러분의 후원금을 귀하게 쓰겠습니다.",
        "편도욱 로이슈 기자",
        "정세욱 기자",
        "영남취재본부",
        "편집국 의 다른기사보기",
        "공유하기",
        "더보기",
        "(사진)",
        "※ '당신의 제보가 뉴스가 됩니다'",
        "[카카오톡] YTN 검색해 채널 추가",
        "이 기사를 공유합니다.",
        "URL 기사저장",
        "이 기사와 관련된 기사",
        "죄송하지만 다른 브라우저를 사용하여 주십시오. 닫기",
        r'ⓒ \w+',
        "덧붙이는 글 | 기자의 블로그에도 실릴 예정입니다",
        "저작권자",
        "무단전재 및 재배포 금지",
        "경남도민문",
        "투어코리 - No.1 여행·축제 뉴스",
        r'\w+ 기자',
        r'\(사진제공=\w+\s+\w+\)',
        r'\w+기자',
        'GoodNews paper',
        '무단전재 및 수집, 재배포금지',
        '무단전재-재배포 금지',
        'co.kr',
        '\(www.\w+.co.kr\)'
    ]
    
    cleaned_text = text
    for pattern in remove_patterns:
        cleaned_text = re.sub(pattern, "", cleaned_text)
    
    # 중복 공백 제거 및 앞뒤 공백 제거
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()
    return cleaned_text

def process_news_content(driver, urls, authors, existing_urls, existing_titles, next_index):
    """뉴스 내용 수집, 전처리 및 저장"""
    try:
        df = pd.DataFrame(columns=['제목', '저자', '날짜', '링크', '내용', '요약'])
        saved_count = 0
        skipped_count = 0
        
        # 뉴스 내용 수집
        for i, (url, author) in enumerate(zip(urls, authors)):
            if url in existing_urls:
                print(f"중복 URL 발견: {url}")
                skipped_count += 1
                continue
                
            try:
                print(f"{i+1}/{len(urls)} 처리 중: {url}")
                
                # 기사 다운로드
                article = Article(url, language='ko')
                article.download()
                article.parse()
                
                # 중복 제목 확인
                if article.title in existing_titles:
                    print(f"중복 제목 발견: {article.title}")
                    skipped_count += 1
                    continue
                
                # 기본 정보 저장
                df.at[i, '링크'] = url
                df.at[i, '저자'] = author
                df.at[i, '제목'] = article.title
                df.at[i, '날짜'] = article.publish_date.strftime('%Y-%m-%d') if article.publish_date else datetime.today().strftime('%Y-%m-%d')
                
                # 내용 수집 및 전처리
                if author != '뉴시스':
                    text = article.text
                else:
                    driver.get(url)
                    text = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.XPATH, '//*[@id="content"]/div[1]/div[1]/div[3]/article'))
                    ).text
                
                # 텍스트 정제 함수 적용
                cleaned_text = clean_text(text)
                
                df.at[i, '내용'] = cleaned_text
                df.at[i, '요약'] = cleaned_text[:300] + "..." if len(cleaned_text) > 300 else cleaned_text
                
                saved_count += 1
                time.sleep(1)
                
            except Exception as e:
                print(f"기사 처리 중 오류: {e}")
                continue
        
        # 데이터 정제
        df = df.drop_duplicates()
        df = df.dropna(subset=['내용'])
        df = df.fillna("")
        df = df.reset_index(drop=True)
        
        # 데이터베이스 저장
        conn = pymysql.connect(
            host='localhost', port=3307,
            user='root', password='epdlxjdpeb!1',
            db='ghost_2025', charset='utf8mb4'
        )
        
        try:
            with conn.cursor() as cursor:
                sql = '''INSERT INTO naver_news (idx, title, author, register_date, url, body, summary, status)
                         VALUES(%s, %s, %s, %s, %s, %s, %s, %s)'''
                
                for i, row in df.iterrows():
                    cursor.execute(sql, [
                        next_index + i,
                        row['제목'],
                        row['저자'],
                        row['날짜'],
                        row['링크'],
                        row['내용'],
                        row['요약'],
                        "1"
                    ])
                conn.commit()
        finally:
            conn.close()
        
        return saved_count, skipped_count
        
    except Exception as e:
        print(f"뉴스 처리 중 오류: {e}")
        return 0, 0

def main():
    """메인 실행 함수"""
    try:
        print("네이버 뉴스 크롤러 시작")
        
        # 초기 설정
        start_date, end_date, next_index, existing_urls, existing_titles = setup_database()
        
        # URL 수집
        driver, urls, authors = collect_news_urls(start_date, end_date)
        if not urls:
            print("수집된 URL이 없습니다.")
            return
            
        # 뉴스 처리 및 저장
        try:
            saved_count, skipped_count = process_news_content(
                driver, urls, authors, existing_urls, existing_titles, next_index
            )
            print(f"=== 크롤링 완료 (저장: {saved_count}개, 중복: {skipped_count}개) ===")
        finally:
            if driver:
                driver.quit()
                
    except Exception as e:
        print(f"크롤러 실행 중 오류: {e}")

if __name__ == "__main__":
    main()