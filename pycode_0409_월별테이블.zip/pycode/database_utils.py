import pymysql
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
import warnings

# 경고 숨기기
warnings.filterwarnings('ignore')

# 로컬 DB 연결 정보
DB_CONFIG = {
    'host': 'localhost',
    'port': 3307,
    'user': 'root',
    'password': 'epdlxjdpeb!1',
    'db': 'ghost_2021',
    'charset': 'utf8mb4'
}

# 테이블 생성 SQL 정의
TABLE_SCHEMAS = {
    'epeople': """
        `idx` INT(11) NOT NULL AUTO_INCREMENT,
        `region` VARCHAR(50) NULL DEFAULT '' COLLATE 'utf8mb4_general_ci',
        `title` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `body` TEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `register_date` VARCHAR(50) NULL DEFAULT '' COLLATE 'utf8mb4_general_ci',
        `answer` TEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `answer_date` VARCHAR(50) NULL DEFAULT '' COLLATE 'utf8mb4_general_ci',
        `part` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` ENUM('Y','N') NULL DEFAULT 'N' COLLATE 'utf8mb4_general_ci',
        PRIMARY KEY (`idx`) USING BTREE
    """,
    'naver_news': """
        `idx` INT(11) NOT NULL AUTO_INCREMENT,
        `title` VARCHAR(200) NOT NULL DEFAULT '' COLLATE 'utf8mb4_general_ci',
        `author` VARCHAR(100) NOT NULL DEFAULT '' COLLATE 'utf8mb4_general_ci',
        `register_date` VARCHAR(50) NOT NULL DEFAULT '' COLLATE 'utf8mb4_general_ci',
        `url` VARCHAR(255) NOT NULL DEFAULT '' COLLATE 'utf8mb4_general_ci',
        `body` LONGTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `summary` TEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` ENUM('Y','N') NULL DEFAULT 'N' COLLATE 'utf8mb4_general_ci',
        PRIMARY KEY (`idx`) USING BTREE,
        INDEX `title` (`title`) USING BTREE,
        INDEX `status` (`status`) USING BTREE
    """,
    'bigkinds_news': """
        `idx` INT(11) NULL DEFAULT NULL,
        `title` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `press` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `class` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `register_date` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `body` TEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `link` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` ENUM('Y','N') NULL DEFAULT 'N' COLLATE 'utf8mb4_general_ci'
    """,
    'gndomin_news': """
        `idx` INT(11) NOT NULL AUTO_INCREMENT,
        `idx_temp` INT(11) NULL DEFAULT '0',
        `title` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `author` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `register_date` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `url` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `body` TEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `area_nm` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` ENUM('Y','N') NOT NULL DEFAULT 'N' COLLATE 'utf8mb4_general_ci',
        PRIMARY KEY (`idx`) USING BTREE
    """,
    'naver_news_travel': """
        `idx` INT(11) NOT NULL AUTO_INCREMENT,
        `title` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `author` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `register_date` VARCHAR(50) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `url` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `body` LONGTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `body_re` LONGTEXT NULL DEFAULT NULL COLLATE 'utf8mb4_general_ci',
        `status` ENUM('Y','N') NOT NULL DEFAULT 'N' COLLATE 'utf8mb4_general_ci',
        PRIMARY KEY (`idx`) USING BTREE
    """
}

def connect_db():
    """데이터베이스 연결 함수"""
    try:
        connection = pymysql.connect(**DB_CONFIG)
        return connection
    except Exception as e:
        print(f"[오류] 데이터베이스 연결 실패: {e}")
        return None

def setup_webdriver(headless=True):
    """웹드라이버 설정 및 초기화 함수"""
    try:
        options = webdriver.ChromeOptions()
        if headless:
            options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        options.add_experimental_option('excludeSwitches', ['enable-logging'])
        options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
        
        # SSL 오류 무시 옵션
        options.add_argument('--ignore-certificate-errors')
        options.add_argument('--ignore-ssl-errors')
        
        service = Service(executable_path="C:\drivers\chromedriver.exe")
        driver = webdriver.Chrome(service=service, options=options)
        print("크롬드라이버 정상 초기화")
        return driver
    except Exception as e:
        print(f"[오류] 크롬드라이버 초기화 실패: {e}")
        return None

def check_table_exists(conn, table_name):
    """테이블 존재 여부 확인 함수"""
    cursor = None
    try:
        cursor = conn.cursor()
        cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
        return cursor.fetchone() is not None
    except Exception as e:
        print(f"[오류] 테이블 확인 실패: {e}")
        return False
    finally:
        if cursor:
            cursor.close()

def get_table_name_for_date(base_table, date_str):
    """날짜에 해당하는 월별 테이블 이름 생성"""
    try:
        # YYYY-MM-DD 형식의 날짜를 파싱
        if isinstance(date_str, datetime):
            date_obj = date_str
        else:
            date_obj = datetime.strptime(date_str.split()[0], '%Y-%m-%d')
        
        # 테이블 이름 형식: base_table_YYYY_MM
        table_name = f"{base_table}_{date_obj.year}_{date_obj.month:02d}"
        return table_name
    except Exception as e:
        print(f"[오류] 테이블 이름 생성 실패: {e}")
        # 기본 테이블명이 아닌 현재 년월로 테이블 생성
        current_date = datetime.now()
        return f"{base_table}_{current_date.year}_{current_date.month:02d}"

def create_monthly_table(conn, base_table, table_name):
    """월별 테이블 생성 함수"""
    cursor = None
    try:
        cursor = conn.cursor()
        
        # 기본 테이블명 추출
        base_name = base_table
        
        # 테이블 스키마 가져오기
        if base_name in TABLE_SCHEMAS:
            schema = TABLE_SCHEMAS[base_name]
            create_table_sql = f"CREATE TABLE IF NOT EXISTS {table_name} ({schema})"
            
            cursor.execute(create_table_sql)
            conn.commit()
            print(f"[성공] 월별 테이블 {table_name} 생성 완료")
            return True
        else:
            print(f"[오류] {base_name} 테이블의 스키마 정의를 찾을 수 없습니다.")
            return False
            
    except Exception as e:
        print(f"[오류] 테이블 {table_name} 생성 실패: {e}")
        if conn:
            conn.rollback()
        return False
    finally:
        if cursor:
            cursor.close()

def save_to_monthly_table(conn, df, base_table, date_column='register_date', columns=None):
    """데이터프레임을 월별 테이블에 저장하는 함수"""
    if df.empty:
        print("[정보] 저장할 데이터가 없습니다.")
        return 0
    
    # 날짜별로 데이터 그룹화
    grouped_data = {}
    
    for idx, row in df.iterrows():
        try:
            # 날짜 컬럼값 가져오기
            date_value = row[date_column]
            if not date_value:
                # 날짜 값이 없는 경우 현재 날짜 사용
                date_value = datetime.now().strftime('%Y-%m-%d')
            
            # 월별 테이블명 생성
            table_name = get_table_name_for_date(base_table, date_value)
            
            if table_name not in grouped_data:
                grouped_data[table_name] = []
            
            grouped_data[table_name].append(row)
        except Exception as e:
            print(f"[오류] 데이터 그룹화 중 오류: {e}")
            continue
    
    # 각 월별 테이블에 데이터 저장
    total_saved = 0
    
    for table_name, rows in grouped_data.items():
        cursor = None
        try:
            cursor = conn.cursor()
            
            # 테이블 존재 여부 확인 및 없으면 생성
            if not check_table_exists(conn, table_name):
                print(f"[정보] 테이블 {table_name}이 존재하지 않습니다. 생성을 시도합니다.")
                if not create_monthly_table(conn, base_table, table_name):
                    print(f"[오류] {table_name} 테이블 생성 실패, 데이터 저장 건너뜀")
                    continue
            
            # 데이터 저장을 위한 SQL 구성
            if not columns:
                columns = rows[0].index.tolist()  # 모든 컬럼 사용
            
            placeholders = ', '.join(['%s'] * len(columns))
            column_names = ', '.join(columns)
            sql = f"INSERT INTO {table_name} ({column_names}) VALUES ({placeholders})"
            
            # 데이터 저장
            rows_data = []
            for row in rows:
                row_values = [row[col] for col in columns]
                rows_data.append(row_values)
            
            # 벌크 삽입
            cursor.executemany(sql, rows_data)
            conn.commit()
            
            saved_count = len(rows)
            total_saved += saved_count
            print(f"[성공] {table_name} 테이블에 {saved_count}건 저장 완료")
            
        except Exception as e:
            print(f"[오류] {table_name} 테이블 데이터 저장 실패: {e}")
            conn.rollback()
        finally:
            if cursor:
                cursor.close()
    
    return total_saved

def get_last_data_from_monthly_tables(conn, base_table, date_column='register_date'):
    """월별 테이블에서 가장 최근 데이터와 다음 인덱스 조회"""
    cursor = None
    try:
        cursor = conn.cursor()
        
        # 모든 월별 테이블 조회 (기본 테이블 제외)
        cursor.execute(f"SHOW TABLES LIKE '{base_table}_%'")
        tables = [row[0] for row in cursor.fetchall()]
        
        if not tables:
            print(f"[정보] {base_table}_* 형식의 테이블이 없습니다. 새 월별 테이블을 생성합니다.")
            # 데이터가 없는 경우 현재 년월에 해당하는 테이블 이름 생성
            current_date = datetime.now()
            monthly_table = f"{base_table}_{current_date.year}_{current_date.month:02d}"
            
            # 새 월별 테이블 생성
            if create_monthly_table(conn, base_table, monthly_table):
                print(f"[정보] 새 월별 테이블 {monthly_table} 생성 완료")
            else:
                print(f"[경고] 월별 테이블 생성 실패")
            
            return None, 1
        
        # 모든 월별 테이블에서 가장 최근 데이터 조회
        union_queries = []
        for table in tables:
            union_queries.append(f"SELECT *, '{table}' as source_table FROM {table}")
        
        union_sql = " UNION ALL ".join(union_queries)
        cursor.execute(f"SELECT * FROM ({union_sql}) AS combined ORDER BY {date_column} DESC LIMIT 1")
        latest_row = cursor.fetchone()
        
        if not latest_row:
            return None, 1
        
        # 모든 월별 테이블에서 가장 큰 idx 찾기
        idx_queries = []
        for table in tables:
            idx_queries.append(f"SELECT MAX(idx) FROM {table}")
        
        idx_sql = " UNION ALL ".join(idx_queries)
        cursor.execute(f"SELECT MAX(MAX_idx) FROM ({idx_sql}) AS max_indices")
        max_idx = cursor.fetchone()[0] or 0
        
        return latest_row, max_idx + 1
    
    except Exception as e:
        print(f"[오류] 최근 데이터 조회 실패: {e}")
        return None, 1
    finally:
        if cursor:
            cursor.close()

# 전역 드라이버 변수
DRIVER = None

def get_driver(headless=True):
    """전역 웹드라이버 인스턴스 가져오기"""
    global DRIVER
    if DRIVER is None:
        DRIVER = setup_webdriver(headless)
    return DRIVER

def close_driver():
    """전역 웹드라이버 인스턴스 닫기"""
    global DRIVER
    if DRIVER:
        try:
            DRIVER.quit()
        except:
            pass
        DRIVER = None
