# -*- coding: utf-8 -*-
import time
from bs4 import BeautifulSoup
import requests
import pandas as pd
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from datetime import datetime, timedelta
from newspaper import Article
import warnings
import sys
import os
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)
from database_utils import connect_db, save_to_monthly_table, get_last_data_from_monthly_tables, setup_webdriver, create_monthly_table
warnings.filterwarnings('ignore')

# 기본 테이블명
BASE_TABLE = 'naver_news'

def setup_database():
    """데이터베이스 연결 설정 및 날짜 범위 설정"""
    try:
        conn = connect_db()
        if not conn:
            return (
                datetime.today() - timedelta(days=7),
                datetime.today() - timedelta(days=1),
                1,
                set(),
                set()
            )
        
        # 월별 테이블에서 최근 데이터와 다음 인덱스 조회
        latest_row, next_index = get_last_data_from_monthly_tables(conn, BASE_TABLE, 'register_date')
        
        # 기존 URL과 제목 로드를 위한 임시 쿼리 구성
        with conn.cursor() as cursor:
            # 모든 월별 테이블에서 URL과 제목 조회
            cursor.execute(f"SHOW TABLES LIKE '{BASE_TABLE}_%'")
            tables = [row[0] for row in cursor.fetchall()]
            
            # 테이블이 없는 경우 현재 년월에 해당하는 테이블 생성
            if not tables:
                current_date = datetime.now()
                monthly_table = f"{BASE_TABLE}_{current_date.year}_{current_date.month:02d}"
                if create_monthly_table(conn, BASE_TABLE, monthly_table):
                    print(f"[정보] 새 월별 테이블 {monthly_table} 생성 완료")
                    tables.append(monthly_table)
            
            url_queries = []
            title_queries = []
            
            for table in tables:
                url_queries.append(f"SELECT url FROM {table} WHERE url IS NOT NULL AND url != ''")
                title_queries.append(f"SELECT title FROM {table} WHERE title IS NOT NULL AND title != ''")
            
            # URL 중복 체크용 데이터 수집
            existing_urls = set()
            for query in url_queries:
                try:
                    cursor.execute(query)
                    existing_urls.update(row[0] for row in cursor.fetchall() if row[0])
                except Exception as e:
                    print(f"[경고] URL 쿼리 실행 중 오류: {e}")
                    continue
            
            # 제목 중복 체크용 데이터 수집
            existing_titles = set()
            for query in title_queries:
                try:
                    cursor.execute(query)
                    existing_titles.update(row[0] for row in cursor.fetchall() if row[0])
                except Exception as e:
                    print(f"[경고] 제목 쿼리 실행 중 오류: {e}")
                    continue
        
        conn.close()
        
        # 날짜 범위 설정
        if latest_row and latest_row['register_date']:
            # 마지막 수집 날짜 + 1일
            start_date = datetime.strptime(str(latest_row['register_date']), '%Y-%m-%d') + timedelta(days=1)
        else:
            # 초기값 : 최근 30일
            start_date = datetime.today() - timedelta(days=30)
        
        end_date = datetime.today() - timedelta(days=1)
        
        # 시간 정보 추가
        start_date = datetime.combine(start_date.date(), datetime.min.time())
        end_date = datetime.combine(end_date.date(), datetime.max.time())
        
        print(f"수집 기간: {start_date.strftime('%Y-%m-%d %H:%M:%S')} ~ {end_date.strftime('%Y-%m-%d %H:%M:%S')}")
        return start_date, end_date, next_index, existing_urls, existing_titles
        
    except Exception as e:
        print(f"[오류] 데이터베이스 설정 중 오류: {e}")
        return (
            datetime.today() - timedelta(days=7),
            datetime.today() - timedelta(days=1),
            1,
            set(),
            set()
        )

def collect_news_urls(start_date, end_date):
    """뉴스 URL 및 저자 정보 수집"""
    try:
        # 웹드라이버 설정
        driver = setup_webdriver()
        
        # requests 설정
        requests.packages.urllib3.disable_warnings()
        session = requests.Session()
        session.verify = False  # SSL 검증 비활성화
        
        article_list = []
        author_list = []
        
        # 날짜 형식 변환
        start_str = start_date.strftime("%Y.%m.%d")
        end_str = end_date.strftime("%Y.%m.%d")
        
        # 페이지별 URL 수집
        for n in range(1, 1000, 10):
            url = f'''https://search.naver.com/search.naver?where=news&sm=tab_pge&query=%EB%B0%80%EC%96%91&sort=1
                    &photo=0&field=0&pd=3&ds={start_str}&de={end_str}&start={n}'''
            
            raw = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
            html = BeautifulSoup(raw.text, "html.parser")
            articles = html.select("ul.list_news > li")
            
            if not articles:
                break
                
            for ar in articles:
                try:
                    article_url = ar.find("a")['data-url']
                    article_author = ar.find_all("a")[3].text if len(ar.find_all("a")) >= 4 else "Unknown"
                    
                    article_list.append(article_url)
                    author_list.append(article_author)
                except Exception as e:
                    print(f"URL 추출 중 오류: {e}")
                    continue
            
            time.sleep(1)
        
        return driver, article_list, author_list
        
    except Exception as e:
        print(f"URL 수집 중 오류: {e}")
        return None, [], []

def clean_text(text):
    """텍스트 정제 함수"""
    remove_patterns = [
        r'ⓒ .+? 무단전재·재배포 금지',
        r'저작권자 ⓒ .+? 무단전재 및 재배포 금지',
        r'밀양=.+?기자',
        "큰사진보기",
        "관련사진보기",
        r'기사모아보기',
        r'투데이는 여러분의 후원금을 귀하게 쓰겠습니다.',
        r'연합뉴스TV 기사문의 및 제보 : 카톡/라인\s+\w+\(.*?\)',
        r'제보는 카카오톡\s+\w+',
        r'\w+@\w+.kr',
        r'<저작권자\(c\) \w+, 무단 전재-재배포 금지>',
        r'\[저작권자\(c\) \w+ 무단전재 및 재배포 금지\]',
        r'(?:카카오톡|카카오스토리|네이버밴드|네이버블로그|URL복사)\(으\)로 기사보내기',
        r'\(사진제공=\w+\)',
        r'사진/',
        r'\[사진=\w+\]',
        r'\w+@\w+.com',
        r'\w+@\w+.kr',
        r'\[사진=\w+ 제공\]',
        r"ⓒ .+? 관련사진보기",
        r'\(사진=\w+ 기자\)',
        r'\(사진=\w+ \)',
        "글씨키우기 글씨줄이기 프린트 top\n\nfacebook twitter kakao story naver band share",
        r'\[신아일보\]',
        r'\w+@\w+',
        r'〈ⓒ \w+\([^)]+\), 무단전재 및 수집, 재배포금지',
        "UPI뉴스 /",
        r'\[밀양=\w+\s+기자\]',
        "\[\w+\s+\w+ 기자\]",
        r'\[\w+\s+\w= 기자\]',
        r'\[\w+ 기자\]',
        r'[^a-z]{3} 기자',
        r'\w+\s+기자',
        r'\[\w+ 제공\]',
        "을 응원해주세요.",
        "기사 잘 보셨나요?",
        "독자님의 응원이 기자에게 큰 힘이 됩니다.",
        "후원회원이 되어주세요.",
        "독자님의 후원금은 모두 기자에게 전달됩니다.",
        "정기후원은 모든 기자들에게 전달됩니다.",
        "정기후원 하기",
        "저작권자 ? 전국매일신문 - 전국의 생생한 뉴스를 '한눈에' 무단전재 및 재배포 금지",
        r'\[\w+\s+\w+\s+\w+\s+기자\]',
        "한국경제매거진 여행팀 기자",
        r'\w+=\w+',
        "고비룡 기자",
        "자료제공/밀양시",
        r'사진/ \w+ 사진작가',
        r'\(사진=\w+\s\w+\)',
        "대한민국 정책기자단 박하나",
        '카카오톡(으)로',
        '카카오스토리(으)로',
        '네이버밴드(으)로',
        '네이버블로그(으)로',
        '기사보내기',
        'URL복사(으)로',
        "고비룡(밀양창녕본부장)",
        "하용성 부산/경남 기자",
        "Fn투데이는 여러분의 후원금을 귀하게 쓰겠습니다.",
        "편도욱 로이슈 기자",
        "정세욱 기자",
        "영남취재본부",
        "편집국 의 다른기사보기",
        "공유하기",
        "더보기",
        "(사진)",
        "※ '당신의 제보가 뉴스가 됩니다'",
        "[카카오톡] YTN 검색해 채널 추가",
        "이 기사를 공유합니다.",
        "URL 기사저장",
        "이 기사와 관련된 기사",
        "죄송하지만 다른 브라우저를 사용하여 주십시오. 닫기",
        r'ⓒ \w+',
        "덧붙이는 글 | 기자의 블로그에도 실릴 예정입니다",
        "저작권자",
        "무단전재 및 재배포 금지",
        "경남도민문",
        "투어코리 - No.1 여행·축제 뉴스",
        r'\w+ 기자',
        r'\(사진제공=\w+\s+\w+\)',
        r'\w+기자',
        'GoodNews paper',
        '무단전재 및 수집, 재배포금지',
        '무단전재-재배포 금지',
        'co.kr',
        '\(www.\w+.co.kr\)'
    ]
    
    cleaned_text = text
    for pattern in remove_patterns:
        cleaned_text = re.sub(pattern, "", cleaned_text)
    
    # 중복 공백 제거 및 앞뒤 공백 제거
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()
    return cleaned_text

def process_news_content(driver, urls, authors, existing_urls, existing_titles, next_index):
    """뉴스 내용 수집, 전처리 및 저장"""
    try:
        df = pd.DataFrame(columns=['idx', 'title', 'author', 'register_date', 'url', 'body', 'summary', 'status'])
        saved_count = 0
        skipped_count = 0
        
        # 뉴스 내용 수집
        for i, (url, author) in enumerate(zip(urls, authors)):
            if url in existing_urls:
                print(f"중복 URL 발견: {url}")
                skipped_count += 1
                continue
                
            try:
                print(f"{i+1}/{len(urls)} 처리 중: {url}")
                
                # 기사 다운로드
                article = Article(url, language='ko')
                article.download()
                article.parse()
                
                # 중복 제목 확인
                if article.title in existing_titles:
                    print(f"중복 제목 발견: {article.title}")
                    skipped_count += 1
                    continue
                
                # 기본 정보 저장
                new_row = {
                    'idx': next_index + i,
                    'url': url,
                    'author': author,
                    'title': article.title,
                    'register_date': article.publish_date.strftime('%Y-%m-%d') if article.publish_date else datetime.today().strftime('%Y-%m-%d'),
                    'status': 'N'
                }
                
                # 내용 수집 및 전처리
                if author != '뉴시스':
                    text = article.text
                else:
                    driver.get(url)
                    text = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.XPATH, '//*[@id="content"]/div[1]/div[1]/div[3]/article'))
                    ).text
                
                # 텍스트 정제 함수 적용
                cleaned_text = clean_text(text)
                
                new_row['body'] = cleaned_text
                new_row['summary'] = cleaned_text[:300] + "..." if len(cleaned_text) > 300 else cleaned_text
                
                # 데이터프레임에 추가
                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
                saved_count += 1
                time.sleep(1)
                
            except Exception as e:
                print(f"기사 처리 중 오류: {e}")
                continue
        
        # 데이터 정제
        df = df.drop_duplicates()
        df = df.dropna(subset=['body'])
        df = df.fillna("")
        df = df.reset_index(drop=True)
        
        # 월별 테이블에 저장
        if not df.empty:
            conn = connect_db()
            try:
                # 컬럼 지정
                columns = ['idx', 'title', 'author', 'register_date', 'url', 'body', 'summary', 'status']
                total_saved = save_to_monthly_table(conn, df, BASE_TABLE, 'register_date', columns)
                print(f"총 {total_saved}건 저장 완료")
            finally:
                conn.close()
        
        return saved_count, skipped_count
        
    except Exception as e:
        print(f"뉴스 처리 중 오류: {e}")
        return 0, 0

def main():
    """메인 실행 함수"""
    try:
        print("네이버 뉴스 크롤러 시작")
        
        # 초기 설정
        start_date, end_date, next_index, existing_urls, existing_titles = setup_database()
        
        # URL 수집
        driver, urls, authors = collect_news_urls(start_date, end_date)
        if not urls:
            print("수집된 URL이 없습니다.")
            return
            
        # 뉴스 처리 및 저장
        try:
            saved_count, skipped_count = process_news_content(
                driver, urls, authors, existing_urls, existing_titles, next_index
            )
            print(f"=== 크롤링 완료 (저장: {saved_count}개, 중복: {skipped_count}개) ===")
        finally:
            if driver:
                driver.quit()
                
    except Exception as e:
        print(f"크롤러 실행 중 오류: {e}")

if __name__ == "__main__":
    main()