import time
from datetime import datetime, timedelta
import re
import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database_utils import connect_db, save_to_monthly_table, get_last_data_from_monthly_tables, create_monthly_table

# 기본 테이블명
BASE_TABLE = 'bigkinds_news'

def database_handler(action="load", result_df=None):
    """데이터베이스 로드/저장 작업을 처리하는 통합 함수"""
    try:
        if action == "load":
            conn = connect_db()
            if not conn:
                return None, None, None, None
            
            try:
                # 월별 테이블에서 최근 데이터와 다음 인덱스 조회
                latest_row, next_idx = get_last_data_from_monthly_tables(conn, BASE_TABLE, 'register_date')
                
                # 기존 링크 조회
                with conn.cursor() as cursor:
                    # 모든 월별 테이블 조회
                    cursor.execute(f"SHOW TABLES LIKE '{BASE_TABLE}_%'")
                    tables = [row[0] for row in cursor.fetchall()]
                    
                    # 테이블이 없는 경우 현재 년월에 해당하는 테이블 생성
                    if not tables:
                        current_date = datetime.now()
                        monthly_table = f"{BASE_TABLE}_{current_date.year}_{current_date.month:02d}"
                        if create_monthly_table(conn, BASE_TABLE, monthly_table):
                            print(f"[정보] 새 월별 테이블 {monthly_table} 생성 완료")
                            tables.append(monthly_table)
                    
                    # 모든 월별 테이블에서 링크 조회
                    existing_links = set()
                    for table in tables:
                        try:
                            cursor.execute(f"SELECT link FROM {table} WHERE link IS NOT NULL")
                            existing_links.update(row[0] for row in cursor.fetchall() if row[0])
                        except Exception as e:
                            print(f"[경고] 테이블 {table} 조회 중 오류: {e}")
                            continue
                
                # 날짜 설정
                if latest_row and latest_row['register_date']:
                    start_date = datetime.strptime(str(latest_row['register_date']), '%Y-%m-%d')
                    # 최근 수집일 이후 7일간의 데이터 수집
                    start_date = start_date - timedelta(days=7)
                else:
                    # 처음 실행 시 7일 전부터 데이터 수집
                    start_date = datetime.today() - timedelta(days=7)
                
                end_date = datetime.today()
                
                if not next_idx:
                    next_idx = 1
                
                print(f"수집 기간: {start_date.strftime('%Y-%m-%d')} ~ {end_date.strftime('%Y-%m-%d')}")
                return conn, start_date, end_date, next_idx, existing_links
            except Exception as e:
                print(f"[오류] 데이터베이스 정보 로드 중 오류: {e}")
                return conn, None, None, None, set()
        
        elif action == "save" and result_df is not None and not result_df.empty:
            conn = connect_db()
            if not conn:
                return False
            
            try:
                # 컬럼 지정
                columns = ['idx', 'title', 'press', 'class', 'register_date', 'body', 'link', 'status']
                saved_count = save_to_monthly_table(conn, result_df, BASE_TABLE, 'register_date', columns)
                print(f"[성공] 총 {saved_count}건 저장 완료")
                return True
            except Exception as e:
                print(f"[오류] 데이터 저장 중 오류: {e}")
                return False
            finally:
                conn.close()
        
        return False
    except Exception as e:
        print(f"[오류] 데이터베이스 처리 중 오류: {e}")
        return False

def browser_utils(driver, action, element=None, input_id=None, date_value=None):
    """브라우저 작업을 처리하는 유틸리티 함수"""
    try:
        if action == "click":
            if element:
                WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable(element)
                ).click()
                time.sleep(0.5)
                return True
            return False
        
        elif action == "input":
            if element and input_id:
                input_element = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located(element)
                )
                input_element.clear()
                input_element.send_keys(input_id)
                return True
            return False
        
        elif action == "date":
            if element and date_value:
                date_input = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located(element)
                )
                date_input.clear()
                date_input.send_keys(date_value)
                return True
            return False
        
        elif action == "wait":
            if element:
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located(element)
                )
                return True
            return False
        
        return False
    except Exception as e:
        print(f"[오류] 브라우저 작업 중 오류: {e}")
        return False

def setup_search_params(driver):
    """검색 조건 설정 함수"""
    try:
        # 빅카인즈 메인 페이지 접속
        driver.get("https://www.bigkinds.or.kr/")
        time.sleep(2)
        
        # 뉴스 검색 페이지로 이동
        browser_utils(driver, "click", (By.XPATH, "//a[contains(text(), '뉴스검색')]"))
        time.sleep(1)
        
        # 상세검색 클릭
        browser_utils(driver, "click", (By.XPATH, "//a[contains(text(), '상세검색')]"))
        time.sleep(1)
        
        # 밀양 검색어 입력
        browser_utils(driver, "input", (By.ID, "search-keyword"), "밀양")
        
        # 기간 직접 입력 선택
        browser_utils(driver, "click", (By.XPATH, "//label[contains(text(), '기간 직접입력')]"))
        time.sleep(0.5)
        
        # 시작일 설정
        start_date = (datetime.today() - timedelta(days=7)).strftime("%Y.%m.%d")
        browser_utils(driver, "date", (By.ID, "search-begin-date"), start_date)
        
        # 종료일 설정
        end_date = datetime.today().strftime("%Y.%m.%d")
        browser_utils(driver, "date", (By.ID, "search-end-date"), end_date)
        
        # 지역(경남) 선택
        browser_utils(driver, "click", (By.XPATH, "//label[contains(text(), '경남')]"))
        
        # 검색 버튼 클릭
        browser_utils(driver, "click", (By.XPATH, "//button[contains(text(), '검색')]"))
        
        # 검색 결과 로드 대기
        time.sleep(3)
        
        # 중간 검색 결과 확인
        result_count_element = driver.find_element(By.XPATH, "//span[@class='num' and contains(text(), '건')]")
        result_count = re.search(r'\d+', result_count_element.text)
        if result_count:
            count = int(result_count.group())
            print(f"검색 결과: {count}건")
            if count == 0:
                return False
        
        return True
    except Exception as e:
        print(f"[오류] 검색 설정 중 오류: {e}")
        return False

def extract_article_data(driver):
    """뉴스 기사 데이터 추출 함수"""
    try:
        articles_df = pd.DataFrame(columns=['idx', 'title', 'press', 'class', 'register_date', 'body', 'link', 'status'])
        idx = 1
        
        # 페이지 수 파악
        pagination = driver.find_element(By.CLASS_NAME, "pagination")
        page_links = pagination.find_elements(By.TAG_NAME, "a")
        max_page = 1
        
        for link in page_links:
            try:
                page_num = int(link.text)
                if page_num > max_page:
                    max_page = page_num
            except:
                continue
        
        print(f"총 {max_page}페이지 크롤링 시작")
        
        for page in range(1, max_page + 1):
            print(f"{page}/{max_page} 페이지 처리 중...")
            
            if page > 1:
                # 페이지 번호 클릭
                page_element = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, f"//a[@aria-label='page-{page}']"))
                )
                page_element.click()
                time.sleep(2)
            
            # 현재 페이지의 기사 링크 추출
            news_items = driver.find_elements(By.CLASS_NAME, "news-item")
            
            for item in news_items:
                try:
                    title_element = item.find_element(By.CLASS_NAME, "news-tit")
                    title = title_element.text.strip()
                    
                    # 신문사, 분류, 날짜 정보 추출
                    meta_info = item.find_element(By.CLASS_NAME, "info").text.strip()
                    meta_parts = meta_info.split('|')
                    
                    press = meta_parts[0].strip() if len(meta_parts) > 0 else ""
                    news_class = meta_parts[1].strip() if len(meta_parts) > 1 else ""
                    date_str = meta_parts[2].strip() if len(meta_parts) > 2 else ""
                    
                    # 기사 클릭 및 상세 내용 추출
                    title_element.click()
                    time.sleep(1)
                    
                    # 새 창 처리
                    windows = driver.window_handles
                    driver.switch_to.window(windows[-1])
                    
                    # 본문 추출
                    body_element = WebDriverWait(driver, 10).until(
                        EC.presence_of_element_located((By.CLASS_NAME, "news-detail-body"))
                    )
                    body = body_element.text.strip()
                    
                    # URL 추출
                    current_url = driver.current_url
                    
                    # 새 창 닫고 원래 창으로 복귀
                    driver.close()
                    driver.switch_to.window(windows[0])
                    
                    # 데이터프레임에 추가
                    new_row = pd.DataFrame({
                        'idx': [idx],
                        'title': [title],
                        'press': [press],
                        'class': [news_class],
                        'register_date': [date_str],
                        'body': [body],
                        'link': [current_url],
                        'status': ['N']
                    })
                    
                    articles_df = pd.concat([articles_df, new_row], ignore_index=True)
                    idx += 1
                    
                except Exception as e:
                    print(f"[오류] 기사 처리 중 오류: {e}")
                    # 새 창이 열려있다면 닫기
                    windows = driver.window_handles
                    if len(windows) > 1:
                        driver.close()
                        driver.switch_to.window(windows[0])
                    continue
            
            time.sleep(1)
        
        return articles_df
    
    except Exception as e:
        print(f"[오류] 데이터 추출 중 오류: {e}")
        return pd.DataFrame()

def crawler():
    """메인 크롤링 함수"""
    driver = None
    try:
        # 초기 설정
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_experimental_option('excludeSwitches', ['enable-logging'])
        
        driver = webdriver.Chrome(options=options)
        driver.implicitly_wait(10)
        
        # 데이터베이스 연결 및 정보 조회
        conn, start_date, end_date, next_idx, existing_links = database_handler("load")
        
        if not conn or not start_date or not end_date:
            print("[오류] 데이터베이스 설정 실패")
            return
        
        # 검색 설정
        if not setup_search_params(driver):
            print("[오류] 검색 설정 실패 또는 검색 결과 없음")
            return
        
        # 데이터 추출
        articles_df = extract_article_data(driver)
        
        if articles_df.empty:
            print("[정보] 추출된 기사가 없습니다.")
            return
        
        print(f"총 {len(articles_df)}개 기사 추출 완료")
        
        # 중복 제거 및 인덱스 재설정
        articles_df = articles_df[~articles_df['link'].isin(existing_links)]
        articles_df['idx'] = list(range(next_idx, next_idx + len(articles_df)))
        
        if articles_df.empty:
            print("[정보] 저장할 새로운 기사가 없습니다.")
            return
        
        # 데이터 저장
        if database_handler("save", articles_df):
            print("[성공] 크롤링 및 저장 완료")
        else:
            print("[오류] 데이터 저장 실패")
    
    except Exception as e:
        print(f"[오류] 크롤링 중 오류 발생: {e}")
    
    finally:
        if driver:
            try:
                driver.quit()
            except:
                pass

if __name__ == "__main__":
    print("\n빅카인즈 뉴스 크롤러 시작")
    crawler()
    print("빅카인즈 뉴스 크롤러 종료")
