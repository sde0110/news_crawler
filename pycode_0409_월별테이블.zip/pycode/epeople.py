# -*- coding: utf-8 -*-
import re, time, os, sys
import pandas as pd
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
import warnings

# 상대 경로 처리
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)
from database_utils import connect_db, save_to_monthly_table, get_last_data_from_monthly_tables, create_monthly_table

# 경고 숨기기
warnings.filterwarnings('ignore')

# 기본 테이블명과 지연 시간
BASE_TABLE = 'epeople'
DELAY_TIME = 2


def setup_webdriver(headless=True):
    """크롬 웹드라이버 설정 및 초기화"""
    try:
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        options.add_experimental_option('excludeSwitches', ['enable-logging'])
        options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
        
        service = Service(executable_path="C:\drivers\chromedriver.exe")
        driver = webdriver.Chrome(service=service, options=options)
        print("크롬드라이버 정상 초기화")
        return driver
    except Exception as e:
        print(f"[오류] 크롬드라이버 초기화 실패: {e}")
        return None


def get_next_date(date_str, format='%Y-%m-%d'):
    """날짜에 1일 더하기"""
    date_obj = datetime.strptime(date_str, format)
    next_date = date_obj + timedelta(days=1)
    return next_date.strftime(format)


def get_today_and_yesterday():
    """오늘과 어제 날짜 반환"""
    today = datetime.now()
    yesterday = today - timedelta(days=1)
    return today.strftime('%Y-%m-%d'), yesterday.strftime('%Y-%m-%d')


def all_crawler(key, value, last_date, today):
    """국민신문고 데이터 크롤링"""
    driver = None
    try:
        print(f"크롤링 시작: {key}, {last_date} ~ {today}")
        driver = setup_webdriver(headless=False)
        url = 'https://www.epeople.go.kr/nep/prpsl/opnPrpl/opnpblPrpslList.npaid'
        driver.get(url)

        # 페이지 설정: 50개 보기
        select = Select(driver.find_element(By.ID, "listCnt"))
        select.select_by_index(4)

        # 지방자치단체 선택
        select_agency = Select(driver.find_element(By.ID, "searchCd"))
        select_agency.select_by_index(2)
        time.sleep(1)

        # 지역 선택
        select_area = Select(driver.find_element(By.NAME, "searchInstCd"))
        select_area.select_by_index(value)

        # 날짜 설정
        start_date = driver.find_element(By.NAME, "rqstStDt")
        start_date.clear()
        start_date.send_keys(last_date)

        end_date = driver.find_element(By.NAME, "rqstEndDt")
        end_date.clear()
        end_date.send_keys(today)

        # 검색 버튼 클릭
        search_button_xpath = '//*[@id="frm"]/div[1]/div[1]/div[4]/button[1]'
        driver.find_element(By.XPATH, search_button_xpath).click()
        time.sleep(2)

        # 데이터 건수 확인
        total = driver.find_element(By.XPATH, f'//*[@id="frm"]/div[2]/span/span').text
        print(f"데이터 건수: {total}")

        # 페이지네이션 정보 확인
        pagination = driver.find_element(By.XPATH, '//*[@id="frm"]/div[3]')
        html_content = pagination.get_attribute('innerHTML')
        page_numbers = re.findall(r'frmPageLink\((\d+)\)', html_content)
            
        if page_numbers:
            page_count = max(map(int, page_numbers))
            print(f"마지막 페이지 번호: {page_count}")
        else:
            page_count = 1

        # 결과 데이터프레임 초기화
        result_df = pd.DataFrame(columns=['제목', '내용', '작성일자', '답변', '답변일자', '처리기관'])

        # 페이지별 크롤링
        current_page = 1
        while current_page <= page_count:
            print(f"{current_page}/{page_count} 페이지 처리 중...")
            
            try:
                # 테이블 데이터 추출
                table = driver.find_element(By.CLASS_NAME, 'tbl.default.brd1')
                tbody = table.find_element(By.TAG_NAME, "tbody")
                rows = tbody.find_elements(By.TAG_NAME, "tr")
                
                # 각 행의 데이터 추출
                for i in range(1, len(rows) + 1):
                    try:
                        # 게시물 클릭
                        complain_list = f'//*[@id="frm"]/table/tbody/tr[{i}]/td[2]/a'
                        driver.find_element(By.XPATH, complain_list).click()
                        time.sleep(1)
                        
                        # 상세 정보 가져오기
                        try:
                            title = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[1]/div[1]').text
                        except:
                            title = "제목 없음"
                        
                        try:
                            text = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[3]').text
                        except:
                            text = "내용 없음"
                        
                        try:
                            date = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[4]/div[2]').text
                        except:
                            date = ""
                        
                        try:
                            depart = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[2]/div[2]').text
                        except:
                            depart = "처리기관 정보 없음"
                        
                        try:
                            answer = driver.find_element(By.XPATH, '//*[@id="txt"]/div[2]/div[1]/div[3]').text
                        except:
                            answer = "답변 전"
                        
                        try:
                            ans_date = driver.find_element(By.XPATH, '//*[@id="txt"]/div[2]/div/div/div[2]').text
                        except:
                            ans_date = ""
                        
                        try:
                            part = driver.find_element(By.XPATH, '//*[@id="txt"]/div[1]/div/div[2]/div[1]').text
                        except:
                            part = "분야 정보 없음"
                        
                        # 데이터프레임에 추가
                        new_row = pd.DataFrame({
                            '제목': [title],
                            '내용': [text],
                            '작성일자': [date],
                            '처리기관': [depart],
                            '답변': [answer],
                            '답변일자': [ans_date],
                            '분야': [part]
                        })
                        result_df = pd.concat([result_df, new_row], ignore_index=True)
                        
                        # 뒤로 가기
                        driver.back()
                        time.sleep(1)
                    
                    except Exception as e:
                        print(f"[오류] {i}번째 행 처리 중 오류: {e}")
                        try:
                            driver.back()
                        except:
                            pass
                        time.sleep(1)
                        continue
                
                # 다음 페이지로 이동
                current_page += 1
                if current_page <= page_count:
                    try:
                        driver.execute_script(f"frmPageLink({current_page})")
                        time.sleep(2)
                    except Exception as e:
                        print(f"[오류] 페이지 이동 실패: {e}")
            
            except Exception as e:
                print(f"[오류] 페이지 처리 중 오류: {e}")
                break

        # 지역 정보 추가 및 결과 반환
        result_df['region'] = key
        print(f"{key} 크롤링 완료: {len(result_df)}건")
        return result_df

    except Exception as e:
        print(f"[오류] 크롤링 실패: {e}")
        return pd.DataFrame()
    finally:
        if driver:
            driver.quit()


def get_data(conn, base_table=BASE_TABLE):
    """최근 등록 날짜와 다음 인덱스 조회"""
    latest_row, next_idx = get_last_data_from_monthly_tables(conn, base_table, 'register_date')
    
    if not latest_row:
        # 데이터가 없는 경우 기본값 반환
        return '2000-01-01', next_idx, None
    
    # 마지막 날짜의 다음 날로 설정
    last_date = (datetime.strptime(str(latest_row['register_date']), '%Y-%m-%d') + timedelta(1)).strftime('%Y-%m-%d')
    latest_table = latest_row['source_table']
    
    return last_date, next_idx, latest_table


def epeople_all(conn, today):
    """국민신문고 통합 사이트 크롤링 및 데이터 저장"""
    base_table = BASE_TABLE
    last_date, idx, latest_table = get_data(conn, base_table)
    
    # 데이터베이스에 이전 데이터가 없는 경우 2일 전으로 설정
    if last_date == '2000-01-01':
        last_date = (datetime.strptime(today, '%Y-%m-%d') - timedelta(days=2)).strftime('%Y-%m-%d')
    
    print(f"[디버그] 크롤링 기간: {last_date} ~ {today}")
    if latest_table:
        print(f"[디버그] 최근 데이터가 저장된 테이블: {latest_table}")
    else:
        print("[디버그] 최근 데이터가 저장된 테이블 없음")
      
    # 국민신문고 지방자치단체 지역 코드
    region_code = {
        '강원도': 1, '경기도': 2, '경상남도': 3, '경상북도': 4,
        '광주광역시': 5, '대구광역시': 6, '대전광역시': 7, '부산광역시': 8,
        '서울특별시': 9, '세종특별자치시': 10, '울산광역시': 11, '인천광역시': 12,
        '전라남도': 13, '전북특별자치도': 14, '제주특별자치도': 15, 
        '충청남도': 16, '충청북도': 17
    }
    
    result_df = pd.DataFrame(columns=['제목', '내용', '작성일자', '처리기관', '답변', '답변일자', '분야'])
      
    # 지역별 크롤링 실행
    for key, value in region_code.items():
        print(f"[디버그] 지역 처리 중: {key} (코드: {value})")
        try:
            df = all_crawler(key, value, last_date, today)
            print(f"[디버그] {key} 지역 {len(df)}건의 데이터 발견")
            result_df = pd.concat([result_df, df], ignore_index=True)
        except Exception as e:
            print(f"[오류] {key} 크롤링 실패: {e}")
            continue
      
    result_df = result_df.sort_values(by='작성일자')
    print(f"[디버그] 전체 발견된 데이터: {len(result_df)}건")
      
    # 데이터 저장
    if not result_df.empty:
        # idx 추가
        index_list = list(range(idx, idx + len(result_df)))
        df = result_df.assign(idx=index_list)
        
        # 컬럼 매핑
        df_renamed = df.rename(columns={
            '제목': 'title', '내용': 'body', '작성일자': 'register_date',
            '답변': 'answer', '답변일자': 'answer_date', 
            '처리기관': 'region', '분야': 'part'
        })
        
        # 상태 컬럼 추가
        df_renamed['status'] = 'N'
        
        # 월별 테이블에 저장
        columns = ['idx', 'region', 'title', 'body', 'register_date', 'answer', 'answer_date', 'part', 'status']
        saved_count = save_to_monthly_table(conn, df_renamed, base_table, 'register_date', columns)
        print(f"[디버그] 총 {saved_count}건 저장 완료")
    else:
        print("[디버그] 업데이트할 데이터가 없습니다.")


# 메인 실행 코드
if __name__ == "__main__":
    print("\n메인 프로세스 시작...")
    conn = None
    try:
        conn = connect_db()
        if not conn:
            print("[오류] 데이터베이스 연결 실패. 프로그램을 종료합니다.")
            sys.exit(1)
            
        print("데이터베이스 연결 성공")
        
        # 어제 날짜로 크롤링 실행
        _, yesterday_format = get_today_and_yesterday()
        print(f"처리할 날짜: {yesterday_format}")
        
        epeople_all(conn, yesterday_format)
        print("epeople_all 프로세스 정상 완료")
        
    except Exception as e:
        print(f"[오류] 프로세스 실패: {e}")
    finally:
        if conn:
            conn.close()
            print("데이터베이스 연결 종료")
    
